# This file: 
# 1) load all the crop-specific shocks on FAO CROPGRIDS croplands wrt 2020
# 2) Aggregate them into shocks on GTAP crops category based on each crop weight on total cropland in 2020
#-------------------------------------------------------------------------
 
 

rm(list = ls())  
gc()


# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)
library(ncdf4)

wd = paste0('D:/Il mio Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
POLLINATION_change_area = paste0(wd, 'DEMAND/POLL_change_area/IIASA_CLIM')
FINAL_SHOCKS = paste0(wd, 'FINAL_SHOCKS/')
output = paste0(wd, 'FINAL_SHOCKS/cum_wrt_2020')

#-------------------------------------------------------------------------
# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]
names(crop_dependency)[names(crop_dependency) == "CROPGRIDS"] <- "base_name_crop"

# Import GTAP_sectors ESTAT files and matching files 
setwd(paste0(wd, "/DEMAND/AREA_crops/"))

gtap_file <- file.path(wd, "DEMAND", "AREA_crops", "Row_agg_Accreu.xlsx")
getSheetNames(gtap_file)

GTAP_sectors <- read.xlsx(gtap_file, sheet = "mapping_sectors") 
GTAP_crops <- GTAP_sectors[GTAP_sectors[[4]] == "Crops", ]
GTAP_crops = GTAP_crops[c(1:3)]

Shocks_GTAP_match <- file.path(wd, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
Shocks_GTAP_match = read.xlsx(Shocks_GTAP_match)

 
final_pollination <- read.xlsx("Final_pollination_shocks_GTAP.xlsx")
final_pollination=final_pollination[c(1:3)]


#-------------------------------------------------------------------------


EU27 <- c(
  "AT","BE","BG","CY","CZ","DE","DK","EE","EL","ES",
  "FI","FR","HR","HU","IE","IT","LT","LU","LV","MT",
  "NL","PL","PT","RO","SE","SI","SK")

country_names <- c(
  AT = "Austria",
  BE = "Belgium",
  BG = "Bulgaria",
  CY = "Cyprus",
  CZ = "Czechia",
  DE = "Germany",
  DK = "Denmark",
  EE = "Estonia",
  EL = "Greece",
  ES = "Spain",
  FI = "Finland",
  FR = "France",
  HR = "Croatia",
  HU = "Hungary",
  IE = "Ireland",
  IT = "Italy",
  LT = "Lithuania",
  LU = "Luxembourg",
  LV = "Latvia",
  MT = "Malta",
  NL = "Netherlands",
  PL = "Poland",
  PT = "Portugal",
  RO = "Romania",
  SE = "Sweden",
  SI = "Slovenia",
  SK = "Slovakia"
)


#------------------------------------------------------------------------------------

Prestele_CLIM = paste0(FINAL_SHOCKS,"/Prestele_CLIM/") 
Prestele_SSPs = paste0(FINAL_SHOCKS,"/Prestele_SSPs/") 
IIASA_CLIM = paste0(FINAL_SHOCKS,"/IIASA_CLIM/") 
IIASA_SSPs = paste0(FINAL_SHOCKS,"/IIASA_SSPs/") 
Ghisbian_SSPs = paste0(FINAL_SHOCKS,"/Ghisbian_SSPs/") 
#-------------------------------------------------------------------------

# Creo shocks su GTAP sectors based on Shocks_GTAP_match

# Run with: 
# IIASA_CLIM_INCA_cum_2020_2080
# IIASA_SSPs_INCA_cum_2020_2080 
# GHSB_SSPs_INCA_cum_2020_2080
# Prestele_CLIM_INCA_cum_2020_2080
# Prestele_SSPs_INCA_cum_2020_2080 (change ^RCP to ^SSP)

# load  crops shocks: files contenenti gli shock attesi sulle aree FAO CROPGRIDS (2020) 
FINAL_SHOCKS = Prestele_SSPs

# Scegli qui quale scenario usare:
inca_scenarios <- c(
  "Prestele_SSPs_INCA_cum_2020_2080"
)

for (inca_name in inca_scenarios) {
  
  cat("\n=== Processing scenario:", inca_name, "===\n")
  
  main_dir <- file.path(FINAL_SHOCKS, inca_name)
  
  # Main list: ogni elemento è una lista di crop associati a un settore GTAP11
  shocks_by_GTAP <- list()
  
  for (i in seq_len(nrow(Shocks_GTAP_match))) {
    crop    <- Shocks_GTAP_match$shock_crop_names[i]
    gtap_id <- as.character(Shocks_GTAP_match$GTAP.11[i])
    
    crop_dir <- file.path(main_dir, crop)
    if (!dir.exists(crop_dir)) {
      warning(paste("Crop folder not found:", crop_dir))
      next
    }
    
    # Cerca un file shock_*.csv nella cartella del crop
    csv_files <- list.files(crop_dir, pattern = "^shock_.*\\.csv$", full.names = TRUE)
    if (length(csv_files) == 0) {
      warning(paste("No shock_*.csv file found in:", crop_dir))
      next
    }
    
    # Prendi il primo (coerente con la logica precedente)
    file_path <- csv_files[1]
    
    # Carica il file
    data <- tryCatch(
      read.csv(file_path),
      error = function(e) {
        warning(paste("Error reading file:", file_path, "->", e$message))
        NULL
      }
    )
    
    if (is.null(data)) next
    
    # Inizializza sottolista GTAP se mancante
    if (!gtap_id %in% names(shocks_by_GTAP)) {
      shocks_by_GTAP[[gtap_id]] <- list()
    }
    
    # Aggiungi dati per questo crop
    shocks_by_GTAP[[gtap_id]][[crop]] <- data
  }
  
  # Diagnostica: quanti file caricati?
  valid_lengths <- sapply(shocks_by_GTAP, function(x) if (is.list(x)) length(x) else 0)
  total_files_loaded <- sum(valid_lengths)
  cat("Total files loaded for", inca_name, ":", total_files_loaded, "\n")
  
  # Se non c'è nulla, passa allo scenario successivo
  if (total_files_loaded == 0) {
    warning(paste("No valid shock files loaded for scenario:", inca_name))
    next
  }
  
  #---------weighted_means_by_GTAP
  weighted_mean_category <- function(category_list) {
    df_all <- bind_rows(category_list)
    
    rcp_cols <- grep("^SSP", names(df_all), value = TRUE)
    
    df_weighted <- df_all %>%
      group_by(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN) %>%
      mutate(total_area = sum(nuts_total_hectares, na.rm = TRUE)) %>%
      mutate(weight = nuts_total_hectares / total_area) %>%
      summarise(
        total_area = first(total_area),
        across(all_of(rcp_cols), ~ weighted.mean(.x, w = weight, na.rm = TRUE)),
        .groups = "drop"
      ) %>%
      mutate(across(where(is.numeric), ~ round(.x, 2)))
    
    return(df_weighted)
  } 
  
  # Calcola medie pesate per ciascun GTAP
  weighted_dfs <- list()
  if (!is.null(shocks_by_GTAP$gro)) weighted_dfs$gro <- weighted_mean_category(shocks_by_GTAP$gro)
  if (!is.null(shocks_by_GTAP$v_f)) weighted_dfs$v_f <- weighted_mean_category(shocks_by_GTAP$v_f)
  if (!is.null(shocks_by_GTAP$osd)) weighted_dfs$osd <- weighted_mean_category(shocks_by_GTAP$osd)
  if (!is.null(shocks_by_GTAP$c_b)) weighted_dfs$c_b <- weighted_mean_category(shocks_by_GTAP$c_b)
  if (!is.null(shocks_by_GTAP$ocr)) weighted_dfs$ocr <- weighted_mean_category(shocks_by_GTAP$ocr)
  
  # SAVE RESULTS
  # Aggiungi "_policy" solo se presente nel nome scenario
  policy_suffix <- if (grepl("policy", inca_name)) "_policy" else ""
  
  GTAP_shocks_dir <- file.path(output, paste0(inca_scenarios, policy_suffix, "pct_wrt_2020"))
  dir.create(GTAP_shocks_dir, recursive = TRUE, showWarnings = FALSE)
  
  for (gtap_id in names(weighted_dfs)) {
    df <- weighted_dfs[[gtap_id]]
    
    rds_path  <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".rds"))
    csv_path  <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".csv"))
    xlsx_path <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".xlsx"))
    
    saveRDS(df, rds_path)
    write.csv(df, csv_path, row.names = FALSE)
    write.xlsx(df, xlsx_path)
  }
  
  cat("✅ Finished scenario:", inca_name, "\n")
}


 
#-------------------------------------------------------------------------
# Creo shocks su tutta l'area agricola 
#-------------------------------------------------------------------------

Shocks_GTAP_agri <- Shocks_GTAP_match %>% dplyr::mutate(GTAP.11 = "Agri_sector")
unique(Shocks_GTAP_agri$GTAP.11)

#-------------------------------------------------------------------------
# Prestele_CLIM
# Prestele_SSPs 
# IIASA_CLIM 
# IIASA_SSPs
# Ghisbian_SSPs
#-------------------------------------------------------------------------
# Run with: 
# IIASA_CLIM_INCA_cum_2020_2080
# IIASA_SSPs_INCA_cum_2020_2080 
# GHSB_SSPs_INCA_cum_2020_2080
# Prestele_CLIM_INCA_cum_2020_2080
# Prestele_SSPs_INCA_cum_2020_2080 (change ^RCP to ^SSP)

# load  crops shocks: files contenenti gli shock attesi sulle aree FAO CROPGRIDS (2020) 
FINAL_SHOCKS = Prestele_SSPs

# Scegli qui quale scenario usare:
inca_scenarios <- c(
  "Prestele_SSPs_INCA_cum_2020_2080"
)

for (inca_name in inca_scenarios) {
  
  cat("\n=== Processing scenario:", inca_name, "===\n")
  
  main_dir <- file.path(FINAL_SHOCKS, inca_name)
  
  # Main list: ogni elemento è una lista di crop associati a un settore GTAP11
  shocks_by_GTAP <- list()
  
  for (i in seq_len(nrow(Shocks_GTAP_agri))) {
    crop    <- Shocks_GTAP_agri$shock_crop_names[i]
    gtap_id <- as.character(Shocks_GTAP_agri$GTAP.11[i])
    
    crop_dir <- file.path(main_dir, crop)
    if (!dir.exists(crop_dir)) {
      warning(paste("Crop folder not found:", crop_dir))
      next
    }
    
    # Cerca un file shock_*.csv nella cartella del crop
    csv_files <- list.files(crop_dir, pattern = "^shock_.*\\.csv$", full.names = TRUE)
    if (length(csv_files) == 0) {
      warning(paste("No shock_*.csv file found in:", crop_dir))
      next
    }
    
    # Prendi il primo (coerente con la logica precedente)
    file_path <- csv_files[1]
    
    # Carica il file
    data <- tryCatch(
      read.csv(file_path),
      error = function(e) {
        warning(paste("Error reading file:", file_path, "->", e$message))
        NULL
      }
    )
    
    if (is.null(data)) next
    
    # Inizializza sottolista GTAP se mancante
    if (!gtap_id %in% names(shocks_by_GTAP)) {
      shocks_by_GTAP[[gtap_id]] <- list()
    }
    
    # Aggiungi dati per questo crop
    shocks_by_GTAP[[gtap_id]][[crop]] <- data
  }
  
  # Diagnostica: quanti file caricati?
  valid_lengths <- sapply(shocks_by_GTAP, function(x) if (is.list(x)) length(x) else 0)
  total_files_loaded <- sum(valid_lengths)
  cat("Total files loaded for", inca_name, ":", total_files_loaded, "\n")
  
  # Se non c'è nulla, passa allo scenario successivo
  if (total_files_loaded == 0) {
    warning(paste("No valid shock files loaded for scenario:", inca_name))
    next
  }
  
  #---------weighted_means_by_GTAP
  weighted_mean_category <- function(category_list) {
    df_all <- bind_rows(category_list)
    
    rcp_cols <- grep("^SSP", names(df_all), value = TRUE)
    
    df_weighted <- df_all %>%
      group_by(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN) %>%
      mutate(total_area = sum(nuts_total_hectares, na.rm = TRUE)) %>%
      mutate(weight = nuts_total_hectares / total_area) %>%
      summarise(
        total_area = first(total_area),
        across(all_of(rcp_cols), ~ weighted.mean(.x, w = weight, na.rm = TRUE)),
        .groups = "drop"
      ) %>%
      mutate(across(where(is.numeric), ~ round(.x, 2)))
    
    return(df_weighted)
  } 
  
  # Calcola medie pesate per ciascun GTAP
  weighted_dfs <- list()
  if (!is.null(shocks_by_GTAP$Agri_sector)) weighted_dfs$Agri_sector <- weighted_mean_category(shocks_by_GTAP$Agri_sector)
  
  # SAVE RESULTS
  # Aggiungi "_policy" solo se presente nel nome scenario
  policy_suffix <- if (grepl("policy", inca_name)) "_policy" else ""
  
  GTAP_shocks_dir <- file.path(output, paste0(inca_scenarios, policy_suffix, "pct_wrt_2020"))
  dir.create(GTAP_shocks_dir, recursive = TRUE, showWarnings = FALSE)
  
  for (gtap_id in names(weighted_dfs)) {
    df <- weighted_dfs[[gtap_id]]
    
    rds_path  <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".rds"))
    csv_path  <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".csv"))
    xlsx_path <- file.path(GTAP_shocks_dir, paste0("pct_wrt_2020_", gtap_id, policy_suffix, ".xlsx"))
    
    saveRDS(df, rds_path)
    write.csv(df, csv_path, row.names = FALSE)
    write.xlsx(df, xlsx_path)
  }
  
  cat("✅ Finished scenario:", inca_name, "\n")
}

 


#------------------------------------------#------------------------------------------#-------------------------------------
# AGGREGAZIONE PER PAESI UE 
#------------------------------------------#------------------------------------------#----------------------------------------
# Run with: 

# GHSB_SSPs_INCA_cum_2020_2080pct_wrt_2020
# Prestele_SSPs_INCA_cum_2020_2080pct_wrt_2020 
# IIASA_SSPs_INCA_cum_2020_2080pct_wrt_2020
# Prestele_CLIM_INCA_cum_2020_2080pct_wrt_2020
# IIASA_CLIM_INCA_cum_2020_2080pct_wrt_2020


setwd(output)

prefixes <- c("c_b", "gro", "ocr", "osd", "v_f", "Agri_sector")

results <- list()

for (p in prefixes) {
  
  # Leggi file CLIM o SSPs
  file_path <- paste0("IIASA_CLIM_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".rds")
  df <- readRDS(file_path)
  
  # Filtri
  df <- df %>%
   # filter(LEVL_CODE == 0) %>%
    dplyr::select(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN, total_area, dplyr::contains("2030"))%>%
    select(!total_area) %>%
    filter(CNTR_CODE %in% EU27) %>%
    mutate(
      CNTR_CODE = as.character(CNTR_CODE),
      NAME_LATN = country_names[CNTR_CODE]
    )
  
  df <- df %>% 
    mutate(crop_sector = p, .before = 1) %>% # aggioungo colonna col nome del df
    rename(CNTR_NAME = NAME_LATN) %>%
    select(-CNTR_CODE)
  
  results[[p]] <- df
}

# Oggetti finali
c_b <- results[["c_b"]]
gro  <- results[["gro"]]
ocr   <- results[["ocr"]]
osd     <- results[["osd"]]
v_f      <- results[["v_f"]]
Agri_sector   <- results[["Agri_sector"]]

EU_pollination_shocks <- rbind( c_b, gro, ocr, osd, v_f,Agri_sector)
EU_pollination_shocks[is.na(EU_pollination_shocks)] <- 0


#------------------------------------------------------------------------------------
# merge in un unico file aggiungendo i prefissi 

#names(EU_pollination_shocks)[c(5, 6, 7)] <- c("GHSB-1 2.6", "GHSB-3 6.0", "GHSB-5 8.5")
#GHSB_2030 = EU_pollination_shocks
#GHSB_2050 = EU_pollination_shocks
#GHSB_2070 = EU_pollination_shocks

#names(EU_pollination_shocks)[c(5:9)] <- c("PREST-1 2.6","PREST-1 4.5", "PREST-3 4.5", "PREST-3 8.5", "PREST-5 8.5")
#PREST_2030 = EU_pollination_shocks
#PREST_2050 = EU_pollination_shocks
#PREST_2070 = EU_pollination_shocks
  
#names(EU_pollination_shocks)[c(5:7)] <- c("IIASA-2 2.6","IIASA-2 4.5", "IIASA-2 7.0")
#IIASA2_2030 = EU_pollination_shocks
#IIASA2_2050 = EU_pollination_shocks
#IIASA2_2070 = EU_pollination_shocks

#names(EU_pollination_shocks)[c(5:7)] <- c("PREST_CLIM 2.6","PREST_CLIM 4.5", "PREST_CLIM 8.5")
#PREST_CLIM_2030 = EU_pollination_shocks
#PREST_CLIM_2050 = EU_pollination_shocks
#PREST_CLIM_2070 = EU_pollination_shocks

#names(EU_pollination_shocks)[c(5:8)] <- c("IIASA_CLIM 2.6","IIASA_CLIM 4.5", "IIASA_CLIM 7.0", "IIASA_CLIM 7.0")
#IIASA_CLIM_2030 = EU_pollination_shocks
#IIASA_CLIM_2050 = EU_pollination_shocks
#IIASA_CLIM_2070 = EU_pollination_shocks



#------------------------------------------------------------------------------------
EU_shocks_2030= merge( PREST_CLIM_2030, IIASA_CLIM_2030) %>% 
  merge(PREST_2030) %>%
  merge(IIASA2_2030) %>% 
  merge(GHSB_2030) 
 
EU_shocks_2030 <- cbind(
  EU_shocks_2030[ , 1:4], year = 2030, EU_shocks_2030[ , -(1:4)])
#------------------------------------------------------------------------------------

EU_shocks_2050= merge( PREST_CLIM_2050, IIASA_CLIM_2050) %>% 
  merge(PREST_2050) %>%
  merge(IIASA2_2050) %>% 
  merge(GHSB_2050) 

EU_shocks_2050 <- cbind(
  EU_shocks_2050[ , 1:4], year = 2050, EU_shocks_2050[ , -(1:4)])
#------------------------------------------------------------------------------------

EU_shocks_2070= merge( PREST_CLIM_2070, IIASA_CLIM_2070) %>% 
  merge(PREST_2070) %>%
  merge(IIASA2_2070) %>% 
  merge(GHSB_2070) 

EU_shocks_2070 <- cbind(
  EU_shocks_2070[ , 1:4], year = 2070, EU_shocks_2070[ , -(1:4)])

#------------------------------------------------------------------------------------
EU_shocks_wrt_2020 = rbind( EU_shocks_2030, EU_shocks_2050, EU_shocks_2070)
#------------------------------------------------------------------------------------

# SAVE 
setwd(output)

write.xlsx(EU_shocks_wrt_2020, "EU_shocks_wrt_2020.xlsx")
saveRDS(EU_shocks_wrt_2020, "EU_shocks_wrt_2020.rds")

   


#------------------------------------------#------------------------------------------#-------------------------------------
# Sensitivity analysis
#------------------------------------------#------------------------------------------#----------------------------------------

#................................................
wd = paste0('F:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')
shocks = paste0(wd, "FINAL_SHOCKS/cum_wrt_2020/")

#------------- -----------------------------------------------------------------------
# Creo files con valori MIN MAX e MED (median) nel 2070
#------------------------------------------------------------------------------------

setwd(shocks)

prefixes <- c("v_f", "c_b", "ocr", "gro", "osd", "Agri_sector")
keys <- c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "total_area")

results <- list()

for (p in prefixes) {
  
  # 1. Lettura file 
  GHSB   <- read.csv(paste0("GHSB_SSPs_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".csv"))
  IIASA  <- read.csv(paste0("IIASA_SSPs_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".csv"))
  IIASA2 <- read.csv(paste0("IIASA_CLIM_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".csv"))
  PREST  <- read.csv(paste0("Prestele_SSPs_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".csv"))
  PREST2 <- read.csv(paste0("Prestele_CLIM_INCA_cum_2020_2080pct_wrt_2020/pct_wrt_2020_", p, ".csv"))
  
  # 2. Merge 
  df <- IIASA |>
    merge(PREST,  by = keys) |>
    merge(PREST2, by = keys)
  
  # 2. Merge 
  df <- GHSB |>
    merge(IIASA,  by = keys) |>
    merge(IIASA2, by = keys) |>
    merge(PREST,  by = keys) |>
    merge(PREST2, by = keys)
  
  # 3. Filtri e selezioni 
  # Filtro per anno di interesse 
  df <- df %>% 
    dplyr::filter(LEVL_CODE == 0) %>% 
    dplyr::select(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN, total_area, dplyr::contains("2070"))
  
  # Filtro per paesi di interesse 
  df <- df %>% 
    dplyr::filter(CNTR_CODE %in% EU27)%>% 
    dplyr::mutate(NAME_LATN = country_names[CNTR_CODE])

  scenario_cols <- names(df)[6:ncol(df)]
  
  # 4. Calcolo MAX, MED, MIN 
  df_MM <- df %>% 
    dplyr::rowwise() %>% 
    dplyr::mutate(
      MAX = max(c_across(all_of(scenario_cols))),
      MIN = min(c_across(all_of(scenario_cols))),
      MED = median(c_across(all_of(scenario_cols)))
    ) %>% 
    dplyr::ungroup() %>% 
    dplyr::select(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN, total_area, MAX, MED, MIN)
  
  df_MM$crop <- p  # column with sector name
  df_MM <- df_MM[, c("crop", setdiff(names(df_MM), "crop"))]
  
  # 5. Rounding 
  df_MM[, c("MAX", "MED", "MIN")] <- round(df_MM[, c("MAX", "MED", "MIN")], 1)
  
  # 6. Rimozione colonne 4,6 
  df_MM <- df_MM[, -c( 4)]
  
  # 7. Salvataggio
  results[[p]] <- df_MM
}

# Oggetti finali 
v_f_MM <- results[["v_f"]]
c_b_MM <- results[["c_b"]]
ocr_MM <- results[["ocr"]]
gro_MM <- results[["gro"]]
osd_MM <- results[["osd"]]
agri_MM <- results[["Agri_sector"]]

yield_pch = rbind(v_f_MM ,
                  osd_MM ,
                  c_b_MM ,
                  ocr_MM ,
                  gro_MM ,
                  agri_MM )

yield_pch[is.na(yield_pch)] <- 0

#------------------------------------------
# aggiungo media valori pesata UE 

eu_row <- yield_pch %>%
  group_by(crop) %>%
  mutate(weight = total_area / sum(total_area, na.rm = TRUE)) %>%   # calcolo pesi
  summarise(
    NUTS_ID   = "EU",
    LEVL_CODE = 0,
    NAME_LATN = "European Union",
    total_area = sum(total_area, na.rm = TRUE),
    MAX = sum(MAX * weight, na.rm = TRUE),
    MED = sum(MED * weight, na.rm = TRUE),
    MIN = sum(MIN * weight, na.rm = TRUE),
    .groups = "drop"
  )


yield_pch_eu <- bind_rows(yield_pch, eu_row) %>%
  mutate(across(c(MAX, MED, MIN), ~ round(.x, 1)))

#------------------------------------------------------------------------------------

# Factor ordering for sectors
shock_pch <- yield_pch_eu %>%
  mutate(crop = recode(crop,
                       v_f   = "Veg, Fruit, Nuts",
                       osd   = "Oil Seeds",
                       gro   = "Cereals, Wheat, Rice",
                       ocr   = "Other crops, fibers",
                       c_b   = "Sugar cane & beet"  ,
                       Agri_sector = "Agri sector"  ))

shock_pch$crop <- factor(shock_pch$crop,
                         levels = c(
                           "Veg, Fruit, Nuts",
                           "Oil Seeds",
                           "Cereals, Wheat, Rice",
                           "Other crops, fibers",
                           "Sugar cane & beet"  ,
                           "Agri sector" ))

# Factor ordering for countries
shock_pch$NAME_LATN <- factor(shock_pch$NAME_LATN,
                              levels = sort(unique(shock_pch$NAME_LATN), decreasing = TRUE))


#------------------------------------------
# SAVE 
setwd(shocks)

write.xlsx(shock_pch, "all_shocks_2070_sensitivity_EU27.xlsx")
saveRDS(shock_pch, "all_shocks_2070_sensitivity_EU27.rds")


 



