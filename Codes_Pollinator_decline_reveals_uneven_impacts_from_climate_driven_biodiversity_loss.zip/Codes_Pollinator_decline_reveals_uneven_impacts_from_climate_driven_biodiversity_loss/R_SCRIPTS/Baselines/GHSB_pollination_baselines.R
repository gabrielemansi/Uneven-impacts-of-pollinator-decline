#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# This file produces pollination potential projections and % changes. 
# Pollination potential projections are generated starting from INCA_2000_2080 data with climate change shock from ghisbian et al., 2024,
# i.e. the % change in average pollinator presence under different climate scenarios (rcp2.6; rcp6.0; rcp8.5) and land use trajectories (SSPs 1,3,5)
 
# Output files:
# GHSB_SSPs_pct_change_2020_2080.tif = GHSB 5 years shock on pollination probability (5y % increase) NOT cumulative in each SSPsate scenario due to SSPs
# GHSB_SSPs_pct_cum_2020_2080.tif : GHSB 5 years shock of pollination probability (5y % increase) CUMULATIVE (y3= y1+y2) in each RCP wrt 2020

# GHSB_SSPs_INCA_poll_potent_2020_2080.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080 baseline with SSPsate shocks (RCP scenarios)
# GHSB_SSPs_INCA_pct_2020_2080.tif: Shock on pollination potential due to SSPsate (under RCP scenarios) as % change respect to baseline INCA_2020_2080 value in the same year
# GHSB_SSPs_INCA_cum_2020_2080.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios

# GHSB_SSPs_INCA_poll_pot_2020_2080_policy.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080_policy baseline with SSPs shocks (RCP scenarios)
# GHSB_SSPs_INCA_pct_2020_2080_policy.tif: Shock on pollination potential due to SSPsate (under RCP scenarios) as % change respect to baseline INCA_2020_2080_policy value in the same year
# GHSB_SSPs_INCA_cum_2020_2080_policy.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios and policy applied 

# baselines_pollination_potential_means_2020_2080.xlsx : means of all rasters
# same FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

 
rm(list = ls())  
gc()

# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)

wd = paste0('G:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

Ghisbian_data = paste0(wd, 'POTENTIAL/input_pollination/Ghisbian_data/Transfer')
inca_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/INCA')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')
baselines_pollination = paste0(wd, 'POTENTIAL/baselines_pollination/Ghisbian_SSPs')
output_baselines_nuts  = paste0(wd, '/POTENTIAL/baselines_NUTS/GHSB_SSPs')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Load the INCA_2020_2080 baselines file for baseline pollination potential 

setwd(inca_baselines)


INCA_2020_2080 = rast("INCA_2020_2080.tif")
INCA_2020_2080_policy =rast("INCA_2020_2080_policy.tif")

INCA_2020 = INCA_2020_2080$'2020'

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# A) Load the Ghisbian CLIM probability file for CLIM shoks on pollinators 
setwd(Ghisbian_data)

# Load the Mean Habitat Suitability ( *_mean_suitability.tif | 9 | Average suitability (μ), 0–1. ): Average habitat suitability across all pollinator species. 
# Values range from 0-1, where higher values indicate better habitat conditions.

ESI_hist = rast(c("ESI_raster_2000-2014_t0.tif"))
names(ESI_hist) = c(paste0("ESI_hist_", c('t0')))

RCP26 = rast(c("ESI_raster_2041-2060_SSP1.tif", "ESI_raster_2061-2080_SSP1.tif"))
names(RCP26) = c(paste0("RCP2_6_", c(2060, 2080)))

RCP60 = rast(c("ESI_raster_2041-2060_SSP3.tif", "ESI_raster_2061-2080_SSP3.tif"))
names(RCP60) = c(paste0("RCP6_0_", c(2060, 2080)))

RCP85 = rast(c("ESI_raster_2041-2060_SSP5.tif", "ESI_raster_2061-2080_SSP5.tif"))
names(RCP85) = c(paste0("RCP8_5_", c(2060, 2080)))


mean_probability = c(ESI_hist, RCP26, RCP60, RCP85)
names(mean_probability)

# check data and remove negative values
global_min <- global(mean_probability, fun = "min", na.rm = TRUE)


# Project coordinates INCA 
mean_probability <- project(mean_probability, INCA_2020)
# Resample the SpatRaster to match the resolution and extent of inca_2018
mean_probability <- resample(mean_probability, INCA_2020, method = "bilinear")

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
#save 
setwd(baselines_pollination)
writeRaster(mean_probability, "Ghisbian_mean_probability.tif", overwrite = TRUE)

#--------------------------------------------------------------------------------------------------------------------
# B) Future pollination potential projections based on INCA 2018 with climate change and NO conservation policy
#---------------------------------------------------------------------------------------------------------------
# PROCESS Ghisbian DATA 
# Compute % change in 2060 and 2080 for each scenario 
base_layer <- mean_probability$ESI_hist_t0

# # Compute percent change for RCP 2.6
future_layer <- mean_probability$RCP2_6_2060
pct_change_rcp26_2060 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp26_2060[pct_change_rcp26_2060 == Inf | pct_change_rcp26_2060 == -Inf | is.nan(pct_change_rcp26_2060)] <- NA
names(pct_change_rcp26_2060) <- "pct_change_rcp26_2060"

future_layer <- mean_probability$RCP2_6_2080
pct_change_rcp26_2080 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp26_2080[pct_change_rcp26_2080 == Inf | pct_change_rcp26_2080 == -Inf | is.nan(pct_change_rcp26_2080)] <- NA
names(pct_change_rcp26_2080) <- "pct_change_rcp26_2080"

# # Compute percent change for RCP 6.0
future_layer <- mean_probability$RCP6_0_2060
pct_change_rcp60_2060 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp60_2060[pct_change_rcp60_2060 == Inf | pct_change_rcp60_2060 == -Inf | is.nan(pct_change_rcp60_2060)] <- NA
names(pct_change_rcp60_2060) <- "pct_change_rcp60_2060"

future_layer <- mean_probability$RCP6_0_2080
pct_change_rcp60_2080 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp60_2080[pct_change_rcp60_2080 == Inf | pct_change_rcp60_2080 == -Inf | is.nan(pct_change_rcp60_2080)] <- NA
names(pct_change_rcp60_2080) <- "pct_change_rcp60_2080"

# # Compute percent change for RCP 8.5
future_layer <- mean_probability$RCP8_5_2060
pct_change_rcp85_2060 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp85_2060[pct_change_rcp85_2060 == Inf | pct_change_rcp85_2060 == -Inf | is.nan(pct_change_rcp85_2060)] <- NA
names(pct_change_rcp85_2060) <- "pct_change_rcp85_2060"

future_layer <- mean_probability$RCP8_5_2080
pct_change_rcp85_2080 <- (future_layer - base_layer) / base_layer * 100
pct_change_rcp85_2080[pct_change_rcp85_2080 == Inf | pct_change_rcp85_2080 == -Inf | is.nan(pct_change_rcp85_2080)] <- NA
names(pct_change_rcp85_2080) <- "pct_change_rcp85_2080"

Ghisbian_pct_change_2014_2080 = c(pct_change_rcp26_2060, pct_change_rcp26_2080, pct_change_rcp60_2060, pct_change_rcp60_2080, pct_change_rcp85_2060, pct_change_rcp85_2080)

# save
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
#save 
writeRaster(Ghisbian_pct_change_2014_2080, "Ghisbian_pct_change_2014_2080.tif", overwrite = TRUE)

 
######
# CREATE RASTER WITH ANNUAL % CHANGE FOR EACH RCPs from 2020 to 2080  
# The Ghisbian baseline reflect 2000/2014 values, and the percentage change values for 2050 and 2080 reflect changes from 2015.

# Loops through the three climate scenarios (RCP2_6, RCP6_0, RCP8_5).
# Applies the exponential decay formula to match the changes in 2060 and 2080 based on the provided percentage changes.
# Computes the decay rates (r) for each pixel. 


# Extract the layers for each RCP scenario (2050 and 2080)
rcp_2060 <- Ghisbian_pct_change_2014_2080[[c(1, 3, 5)]]  # Layers for 2060
rcp_2080 <- Ghisbian_pct_change_2014_2080[[c(2, 4, 6)]]  # Layers for 2080

# Calculate the 5-year changes from 2015 to 2050 (linear interpolation)
change_2015_2060 <- rcp_2060 / 9  # 9 intervals of 5 years between 2015 and 2060
# Calculate the 5-year changes from 2050 to 2080 (linear interpolation)
change_2060_2080 <- (rcp_2080 - rcp_2060) / 4  # 4 intervals of 5 years between 2060 and 2080
# Combine the changes to create a final raster with linear trends
five_year_pct_change <- c(change_2015_2060, change_2060_2080)

 
# RCP2.6
base_layer <- five_year_pct_change[["pct_change_rcp26_2060"]] # Estrai il layer "pct_change_CLIM.RCP2_6_2050" come base 
CLIM_RCP_2_6_2020_2080 <- rep(base_layer, 13) # Crea un raster per gli anni dal 2025 al 2080 
# assegno valori 
CLIM_RCP_2_6_2020_2080[[1]]= setValues(CLIM_RCP_2_6_2020_2080[[1]], 0)
CLIM_RCP_2_6_2020_2080[[2:9]]= rep(five_year_pct_change[["pct_change_rcp26_2060"]], 8)
CLIM_RCP_2_6_2020_2080[[10:13]]= rep(five_year_pct_change[["pct_change_rcp26_2080"]],4)
names(CLIM_RCP_2_6_2020_2080) <- paste0("RCP2_6_", seq(2020, 2080, 5))
gc()
# RCP6.0
base_layer <- five_year_pct_change[["pct_change_rcp60_2060"]] # Estrai il layer "pct_change_CLIM.RCP6_0_2050" come base 
CLIM_RCP_6_0_2020_2080 <- rep(base_layer, 13) # Crea un raster per gli anni dal 2025 al 2080 
# assegno valori 
CLIM_RCP_6_0_2020_2080[[1]]= setValues(CLIM_RCP_6_0_2020_2080[[1]], 0)
CLIM_RCP_6_0_2020_2080[[2:9]]= rep(five_year_pct_change[["pct_change_rcp60_2060"]], 8)
CLIM_RCP_6_0_2020_2080[[10:13]]= rep(five_year_pct_change[["pct_change_rcp60_2080"]],4)
names(CLIM_RCP_6_0_2020_2080) <- paste0("RCP6_0_", seq(2020, 2080, 5))
gc()
#RCP 8.5
base_layer <- five_year_pct_change[["pct_change_rcp85_2060"]] # Estrai il layer "pct_change_CLIM.RCP8_5_2050" come base 
CLIM_RCP_8_5_2020_2080 <- rep(base_layer, 13) # Crea un raster per gli anni dal 2025 al 2080 
# assegno valori 
CLIM_RCP_8_5_2020_2080[[1]]= setValues(CLIM_RCP_8_5_2020_2080[[1]], 0)
CLIM_RCP_8_5_2020_2080[[2:9]]= rep(five_year_pct_change[["pct_change_rcp85_2060"]], 8)
CLIM_RCP_8_5_2020_2080[[10:13]]= rep(five_year_pct_change[["pct_change_rcp85_2080"]],4)
names(CLIM_RCP_8_5_2020_2080) <- paste0("RCP8_5_", seq(2020, 2080, 5))
gc()


# combine in a single raster
CLIM_pct_change_2020_2080 <- c(CLIM_RCP_2_6_2020_2080,
                               CLIM_RCP_6_0_2020_2080,
                                      CLIM_RCP_8_5_2020_2080)
names(CLIM_pct_change_2020_2080)
CLIM_pct_change_2020_2080 <- app( CLIM_pct_change_2020_2080, fun = function(x) round(x, 2))

gc()

# CREATE RASTER WITH CUMULATIVE % CHANGE FOR EACH RCPs from 2020 to 2080 (CLIM_pct_change_2020_2080)

pct_change_RCP2_6 <- CLIM_pct_change_2020_2080[[grep("RCP2_6", names(CLIM_pct_change_2020_2080))]]
pct_change_RCP6_0 <- CLIM_pct_change_2020_2080[[grep("RCP6_0", names(CLIM_pct_change_2020_2080))]]
pct_change_RCP8_5 <- CLIM_pct_change_2020_2080[[grep("RCP8_5", names(CLIM_pct_change_2020_2080))]]

shock_cum_RCP2_6 <- app(pct_change_RCP2_6, fun = cumsum)
shock_cum_RCP6_0 <- app(pct_change_RCP6_0, fun = cumsum)
shock_cum_RCP8_5 <- app(pct_change_RCP8_5, fun = cumsum)

CLIM_pct_cumulative_2020_2080= c(shock_cum_RCP2_6, shock_cum_RCP6_0, shock_cum_RCP8_5)
CLIM_pct_cumulative_2020_2080 <- app( CLIM_pct_cumulative_2020_2080, fun = function(x) round(x, 2))

 
#################
# CREATE POLLINATION POTENTIAL PROJECTIONS FROM 2020 TO 2080 FOR EACH RCPs 
# Future pollination potential projections based on INCA 2018 with climate change and NO CONSERVATION POLICY

INCA_RCP_2_6_2020_2080 <-  (1 + shock_cum_RCP2_6 / 100) * INCA_2020_2080 
INCA_RCP_6_0_2020_2080 <-  (1 + shock_cum_RCP6_0 / 100) * INCA_2020_2080 
INCA_RCP_8_5_2020_2080 <-  (1 + shock_cum_RCP8_5 / 100) * INCA_2020_2080

gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_RCP_2_6_2020_2080 <- clamp(INCA_RCP_2_6_2020_2080, lower = 0, upper = 1)
INCA_RCP_6_0_2020_2080 <- clamp(INCA_RCP_6_0_2020_2080, lower = 0, upper = 1)
INCA_RCP_8_5_2020_2080 <- clamp(INCA_RCP_8_5_2020_2080, lower = 0, upper = 1)

INCA_CLIM_pollination_potential_2020_2080 <- c(INCA_RCP_2_6_2020_2080,
                                     INCA_RCP_6_0_2020_2080,
                                     INCA_RCP_8_5_2020_2080)

names(INCA_CLIM_pollination_potential_2020_2080)
INCA_CLIM_pollination_potential_2020_2080 <- app( INCA_CLIM_pollination_potential_2020_2080, fun = function(x) round(x, 2))


#----------------------------------
#################   
#  CLIMATE  % SHOCK ON POLLINATION POTENTIAL RESPECT TO BASELINE
# It measure the shock that baseline pollination potential will obtain under climate change respect to baseline

pct_change_RCP2_6 <- (INCA_RCP_2_6_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP6_0 <- (INCA_RCP_6_0_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP8_5 <- (INCA_RCP_8_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
INCA_CLIM_pct_change_2020_2080 <- c(pct_change_RCP2_6, pct_change_RCP6_0, pct_change_RCP8_5)

INCA_CLIM_pct_change_2020_2080 <- app( INCA_CLIM_pct_change_2020_2080, fun = function(x) round(x, 2))


# Calcola la variazione percentuale di ogni layer rispetto al base 2020
base_2020 <- INCA_2020_2080[[1]]

INCA_CLIM_pct_cumulative_2020_2080 <- (INCA_CLIM_pollination_potential_2020_2080 - base_2020) / base_2020 * 100
INCA_CLIM_pct_cumulative_2020_2080 <- app(INCA_CLIM_pct_cumulative_2020_2080, fun = function(x) round(x, 2))


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

##  save 
setwd(baselines_pollination)
writeRaster(CLIM_pct_change_2020_2080, "GHSB_SSPs_pct_change_2020_2080.tif", overwrite = TRUE)
writeRaster(CLIM_pct_cumulative_2020_2080, "GHSB_SSPs_pct_cum_2020_2080.tif", overwrite = TRUE)

writeRaster(INCA_CLIM_pollination_potential_2020_2080, "GHSB_SSPs_INCA_poll_potent_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_CLIM_pct_change_2020_2080, "GHSB_SSPs_INCA_pct_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_CLIM_pct_cumulative_2020_2080, "GHSB_SSPs_INCA_cum_2020_2080.tif", overwrite = TRUE)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# C) Future pollination potential projections based on INCA_2020_2080 with climate change and CONSERVATION POLICY APPLIED 
#---------------------------------------------------------------------------------------------------------------------

# Apply year % shock for each RCPs on INCA 2020_2080 pollination potential under the conservation policy scenario.
gc()
INCA_RCP_2_6_2020_2080_policy <-  (1 + shock_cum_RCP2_6 / 100) * INCA_2020_2080_policy 
INCA_RCP_6_0_2020_2080_policy <-  (1 + shock_cum_RCP6_0 / 100) * INCA_2020_2080_policy 
INCA_RCP_8_5_2020_2080_policy <-  (1 + shock_cum_RCP8_5 / 100) * INCA_2020_2080_policy
gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_RCP_2_6_2020_2080_policy <- clamp(INCA_RCP_2_6_2020_2080_policy, lower = 0, upper = 1)
INCA_RCP_6_0_2020_2080_policy <- clamp(INCA_RCP_6_0_2020_2080_policy, lower = 0, upper = 1)
INCA_RCP_8_5_2020_2080_policy <- clamp(INCA_RCP_8_5_2020_2080_policy, lower = 0, upper = 1)

INCA_CLIM_pollination_potential_2020_2080_policy <- c(INCA_RCP_2_6_2020_2080_policy,
                                               INCA_RCP_6_0_2020_2080_policy,
                                               INCA_RCP_8_5_2020_2080_policy)

names(INCA_CLIM_pollination_potential_2020_2080_policy)


#################   
#  CLIMATE ANNUAL % SHOCK ON POLLINATION POTENTIAL RESPECT TO 2020 WITH CONSERVATION
# This raster contain the shock to be used when both the climate shock and the conservation policies are active. 
# It measure the shock that baseline pollination potential will obtain under a conservation policy scenario

pct_change_RCP2_6_policy <- (INCA_RCP_2_6_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP6_0_policy <- (INCA_RCP_6_0_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP8_5_policy <- (INCA_RCP_8_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100

INCA_CLIM_pct_change_2020_2080_policy <- c(pct_change_RCP2_6_policy, pct_change_RCP6_0_policy, pct_change_RCP8_5_policy)
INCA_CLIM_pct_change_2020_2080_policy <- app( INCA_CLIM_pct_change_2020_2080_policy, fun = function(x) round(x, 2))

# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_CLIM_pct_cumulative_2020_2080_policy <- (INCA_CLIM_pollination_potential_2020_2080_policy - base_2020) / base_2020 * 100
INCA_CLIM_pct_cumulative_2020_2080_policy <- app(INCA_CLIM_pct_cumulative_2020_2080_policy, fun = function(x) round(x, 2))


#-------------------------------------------------------------------------
# save
writeRaster(INCA_CLIM_pollination_potential_2020_2080_policy, filename = "GHSB_SSPs_INCA_poll_pot_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_CLIM_pct_change_2020_2080_policy, filename = "GHSB_SSPs_INCA_pct_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_CLIM_pct_cumulative_2020_2080_policy, filename = "GHSB_SSPs_INCA_cum_2020_2080_policy.tif", overwrite = TRUE)

 
#-------------------------------------------------------------------------
# CREATE FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 
#-------------------------------------------------------------------------
output_baselines = baselines_pollination
#-------------------------------------------------------------------------
# Load file .shp with NUTS3 boundaries 
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp")   ## Shapefile with NUts 1,2,3 boudaries 
# Rimuovi solo il livello NUTS3, mantieni 0, 1, 2
nuts <- nuts[nuts$LEVL_CODE != 3, ]
cat("Nuts regions retained:", nrow(nuts), "\n")

#------------------------

# Loop over input folders
for (input_path in output_baselines) {
  tif_files <- list.files(input_path, pattern = "GHSB_SSPs_INCA_cum_2020_2080.tif", full.names = TRUE)
  
  for (tif_file in tif_files) {
    # Load raster
    INCA_raster <- rast(tif_file)
    
    # Crop NUTS to raster extent
    nuts_cropped <- crop(nuts, INCA_raster)
    
    # Extract mean values per polygon
    nuts_means <- extract(INCA_raster, nuts_cropped, fun = mean, na.rm = TRUE)
    
    # Remove polygons with NA (no raster coverage)
    valid_idx <- !is.na(nuts_means[,2])
    nuts_cropped <- nuts_cropped[valid_idx, ]
    nuts_means <- nuts_means[valid_idx, ]
    
    # Round the mean values to 2 decimals
    nuts_means[,-1] <- round(nuts_means[,-1], 2)
    
    # Combine with attributes
    INCA_NUTS <- cbind(nuts_cropped, nuts_means[,-1])
    INCA_NUTS_df <- as.data.frame(INCA_NUTS)
    
    # Codici non UE da escludere
    non_eu_codes <- c("AL","BA","CH","LI","MK","RS","TR","UA", "UK")
    # Filtra via i NUTS_ID che iniziano con codici non UE
    INCA_NUTS_df <- INCA_NUTS_df[!substr(INCA_NUTS_df$NUTS_ID, 1, 2) %in% non_eu_codes, ]
    
    #creo valori mean EU 
    eu_vals <- global(INCA_raster, fun = mean, na.rm = TRUE)
    EU_mean <- data.frame(
      NUTS_ID    = "EU",
      LEVL_CODE  = 0,
      CNTR_CODE  = "EU",
      NAME_LATN  = "EU",
      NUTS_NAME  = "EU",
      MOUNT_TYPE = NA,
      URBN_TYPE  = NA,
      COAST_TYPE = NA,
      t(round(eu_vals$mean, 2))
    )
    
    colnames(EU_mean)[9:ncol(EU_mean)] <- rownames(eu_vals)
    rownames(EU_mean) <- NULL
    
    INCA_NUTS_df=rbind(INCA_NUTS_df, EU_mean)
    
    INCA_NUTS_df <- INCA_NUTS_df[, !names(INCA_NUTS_df) %in% 
                                   c("NUTS_NAME", "MOUNT_TYPE", "URBN_TYPE", "COAST_TYPE")]
    
    # Create output subfolder named after the raster file
    base_name <- tools::file_path_sans_ext(basename(tif_file))
    subfolder <- paste0(output_baselines_nuts, "/", base_name)
    dir.create(subfolder, showWarnings = FALSE)
    
    # Save RDS
    saveRDS(INCA_NUTS, paste0(subfolder, "/", base_name, ".rds"))
    
    # Save Excel
    write.xlsx(INCA_NUTS_df, paste0(subfolder, "/", base_name, ".xlsx"))
    
    
    cat("✅ Processed:", base_name, "\n")
  }
} 

#------------------------------ 