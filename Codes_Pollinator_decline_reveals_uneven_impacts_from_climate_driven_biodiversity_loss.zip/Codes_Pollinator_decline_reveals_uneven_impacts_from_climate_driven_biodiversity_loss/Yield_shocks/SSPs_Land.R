# ==============================================================================
# SSPs_Land.R
# ------------------------------------------------------------------------------
# Crop areas and land use under the SSP scenarios, by NUTS region and GTAP
# sector, from the NUTS 2 land use and land cover projections for 2020-2050 of
# Goebel and Britz (2025).
#
# Method
#   Crop areas, used to weight the SSP pollination shocks
#   1. Irrigated and rainfed areas are summed by crop, aggregated from NUTS 2 to
#      NUTS 1 and 0 regions, and matched to the regions of the economic model
#      and to the crops of the pollination shocks; the total crop area of each
#      region is added.
#   2. % change in crop area, cumulative relative to 2020 and over each 5-year
#      step.
#   Land use, for the calibration of the economic model
#   3. Land-use areas are summed by GTAP sector (gro = pdr + wht + gro,
#      ocr = ocr + pfb, Livestock = ctl + pfb + rmk + wol) and in total
#      (Land_tot), aggregated from NUTS 2 to NUTS 1 and 0 regions, and matched
#      to the regions of the economic model; UK regions are removed and the
#      countries outside the model regions and the EU are aggregated into the
#      rest of the world (RoW).
#   4. % change in land use, cumulative relative to 2020, and the corresponding
#      change over each 5-year step.
#   The % changes computed for 2020-2050 are extended to 2080 as
#   x(t) = x(2050) * (1 + (t - 2050) / 30), and values below -99% are set to
#   -99%. PL7, PL8 and PL9 are given the mean of the Polish regions.
#
# Inputs (paths relative to the project root)
#   DEMAND/AREA_crops/SSP_changes/NUTS2 Level Land Use and Land Cover Quantification/
#     LULC_NUTS2_AllSSPs.xlsx
#   DEMAND/AREA_crops/SSP_changes/SSPs_land_use_data_expl.xlsx (sheet "crops")
#   DEMAND/AREA_crops/Shocks_GTAP_match.xlsx
#   DEMAND/AREA_crops/Final_pollination_shocks_GTAP.xlsx
#
# Outputs
#   DEMAND/AREA_crops/SSP_changes/NUTS2 Level Land Use and Land Cover Quantification/
#     NUTS2_AllSSPs_sum.xlsx
#       crop areas by NUTS 2 region
#     Land_Use_SSPs_0_2.xlsx
#       crop areas by NUTS 0-2 region
#     NUTS2_AllSSPs_GTAP.xlsx
#       crop areas for the regions of the economic model
#     Calib_land_use_SSP_match_sum.xlsx
#       land use by GTAP sector and NUTS 2 region
#   DEMAND/AREA_crops/SSP_changes/data_final/crops_land_use/
#     Crops_Land_Use_SSPs_GTAP.xlsx and .csv
#       areas of the crops of the pollination shocks and total crop area
#     Crops_Land_Use_SSPs_GTAP_cum.xlsx and .csv
#       cumulative % change in crop area relative to 2020, 2020-2080
#     Crops_Land_Use_SSPs_GTAP_5y.xlsx and .csv
#       % change in crop area over each 5-year step, 2020-2080
#     Crops_Land_Use_SSPs_GTAP_cum_WIDE and _5y_WIDE (.xlsx and .csv)
#       same, one column per scenario and year
#   DEMAND/AREA_crops/SSP_changes/data_final/land_use_cali/
#     Calib_Land_Use_SSPs_GTAP.xlsx and .csv
#       land use by GTAP sector, for the regions of the economic model and RoW
#     Calib_Land_Use_SSPs_GTAP_cum.xlsx and .csv
#       cumulative % change in land use relative to 2020, 2020-2080
#     Calib_Land_Use_SSPs_GTAP_cum_5y.xlsx and .csv
#       % change in land use over each 5-year step, 2020-2080
#
# Independent of the pollination scripts. Run before the SSP shocks scripts
# (IIASA_SSPs_, GHSB_SSPs_ and Prestele_SSPs_pollination_shocks.R).
# ==============================================================================

library(dplyr)
library(tidyr)
library(stringr)
library(openxlsx)

# Paths ------------------------------------------------------------------------

base_dir <- "."  # project root (POLLINATION folder)

area_dir      <- file.path(base_dir, "DEMAND", "AREA_crops")
ssp_dir       <- file.path(area_dir, "SSP_changes")
lulc_dir      <- file.path(ssp_dir, "NUTS2 Level Land Use and Land Cover Quantification")
crops_out_dir <- file.path(ssp_dir, "data_final", "crops_land_use")
calib_out_dir <- file.path(ssp_dir, "data_final", "land_use_cali")

lulc_file       <- file.path(lulc_dir, "LULC_NUTS2_AllSSPs.xlsx")
sector_map_file <- file.path(ssp_dir, "SSPs_land_use_data_expl.xlsx")
gtap_match_file <- file.path(area_dir, "Shocks_GTAP_match.xlsx")
regions_file    <- file.path(area_dir, "Final_pollination_shocks_GTAP.xlsx")

dir.create(crops_out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(calib_out_dir, recursive = TRUE, showWarnings = FALSE)

# Settings ---------------------------------------------------------------------

years      <- c("2020", "2025", "2030", "2035", "2040", "2045", "2050")
years_2080 <- c(years, "2055", "2060", "2065", "2070", "2075", "2080")

# Country codes of the land-use data recoded to NUTS codes
iso3_to_nuts <- c(mlt = "MT", bgr = "BG", cyp = "CY", cze = "CZ", dnk = "DK", est = "EE",
                  fin = "FI", hrv = "HR", hun = "HU", irl = "IE", ltu = "LT", lux = "LU",
                  lva = "LV", svk = "SK", svn = "SI")

# Codes excluded from the rest of the world
eu_codes <- c(
  # EU countries, ISO2
  "AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GR", "HR", "HU",
  "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PL", "PT", "RO", "SE", "SI", "SK",
  # EU countries, ISO3
  "AUT", "BEL", "BGR", "CYP", "CZE", "DEU", "DNK", "EST", "ESP", "FIN", "FRA", "GRC",
  "HRV", "HUN", "IRL", "ITA", "LTU", "LUX", "LVA", "MLT", "NLD", "POL", "PRT", "ROU",
  "SWE", "SVN", "SVK",
  # NUTS 1 codes without digits (France, Italy, Turkey)
  "FRB", "FRC", "FRD", "FRE", "FRF", "FRG", "FRH", "FRI", "FRJ", "FRK", "FRL", "FRM",
  "ITC", "ITF", "ITG", "ITH", "ITI",
  "TRA", "TRB", "TRC")

# GTAP sectors summed into gro, ocr and Livestock
grouped_sectors <- c("pdr", "wht", "gro", "ocr", "pfb", "ctl", "rmk", "wol")

# Scenarios and sectors of the land-use tables for the economic model
calib_scenarios <- c("SSP1", "SSP4", "SSP3", "SSP2", "SSP5")
calib_sectors   <- c("frs", "c_b", "v_f", "gro", "osd", "ocr", "Livestock", "Land_tot")

# Functions --------------------------------------------------------------------

# Recode country codes to NUTS codes and convert all codes to upper case
recode_nuts <- function(x, map) {
  i <- x %in% names(map)
  x[i] <- unname(map[x[i]])
  str_to_upper(x)
}

# Aggregate to the first n characters of the NUTS code (2: NUTS 0, 3: NUTS 1):
# crop areas
aggregate_crops <- function(df, n) {
  df %>%
    mutate(NUTS_ID = str_sub(NUTS_ID, 1, n)) %>%
    group_by(Scenario, LandCover, Land_Use, NUTS_ID) %>%
    summarise(across(`2020`:`2050`, sum), .groups = "drop")
}

# Same, land use by GTAP sector
aggregate_land_use <- function(df, n) {
  df %>%
    mutate(NUTS_ID = str_sub(NUTS_ID, 1, n)) %>%
    group_by(Scenario, NUTS_ID, GTAP_11_sector) %>%
    summarise(across(`2020`:`2050`, sum), .groups = "drop")
}

# Land use of a group of GTAP sectors, by scenario and region
sum_sectors <- function(df, sectors, label) {
  df %>%
    group_by(Scenario, Region) %>%
    summarise(across(`2020`:`2050`, ~ sum(.x[GTAP_11_sector %in% sectors])),
              .groups = "drop") %>%
    mutate(GTAP_11_sector = label)
}

# Extend % changes to 2080, x(t) = x(2050) * (1 + (t - 2050) / 30), and set
# values below -99% to -99%
extend_to_2080 <- function(df) {
  df %>%
    mutate(slope  = `2050` / 30,
           `2055` = `2050` + slope * 5,
           `2060` = `2050` + slope * 10,
           `2065` = `2050` + slope * 15,
           `2070` = `2050` + slope * 20,
           `2075` = `2050` + slope * 25,
           `2080` = `2050` + slope * 30) %>%
    mutate(across(all_of(years_2080[-1]), ~ pmax(.x, -99))) %>%
    select(-slope)
}

# Cumulative % change relative to 2020, extended to 2080 and rounded
cumulative_change <- function(df) {
  df %>%
    mutate(base_2020 = `2020`) %>%
    mutate(across(`2020`:`2050`,
                  ~ ifelse(base_2020 == 0, 0, (.x - base_2020) / base_2020 * 100))) %>%
    mutate(`2020` = 0) %>%
    extend_to_2080() %>%
    select(-base_2020) %>%
    mutate(across(where(is.numeric), ~ round(.x, 2)))
}

# Add PL7, PL8 and PL9 to a crop table, as the mean of the Polish regions
add_pl_regions <- function(df) {
  pl <- df %>%
    filter(str_starts(NUTS_ID, "PL")) %>%
    group_by(Land_Use, shock_crop_names, GTAP_number, GTAP.11, GTAP.11.description,
             Avg_impact_on_production, LEVL_CODE, Scenario) %>%
    summarise(across(where(is.numeric), ~ mean(.x, na.rm = TRUE)), .groups = "drop")
  bind_rows(df,
            mutate(pl, NUTS_ID = "PL7"),
            mutate(pl, NUTS_ID = "PL8"),
            mutate(pl, NUTS_ID = "PL9")) %>%
    mutate(ICES_Reg_region_ACCREU = case_when(NUTS_ID == "PL7" ~ "CentrePol",
                                              NUTS_ID == "PL8" ~ "EastPol",
                                              NUTS_ID == "PL9" ~ "Masovia",
                                              TRUE ~ ICES_Reg_region_ACCREU)) %>%
    distinct()
}

# One column per scenario and year
to_wide <- function(df) {
  df %>%
    pivot_longer(all_of(years_2080), names_to = "Year", values_to = "Value") %>%
    mutate(Scenario_Year = paste0(Scenario, "_", Year)) %>%
    select(-Scenario, -Year) %>%
    pivot_wider(names_from = Scenario_Year, values_from = Value, values_fn = first)
}

# Save a table as .xlsx and .csv
save_xlsx_csv <- function(df, path_stem) {
  write.xlsx(df, paste0(path_stem, ".xlsx"))
  write.csv(df, paste0(path_stem, ".csv"))
}

# 1. Inputs --------------------------------------------------------------------

lulc       <- read.xlsx(lulc_file)
sector_map <- read.xlsx(sector_map_file, sheet = "crops")  # land-use class to GTAP sector
gtap_match <- read.xlsx(gtap_match_file)
regions    <- read.xlsx(regions_file)[, 1:3]               # regions of the economic model

# 2. Crop areas by NUTS 0-2 region ---------------------------------------------

# Irrigated and rainfed areas summed by crop
crops_nuts2 <- lulc %>%
  mutate(Land_Use = str_remove(as.character(LandUse), "(_irr-a|_rai-a|-a)$"),
         Region   = str_remove(Region, "0000$")) %>%
  group_by(Scenario, Region, LandCover, Land_Use) %>%
  summarise(across(`2020`:`2050`, sum), .groups = "drop")
crops_nuts2 <- crops_nuts2[, c("Scenario", "Region", "LandCover", "Land_Use", years)]

write.xlsx(crops_nuts2, file.path(lulc_dir, "NUTS2_AllSSPs_sum.xlsx"))

crops_nuts <- crops_nuts2 %>%
  rename(NUTS_ID = Region) %>%
  mutate(NUTS_ID = recode_nuts(NUTS_ID, iso3_to_nuts))
crops_nuts <- bind_rows(crops_nuts, aggregate_crops(crops_nuts, 2),
                        aggregate_crops(crops_nuts, 3)) %>%
  distinct()

crops_regions <- merge(regions, crops_nuts, by = "NUTS_ID", all.x = TRUE)
num_cols <- sapply(crops_regions, is.numeric)
crops_regions[num_cols] <- lapply(crops_regions[num_cols], round, 2)

write.xlsx(crops_nuts, file.path(lulc_dir, "Land_Use_SSPs_0_2.xlsx"))
write.xlsx(crops_regions, file.path(lulc_dir, "NUTS2_AllSSPs_GTAP.xlsx"))

# 3. Areas of the crops of the pollination shocks ------------------------------

crops_gtap <- merge(gtap_match, crops_regions, by = "Land_Use", all.x = TRUE)

# Total crop area of each region
crops_total <- crops_gtap %>%
  select(-LandCover) %>%
  group_by(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, Scenario) %>%
  summarise(across(where(is.numeric), ~ sum(.x, na.rm = TRUE)), .groups = "drop") %>%
  mutate(Land_Use                 = "total",
         shock_crop_names         = "total",
         GTAP_number              = 0,
         GTAP.11                  = "crops",
         GTAP.11.description      = "crops",
         Avg_impact_on_production = NA)

crops_gtap <- bind_rows(select(crops_gtap, -LandCover), crops_total) %>%
  filter(!is.na(Scenario))

save_xlsx_csv(crops_gtap, file.path(crops_out_dir, "Crops_Land_Use_SSPs_GTAP"))

# 4. Cumulative % change in crop area relative to 2020 -------------------------

crops_cum <- crops_gtap %>%
  cumulative_change() %>%
  add_pl_regions()

save_xlsx_csv(crops_cum, file.path(crops_out_dir, "Crops_Land_Use_SSPs_GTAP_cum"))
save_xlsx_csv(to_wide(crops_cum),
              file.path(crops_out_dir, "Crops_Land_Use_SSPs_GTAP_cum_WIDE"))

# 5. % change in crop area over each 5-year step -------------------------------

crops_5y <- crops_gtap
for (i in 2:length(years)) {
  previous <- crops_gtap[[years[i - 1]]]
  crops_5y[[years[i]]] <- ifelse(previous == 0, 0,
                                 (crops_gtap[[years[i]]] - previous) / previous * 100)
}
crops_5y$`2020` <- 0

crops_5y <- crops_5y %>%
  extend_to_2080() %>%
  mutate(across(where(is.numeric), ~ round(.x, 2))) %>%
  add_pl_regions()

save_xlsx_csv(crops_5y, file.path(crops_out_dir, "Crops_Land_Use_SSPs_GTAP_5y"))
save_xlsx_csv(to_wide(crops_5y),
              file.path(crops_out_dir, "Crops_Land_Use_SSPs_GTAP_5y_WIDE"))

# 6. Land use by GTAP sector and NUTS 0-2 region -------------------------------

land_use <- lulc %>%
  filter(str_to_lower(LandUse) != "total") %>%
  mutate(Land_Use = str_remove(as.character(LandUse), "(-a)$"),
         Region   = str_remove(Region, "0000$")) %>%
  group_by(Scenario, Region, LandCover, Land_Use) %>%
  summarise(across(`2020`:`2050`, sum), .groups = "drop")
land_use <- land_use[, c("Scenario", "Region", "LandCover", "Land_Use", years)]

land_use <- merge(sector_map, land_use, by = "Land_Use") %>%
  select(-LandCover, -Explanation, -Land_Use) %>%
  group_by(Scenario, Region, GTAP_11_sector) %>%
  summarise(across(`2020`:`2050`, ~ sum(.x, na.rm = TRUE)), .groups = "drop")
land_use <- land_use[, c("Scenario", "Region", "GTAP_11_sector", years)]

# gro = pdr + wht + gro, ocr = ocr + pfb, Livestock = ctl + pfb + rmk + wol
land_use <- bind_rows(
  filter(land_use, !GTAP_11_sector %in% grouped_sectors),
  sum_sectors(land_use, c("pdr", "wht", "gro"), "gro"),
  sum_sectors(land_use, c("ocr", "pfb"), "ocr"),
  sum_sectors(land_use, c("ctl", "pfb", "rmk", "wol"), "Livestock")
)

# Total land use (Land_tot)
land_use_total <- land_use %>%
  group_by(Scenario, Region) %>%
  summarise(across(where(is.numeric), ~ sum(.x, na.rm = TRUE)), .groups = "drop") %>%
  mutate(GTAP_11_sector = "Land_tot")

land_use <- bind_rows(land_use_total, land_use) %>%
  select(Scenario, NUTS_ID = Region, GTAP_11_sector, all_of(years))

write.xlsx(land_use, file.path(lulc_dir, "Calib_land_use_SSP_match_sum.xlsx"))

# The Slovenian country code (svn) is not recoded here
land_use_nuts <- land_use %>%
  mutate(NUTS_ID = recode_nuts(NUTS_ID, iso3_to_nuts[names(iso3_to_nuts) != "svn"]))

# Where a code appears more than once (NUTS 0 duplicates), the row with the
# largest 2020 value is kept
land_use_nuts <- bind_rows(land_use_nuts, aggregate_land_use(land_use_nuts, 2),
                           aggregate_land_use(land_use_nuts, 3)) %>%
  distinct() %>%
  group_by(Scenario, NUTS_ID, GTAP_11_sector) %>%
  slice_max(`2020`, n = 1, with_ties = FALSE) %>%
  ungroup()

# 7. Land use for the regions of the economic model and RoW --------------------

rest_of_world <- land_use_nuts %>%
  filter(!grepl("[0-9]", NUTS_ID)) %>%
  anti_join(regions, by = "NUTS_ID") %>%
  filter(!NUTS_ID %in% eu_codes) %>%
  group_by(Scenario, GTAP_11_sector) %>%
  summarise(across(`2020`:`2050`, ~ sum(.x, na.rm = TRUE)), .groups = "drop") %>%
  mutate(NUTS_ID = "RoW") %>%
  select(all_of(names(land_use_nuts)))

# UK regions are removed, as they were duplicated
land_use_regions <- merge(regions, land_use_nuts, by = "NUTS_ID", all.x = TRUE) %>%
  filter(!grepl("^UK", NUTS_ID)) %>%
  bind_rows(rest_of_world)
land_use_regions[is.na(land_use_regions)] <- 0

save_xlsx_csv(land_use_regions, file.path(calib_out_dir, "Calib_Land_Use_SSPs_GTAP"))

# 8. Cumulative % change in land use relative to 2020 --------------------------

land_use_cum <- cumulative_change(land_use_regions)

# PL7, PL8 and PL9 as the mean of the Polish regions
pl <- land_use_cum %>%
  filter(str_starts(NUTS_ID, "PL")) %>%
  filter(if_all(where(is.numeric), ~ !is.na(.x))) %>%
  group_by(Scenario, GTAP_11_sector) %>%
  summarise(across(where(is.numeric), ~ mean(.x, na.rm = TRUE)), .groups = "drop")

land_use_cum <- bind_rows(
  land_use_cum,
  mutate(pl, NUTS_ID = "PL7", LEVL_CODE = 1, ICES_Reg_region_ACCREU = "CentrePol"),
  mutate(pl, NUTS_ID = "PL8", LEVL_CODE = 1, ICES_Reg_region_ACCREU = "EastPol"),
  mutate(pl, NUTS_ID = "PL9", LEVL_CODE = 1, ICES_Reg_region_ACCREU = "Masovia")
) %>%
  distinct()
land_use_cum[is.na(land_use_cum)] <- 0

# All combinations of regions, scenarios and sectors
grid <- expand.grid(NUTS_ID          = c(regions$NUTS_ID, "RoW"),
                    Scenario         = calib_scenarios,
                    GTAP_11_sector   = calib_sectors,
                    stringsAsFactors = FALSE)
grid <- merge(grid, regions, by = "NUTS_ID", all.x = TRUE)
grid[is.na(grid)] <- 0

land_use_cum <- merge(grid, land_use_cum, all.x = TRUE)

save_xlsx_csv(land_use_cum, file.path(calib_out_dir, "Calib_Land_Use_SSPs_GTAP_cum"))

# 9. % change in land use over each 5-year step --------------------------------

# Change between consecutive years of the cumulative index 1 + change / 100
land_use_5y <- land_use_cum %>%
  pivot_longer(matches("^20\\d{2}$"), names_to = "year", values_to = "shock_cum") %>%
  mutate(year  = as.integer(year),
         index = 1 + shock_cum / 100) %>%
  arrange(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, Scenario, GTAP_11_sector, year) %>%
  group_by(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, Scenario, GTAP_11_sector) %>%
  mutate(shock_5y = (index / lag(index) - 1) * 100) %>%
  ungroup() %>%
  mutate(shock_5y = round(if_else(year == 2020, 0, shock_5y), 2)) %>%
  select(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, Scenario, GTAP_11_sector, year,
         shock_5y) %>%
  pivot_wider(names_from = year, values_from = shock_5y) %>%
  arrange(NUTS_ID, Scenario, GTAP_11_sector)
land_use_5y[is.na(land_use_5y)] <- 0

save_xlsx_csv(land_use_5y, file.path(calib_out_dir, "Calib_Land_Use_SSPs_GTAP_cum_5y"))
