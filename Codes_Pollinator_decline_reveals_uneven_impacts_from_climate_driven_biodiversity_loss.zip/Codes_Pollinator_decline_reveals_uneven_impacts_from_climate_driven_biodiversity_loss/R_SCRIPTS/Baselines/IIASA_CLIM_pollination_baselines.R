#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# This file produces pollination potential projections and % shocks.
# Pollination potential projections are generated starting from INCA_2000_2080 data. 
# A climate change shock is then applied based on IIASA data,
# estimating the % change in average pollinator presence under 4 different climate scenarios (rcp2.6; rcp4.5; rcp7.0; rcp8.5).
# These changes are derived from the climate_only experiment.
 
# Output files:
# IIASA_CLIM_mean_prob_all_species.tif : mean pollinators probability under climate change scenarios from IIASA climate_only experiment
# IIASA_CLIM_pct_change_2020_2080.tif = IIASA 5 years shock on pollination probability (5y % increase) NOT cumulative in each RCP scenario due to CLIM
# IIASA_CLIM_pct_cum_2020_2080.tif : IIASA 5 years shock of pollination probability (5y % increase) CUMULATIVE (y3= y1+y2) in each CLIM RCP wrt 2020

# IIASA_CLIM_INCA_poll_potent_2020_2080.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080 baseline with CLIM shocks (RCP scenarios)
# IIASA_CLIM_INCA_pct_2020_2080.tif: Shock on pollination potential due to climate (under RCP scenarios) as % change respect to baseline INCA_2020_2080 value in the same year
# IIASA_CLIM_INCA_cum_2020_2080.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios

# IIASA_CLIM_INCA_poll_pot_2020_2080_policy.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080_policy baseline with CLIM shocks (RCP scenarios)
# IIASA_CLIM_INCA_pct_2020_2080_policy.tif: Shock on pollination potential due to climate (under RCP scenarios) as % change respect to baseline INCA_2020_2080_policy value in the same year
# IIASA_CLIM_INCA_cum_2020_2080_policy.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios and policy applied 

# baselines_pollination_potential_means_2020_2080.xlsx : means of all rasters
# same FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 

 
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

rm(list = ls())  
gc()

# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)

wd = paste0('G:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

INCA_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/INCA')
IIASA_data = paste0(wd, 'POTENTIAL/input_pollination/IIASA_data/03_climate_only_pollinators/')
output_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/IIASA_CLIM/')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')
output_baselines_nuts  = paste0(wd, '/POTENTIAL/baselines_NUTS/IIASA_CLIM/')

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Load the INCA_2020_2080 baselines
setwd(INCA_baselines)
INCA_2020_2080 =  rast("INCA_2020_2080.tif")
INCA_2020_2080_policy=  rast("INCA_2020_2080_policy.tif")
INCA_2020 = INCA_2020_2080$`2020`
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
gc()
#--------------------------------------------------------------------------------------------------------------------
# A) Future pollination potential projections based on INCA 2018 with IIASA change and NO conservation policy
#---------------------------------------------------------------------------------------------------------------
# PROCESS IIASA DATA 
setwd(IIASA_data)

# Load the Mean Habitat Suitability ( *_mean_suitability.tif | 9 | Average suitability (μ), 0–1. ): Average habitat suitability across all pollinator species. 
# Values range from 0-1, where higher values indicate better habitat conditions.
RCP26 = rast("EnsembleProjection_biome_dispersal_ssp126_climate_only_mean_suitability.tif")
names(RCP26) = c(paste0("RCP2_6_", c(2015, 2025, 2035, 2045, 2055, 2065, 2075, 2085, 2095)))
RCP45 = rast("EnsembleProjection_biome_dispersal_ssp245_climate_only_mean_suitability.tif")
names(RCP45) = c(paste0("RCP4_5_", c(2015, 2025, 2035, 2045, 2055, 2065, 2075, 2085, 2095)))
RCP70 = rast("EnsembleProjection_biome_dispersal_ssp370_climate_only_mean_suitability.tif")
names(RCP70) = c(paste0("RCP7_0_", c(2015, 2025, 2035, 2045, 2055, 2065, 2075, 2085, 2095)))
RCP85 = rast("EnsembleProjection_biome_dispersal_ssp585_climate_only_mean_suitability.tif")
names(RCP85) = c(paste0("RCP8_5_", c(2015, 2025, 2035, 2045, 2055, 2065, 2075, 2085, 2095)))

mean_probability = c(RCP26,  RCP45, RCP70, RCP85)
names(mean_probability)

# check data and remove negative values
global_min <- global(mean_probability, fun = "min", na.rm = TRUE)
mean_probability <- clamp(mean_probability, lower = 0)

# Project coordinates INCA 
mean_probability <- project(mean_probability, INCA_2020)
# Resample the SpatRaster to match the resolution and extent of inca_2018
mean_probability <- resample(mean_probability, INCA_2020, method = "bilinear")

gc()


# Interpolate IIASA data for missing timesteps 

r <- mean_probability
layer_names <- names(r)

# Funzione per calcolare medie tra anni consecutivi
interpolate_means <- function(r, scenario) {
  # Seleziona i layer dello scenario
  sc_layers <- grep(scenario, names(r), value = TRUE)
  sc_r <- r[[sc_layers]]
  # Estrai anni
  sc_years <- as.numeric(sub(".*_(\\d{4})", "\\1", sc_layers))
  new_layers <- list()
  for (i in seq_along(sc_years)[-length(sc_years)]) {
    y1 <- sc_years[i]
    y2 <- sc_years[i+1]
    y_mid <- (y1 + y2) / 2
    
    # Media semplice tra i due raster
    r_mid <- (sc_r[[i]] + sc_r[[i+1]]) / 2
    # Nome coerente
    names(r_mid) <- paste0(scenario, "_", y_mid)
    new_layers[[length(new_layers)+1]] <- r_mid
  }
  # Combina originali + nuovi
  c(sc_r, rast(new_layers))
}
# Scenari
scenarios <- unique(sub("_(\\d{4})", "", layer_names))
# Interpolazione per ciascuno scenario
interp_list <- lapply(scenarios, function(sc) interpolate_means(r, sc))
# Ricomponi tutti gli scenari
r_interp <- rast(interp_list)

# Estrai scenario e anno dai nomi
layer_names <- names(r_interp)
scenarios <- sub("_(\\d{4})", "", layer_names)
years <- as.numeric(sub(".*_(\\d{4})", "\\1", layer_names))
# Ordine: prima scenario, poi anno
ord <- order(scenarios, years)
# Riordina raster
r_interp <- r_interp[[ord]]
names(r_interp)

mean_probability_interp = r_interp


######
# CREATE RASTER WITH ANNUAL % CHANGE FOR EACH RCPs from 2020 to 2080 

# Funzione per calcolare % change anno per anno 
percent_change <- function(r, scenario, start_year = 2020, end_year = 2080) {
  # Seleziona i layer dello scenario
  sc_layers <- grep(scenario, names(r), value = TRUE)
  sc_years <- as.numeric(sub(".*_(\\d{4})", "\\1", sc_layers))
  
  # Filtra intervallo richiesto
  keep <- sc_layers[sc_years >= start_year & sc_years <= end_year]
  sc_r <- r[[keep]]
  
  # Calcola cambiamento % rispetto all'anno precedente
  out_layers <- list()
  for (i in seq_along(keep)) {
    if (i == 1) {
      # Anno base = 0
      out_layers[[i]] <- sc_r[[i]] * 0
    } else {
      prev <- sc_r[[i-1]]
      curr <- sc_r[[i]]
      # % change = (curr - prev)/prev * 100
      change <- (curr - prev) / prev * 100
      
      # Limita la riduzione a -100%
      change[change < -100] <- -100
      
      out_layers[[i]] <- change
    }
    names(out_layers[[i]]) <- keep[i]  # mantieni nome originale
  }
  
  rast(out_layers)
}
gc()

# Applica agli scenari
IIASA_RCP_2_6_2020_2080 <- percent_change(r_interp, "RCP2_6")
IIASA_RCP_4_5_2020_2080 <- percent_change(r_interp, "RCP4_5")
IIASA_RCP_7_0_2020_2080 <- percent_change(r_interp, "RCP7_0")
IIASA_RCP_8_5_2020_2080 <- percent_change(r_interp, "RCP8_5")


# combine in a single raster
IIASA_pct_change_2020_2080 <- c(IIASA_RCP_2_6_2020_2080,
                                      IIASA_RCP_4_5_2020_2080,
                                          IIASA_RCP_7_0_2020_2080,
                                              IIASA_RCP_8_5_2020_2080)

names(IIASA_pct_change_2020_2080)
IIASA_pct_change_2020_2080 <- app( IIASA_pct_change_2020_2080, fun = function(x) round(x, 2))

gc()

# CREATE RASTER WITH CUMULATIVE % CHANGE FOR EACH RCPs from 2020 to 2080 (IIASA_pct_change_2020_2080)

pct_change_RCP2_6 <- IIASA_pct_change_2020_2080[[grep("RCP2_6", names(IIASA_pct_change_2020_2080))]]
pct_change_RCP4_5 <- IIASA_pct_change_2020_2080[[grep("RCP4_5", names(IIASA_pct_change_2020_2080))]]
pct_change_RCP7_0 <- IIASA_pct_change_2020_2080[[grep("RCP7_0", names(IIASA_pct_change_2020_2080))]]
pct_change_RCP8_5 <- IIASA_pct_change_2020_2080[[grep("RCP8_5", names(IIASA_pct_change_2020_2080))]]

shock_cum_RCP2_6 <- app(pct_change_RCP2_6, fun = cumsum)
shock_cum_RCP4_5 <- app(pct_change_RCP4_5, fun = cumsum)
shock_cum_RCP7_0 <- app(pct_change_RCP7_0, fun = cumsum)
shock_cum_RCP8_5 <- app(pct_change_RCP8_5, fun = cumsum)

IIASA_pct_cumulative_2020_2080= c(shock_cum_RCP2_6, shock_cum_RCP4_5,shock_cum_RCP7_0, shock_cum_RCP8_5)
IIASA_pct_cumulative_2020_2080 <- app( IIASA_pct_cumulative_2020_2080, fun = function(x) round(x, 2))

gc()

#################
# CREATE POLLINATION POTENTIAL PROJECTIONS FROM 2020 TO 2080 FOR EACH RCPs 
# Future pollination potential projections based on INCA 2018 with IIASA change and NO CONSERVATION POLICY

INCA_RCP_2_6_2020_2080 <-  (1 + shock_cum_RCP2_6 / 100) * INCA_2020_2080 
INCA_RCP_4_5_2020_2080 <-  (1 + shock_cum_RCP4_5 / 100) * INCA_2020_2080 
INCA_RCP_7_0_2020_2080 <-  (1 + shock_cum_RCP7_0 / 100) * INCA_2020_2080 
INCA_RCP_8_5_2020_2080 <-  (1 + shock_cum_RCP8_5 / 100) * INCA_2020_2080

gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_RCP_2_6_2020_2080 <- clamp(INCA_RCP_2_6_2020_2080, lower = 0, upper = 1)
INCA_RCP_4_5_2020_2080 <- clamp(INCA_RCP_4_5_2020_2080, lower = 0, upper = 1)
INCA_RCP_7_0_2020_2080 <- clamp(INCA_RCP_7_0_2020_2080, lower = 0, upper = 1)
INCA_RCP_8_5_2020_2080 <- clamp(INCA_RCP_8_5_2020_2080, lower = 0, upper = 1)

INCA_IIASA_pollination_potential_2020_2080 <- c(INCA_RCP_2_6_2020_2080,
                                     INCA_RCP_4_5_2020_2080,
                                     INCA_RCP_7_0_2020_2080,
                                     INCA_RCP_8_5_2020_2080)

names(INCA_IIASA_pollination_potential_2020_2080)
INCA_IIASA_pollination_potential_2020_2080 <- app( INCA_IIASA_pollination_potential_2020_2080, fun = function(x) round(x, 2))

gc()

#----------------------------------
#################   
#  IIASA  % SHOCK ON POLLINATION POTENTIAL RESPECT TO BASELINE
# It measure the shock that baseline pollination potential will obtain under IIASA change respect to baseline

pct_change_RCP2_6 <- (INCA_RCP_2_6_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP4_5 <- (INCA_RCP_4_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP7_0 <- (INCA_RCP_7_0_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP8_5 <- (INCA_RCP_8_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
INCA_IIASA_pct_change_2020_2080 <- c(pct_change_RCP2_6, pct_change_RCP4_5, pct_change_RCP7_0, pct_change_RCP8_5)

INCA_IIASA_pct_change_2020_2080 <- app( INCA_IIASA_pct_change_2020_2080, fun = function(x) round(x, 2))


# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_2020 <- INCA_2020_2080[[1]]

INCA_IIASA_pct_cumulative_2020_2080 <- (INCA_IIASA_pollination_potential_2020_2080 - INCA_2020) / INCA_2020 * 100
INCA_IIASA_pct_cumulative_2020_2080 <- app(INCA_IIASA_pct_cumulative_2020_2080, fun = function(x) round(x, 2))


gc()

##  save 
setwd(output_baselines)
writeRaster(mean_probability, "IIASA_CLIM_mean_prob_all_species.tif", overwrite = TRUE)
writeRaster(mean_probability_interp, "IIASA_CLIM_mean_prob_all_species_interp.tif", overwrite = TRUE)
writeRaster(IIASA_pct_change_2020_2080, "IIASA_CLIM_pct_change_2020_2080.tif", overwrite = TRUE)
writeRaster(IIASA_pct_cumulative_2020_2080, "IIASA_CLIM_pct_cum_2020_2080.tif", overwrite = TRUE)

writeRaster(INCA_IIASA_pollination_potential_2020_2080, "IIASA_CLIM_INCA_poll_potent_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_IIASA_pct_change_2020_2080, "IIASA_CLIM_INCA_pct_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_IIASA_pct_cumulative_2020_2080, "IIASA_CLIM_INCA_cum_2020_2080.tif", overwrite = TRUE)


gc()

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# B) Future pollination potential projections based on INCA_2020_2080 with IIASA change and CONSERVATION POLICY APPLIED 
#---------------------------------------------------------------------------------------------------------------------

# Apply year % shock for each RCPs on INCA 2020_2080 pollination potential under the conservation policy scenario.
gc()
INCA_RCP_2_6_2020_2080_policy <-  (1 + shock_cum_RCP2_6 / 100) * INCA_2020_2080_policy 
INCA_RCP_4_5_2020_2080_policy <-  (1 + shock_cum_RCP4_5 / 100) * INCA_2020_2080_policy 
INCA_RCP_7_0_2020_2080_policy <-  (1 + shock_cum_RCP7_0 / 100) * INCA_2020_2080_policy 
INCA_RCP_8_5_2020_2080_policy <-  (1 + shock_cum_RCP8_5 / 100) * INCA_2020_2080_policy
gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_RCP_2_6_2020_2080_policy <- clamp(INCA_RCP_2_6_2020_2080_policy, lower = 0, upper = 1)
INCA_RCP_4_5_2020_2080_policy <- clamp(INCA_RCP_4_5_2020_2080_policy, lower = 0, upper = 1)
INCA_RCP_7_0_2020_2080_policy <- clamp(INCA_RCP_7_0_2020_2080_policy, lower = 0, upper = 1)
INCA_RCP_8_5_2020_2080_policy <- clamp(INCA_RCP_8_5_2020_2080_policy, lower = 0, upper = 1)

INCA_IIASA_pollination_potential_2020_2080_policy <- c(INCA_RCP_2_6_2020_2080_policy,
                                               INCA_RCP_4_5_2020_2080_policy,
                                               INCA_RCP_7_0_2020_2080_policy,
                                               INCA_RCP_8_5_2020_2080_policy)

names(INCA_IIASA_pollination_potential_2020_2080_policy)

gc()

#################   
#  IIASA ANNUAL % SHOCK ON POLLINATION POTENTIAL WITH CONSERVATION
# This raster contain the shock to be used when both the IIASA shock and the conservation policies are active. 
# It measure the shock that baseline pollination potential will obtain under a conservation policy scenario

pct_change_RCP2_6_policy <- (INCA_RCP_2_6_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP4_5_policy <- (INCA_RCP_4_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP7_0_policy <- (INCA_RCP_7_0_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_RCP8_5_policy <- (INCA_RCP_8_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100

INCA_IIASA_pct_change_2020_2080_policy <- c(pct_change_RCP2_6_policy, pct_change_RCP4_5_policy, pct_change_RCP7_0_policy, pct_change_RCP8_5_policy)
INCA_IIASA_pct_change_2020_2080_policy <- app( INCA_IIASA_pct_change_2020_2080_policy, fun = function(x) round(x, 2))

# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_IIASA_pct_cumulative_2020_2080_policy <- (INCA_IIASA_pollination_potential_2020_2080_policy - INCA_2020) / INCA_2020 * 100
INCA_IIASA_pct_cumulative_2020_2080_policy <- app(INCA_IIASA_pct_cumulative_2020_2080_policy, fun = function(x) round(x, 2))


#-----------------------------------------------------------------------------------------
# save
writeRaster(INCA_IIASA_pollination_potential_2020_2080_policy, filename = "IIASA_CLIM_INCA_poll_pot_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_IIASA_pct_change_2020_2080_policy, filename = "IIASA_CLIM_INCA_pct_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_IIASA_pct_cumulative_2020_2080_policy, filename = "IIASA_CLIM_INCA_cum_2020_2080_policy.tif", overwrite = TRUE)

gc()

#-----------------------------------------------------------------------------------------
## some statistics - means

# Function to extract mean values from all layers of a SpatRaster
extract_means <- function(rast_obj, dataset_name) {
  layer_names <- names(rast_obj)
  means <- global(rast_obj, mean, na.rm = TRUE)
  
  # Create data frame
  df <- data.frame(
    Layer = layer_names,
    Mean = round(means[, 1], 5),
    Dataset = dataset_name )
  return(df)}

# Compute mean values

l <- extract_means(IIASA_pct_change_2020_2080, "IIASA_pct_change_2020_2080")
m <- extract_means(INCA_IIASA_pollination_potential_2020_2080, "INCA_IIASA_pollination_potential_2020_2080")
n <- extract_means(IIASA_pct_cumulative_2020_2080, "IIASA_pct_cumulative_2020_2080")
o <- extract_means(INCA_IIASA_pct_change_2020_2080, "INCA_IIASA_pct_change_2020_2080")
p <- extract_means(INCA_IIASA_pollination_potential_2020_2080_policy, "INCA_IIASA_pollination_potential_2020_2080_policy")
q <- extract_means(INCA_IIASA_pct_change_2020_2080_policy, "INCA_IIASA_pct_change_2020_2080_policy")


# Combine and export
means_all <- rbind(l,m,n,o,p,q)

# Save to CSV
write.xlsx(means_all, file = "beselines_pollination_potential_means_2020_2080.xlsx", row.names = FALSE)
write.csv(means_all, file = "beselines_pollination_potential_means_2020_2080.csv", row.names = FALSE)

  
#-------------------------------------------------------------------------
# CREATE FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 
#-------------------------------------------------------------------------
gc()

#-------------------------------------------------------------------------
# Load file .shp with NUTS3 boundaries 
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp")   ## Shapefile with NUts 1,2,3 boudaries 
# Rimuovi solo il livello NUTS3, mantieni 0, 1, 2
nuts <- nuts[nuts$LEVL_CODE != 3, ]
cat("Nuts regions retained:", nrow(nuts), "\n")

#------------------------

# Loop over input folders
for (input_path in output_baselines) {
  tif_files <- list.files(input_path, pattern = "IIASA_CLIM_INCA_cum_2020_2080.tif$", full.names = TRUE)
  
  for (tif_file in tif_files) {
    # Load raster
    INCA_raster <- rast(tif_file)
    
    # Crop NUTS to raster extent
    nuts_cropped <- crop(nuts, INCA_raster)
    
    # Extract mean values per polygon
    nuts_means <- extract(INCA_raster, nuts_cropped, fun = mean, na.rm = TRUE)
    
    # Remove polygons with NA (no raster coverage)
    valid_idx <- !is.na(nuts_means[,2])
    nuts_cropped <- nuts_cropped[valid_idx, ]
    nuts_means <- nuts_means[valid_idx, ]
    
    # Round the mean values to 2 decimals
    nuts_means[,-1] <- round(nuts_means[,-1], 2)
    
    # Combine with attributes
    INCA_NUTS <- cbind(nuts_cropped, nuts_means[,-1])
    INCA_NUTS_df <- as.data.frame(INCA_NUTS)
    
    # Codici non UE da escludere
    non_eu_codes <- c("AL","BA","CH","LI","MK","RS","TR","UA", "UK")
    # Filtra via i NUTS_ID che iniziano con codici non UE
    INCA_NUTS_df <- INCA_NUTS_df[!substr(INCA_NUTS_df$NUTS_ID, 1, 2) %in% non_eu_codes, ]
    
    #creo valori mean EU 
    eu_vals <- global(INCA_raster, fun = mean, na.rm = TRUE)
    EU_mean <- data.frame(
      NUTS_ID    = "EU",
      LEVL_CODE  = 0,
      CNTR_CODE  = "EU",
      NAME_LATN  = "EU",
      NUTS_NAME  = "EU",
      MOUNT_TYPE = NA,
      URBN_TYPE  = NA,
      COAST_TYPE = NA,
      t(round(eu_vals$mean, 2))
    )
    
    colnames(EU_mean)[9:ncol(EU_mean)] <- rownames(eu_vals)
    rownames(EU_mean) <- NULL
    
    INCA_NUTS_df=rbind(INCA_NUTS_df, EU_mean)
    
    INCA_NUTS_df <- INCA_NUTS_df[, !names(INCA_NUTS_df) %in% 
                                   c("NUTS_NAME", "MOUNT_TYPE", "URBN_TYPE", "COAST_TYPE")]
    
    # Create output subfolder named after the raster file
    base_name <- tools::file_path_sans_ext(basename(tif_file))
    subfolder <- paste0(output_baselines_nuts, "/", base_name)
    dir.create(subfolder, showWarnings = FALSE)
    
    # Save RDS
    saveRDS(INCA_NUTS, paste0(subfolder, "/", base_name, ".rds"))
    
    # Save Excel
    write.xlsx(INCA_NUTS_df, paste0(subfolder, "/", base_name, ".xlsx"))
    
    
    cat("✅ Processed:", base_name, "\n")
  }
} 

#------------------------------ 