# This file: 
# 1) load all the crop-specific shocks on FAO CROPGRIDS croplands wrt 2020
# 2) Aggregate them into shocks on GTAP crops category based on each crop weight on total cropland in 2020
#-------------------------------------------------------------------------

 

rm(list = ls())  
gc()


# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)
library(ncdf4)

wd = paste0('D:/Il mio Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
FINAL_SHOCKS = paste0(wd, '/POTENTIAL/baselines_NUTS')
output = paste0(wd, '/POTENTIAL/baselines_NUTS/sensitivity')


#-------------------------------------------------------------------------
# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]
names(crop_dependency)[names(crop_dependency) == "CROPGRIDS"] <- "base_name_crop"

# Import GTAP_sectors ESTAT files and matching files 
setwd(paste0(wd, "/DEMAND/AREA_crops/"))

gtap_file <- file.path(wd, "DEMAND", "AREA_crops", "Row_agg_Accreu.xlsx")
getSheetNames(gtap_file)

GTAP_sectors <- read.xlsx(gtap_file, sheet = "mapping_sectors") 
GTAP_crops <- GTAP_sectors[GTAP_sectors[[4]] == "Crops", ]
GTAP_crops = GTAP_crops[c(1:3)]

Shocks_GTAP_match <- file.path(wd, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
Shocks_GTAP_match = read.xlsx(Shocks_GTAP_match)

final_pollination <- read.xlsx("Final_pollination_shocks_GTAP.xlsx")
final_pollination=final_pollination[c(1:3)]

 
#-------------------------------------------------------------------------


EU27 <- c(
  "AT","BE","BG","CY","CZ","DE","DK","EE","EL","ES",
  "FI","FR","HR","HU","IE","IT","LT","LU","LV","MT",
  "NL","PL","PT","RO","SE","SI","SK", "EU")

country_names <- c(
  AT = "Austria",
  BE = "Belgium",
  BG = "Bulgaria",
  CY = "Cyprus",
  CZ = "Czechia",
  DE = "Germany",
  DK = "Denmark",
  EE = "Estonia",
  EL = "Greece",
  ES = "Spain",
  FI = "Finland",
  FR = "France",
  HR = "Croatia",
  HU = "Hungary",
  IE = "Ireland",
  IT = "Italy",
  LT = "Lithuania",
  LU = "Luxembourg",
  LV = "Latvia",
  MT = "Malta",
  NL = "Netherlands",
  PL = "Poland",
  PT = "Portugal",
  RO = "Romania",
  SE = "Sweden",
  SI = "Slovenia",
  SK = "Slovakia",
  EU = "EU"
)


#------------------------------------------#------------------------------------------#-------------------------------------
# AGGREGAZIONE PER PAESI UE 
#------------------------------------------#------------------------------------------#----------------------------------------
setwd(FINAL_SHOCKS)

Prestele_CLIM_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/Prestele_CLIM/Prestele_CLIM_INCA_cum_2020_2080") 
Prestele_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/Prestele_SSPs/Prestele_SSPs_INCA_cum_2020_2080") 
IIASA_CLIM_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/IIASA_CLIM/IIASA_CLIM_INCA_cum_2020_2080") 
IIASA_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/IIASA_SSPs/IIASA_SSPs_INCA_cum_2020_2080") 
GHSB_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/GHSB_SSPs/GHSB_SSPs_INCA_cum_2020_2080") 
#-------------------------------------------------------------------------

# Definizione scenari come nomi
baselines <- c(
  "IIASA_CLIM_INCA_cum_2020_2080",
  "IIASA_SSPs_INCA_cum_2020_2080",
  "GHSB_SSPs_INCA_cum_2020_2080",
  "Prestele_CLIM_INCA_cum_2020_2080",
  "Prestele_SSPs_INCA_cum_2020_2080"
)

scenarios <- c(
  "IIASA_CLIM",
  "IIASA_SSPs",
  "GHSB_SSPs",
  "Prestele_CLIM",
  "Prestele_SSPs"
)

results <- list()

for (i in seq_along(baselines)) {
  
  b <- baselines[i]      # baseline completo
  s <- scenarios[i]      # etichetta scenario
  
  file_path <- file.path(FINAL_SHOCKS, sub("_INCA.*","",b), b, paste0(b,".xlsx"))
  
  if (!file.exists(file_path)) {
    warning("File mancante: ", file_path)
    next
  }
  
  df <- read.xlsx(file_path)
  
  # Filtri e selezione colonne
  df <- df %>%
    filter(LEVL_CODE == 0) %>%
    dplyr::select(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN,
                  dplyr::contains("2030"),
                  dplyr::contains("2050"),
                  dplyr::contains("2070"))
  
  # sostituisci NAME_LATN con i nomi EU27
  df$CNTR_CODE <- as.character(df$CNTR_CODE)
  df$NAME_LATN <- country_names[df$CNTR_CODE]
  
  # aggiungi colonna scenario
  df$scenario <- s
  
  # rinomina NAME_LATN in CNTR_NAME e riorganizza
  df <- df %>%
    rename(CNTR_NAME = NAME_LATN) %>%
    select(scenario, NUTS_ID, LEVL_CODE, CNTR_NAME, everything(), -CNTR_CODE)
  
  # Se manca MT, aggiungi riga con valori = 0
  if (!"MT" %in% df$NUTS_ID) {
    zero_row <- df[1, ]          # copia struttura
    zero_row$scenario  <- s
    zero_row$NUTS_ID   <- "MT"
    zero_row$LEVL_CODE <- 0
    zero_row$CNTR_NAME <- "Malta"
    zero_row[setdiff(names(zero_row), c("scenario","NUTS_ID","LEVL_CODE","CNTR_NAME"))] <- 0
    df <- rbind(df, zero_row)
  }
  df[is.na(df)] <- 0
  # rinomino colonne SSP -> RCP se presenti
  names(df) <- gsub("SSP", "RCP", names(df))
  
  results[[b]] <- df
}

# Oggetti finali
Prestele_CLIM  <- results[["Prestele_CLIM_INCA_cum_2020_2080"]]
Prestele_SSPs  <- results[["Prestele_SSPs_INCA_cum_2020_2080"]]
IIASA_CLIM     <- results[["IIASA_CLIM_INCA_cum_2020_2080"]]
IIASA_SSPs     <- results[["IIASA_SSPs_INCA_cum_2020_2080"]]
GHSB_SSPs      <- results[["GHSB_SSPs_INCA_cum_2020_2080"]]

#------------------------------------------#------------------------------------------#-------------------------------------
# AGGREGAZIONE PER NUTS
#------------------------------------------#------------------------------------------#----------------------------------------
setwd(FINAL_SHOCKS)

Prestele_CLIM_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/Prestele_CLIM/Prestele_CLIM_INCA_cum_2020_2080") 
Prestele_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/Prestele_SSPs/Prestele_SSPs_INCA_cum_2020_2080") 
IIASA_CLIM_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/IIASA_CLIM/IIASA_CLIM_INCA_cum_2020_2080") 
IIASA_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/IIASA_SSPs/IIASA_SSPs_INCA_cum_2020_2080") 
GHSB_SSPs_INCA_cum_2020_2080 = paste0(FINAL_SHOCKS,"/GHSB_SSPs/GHSB_SSPs_INCA_cum_2020_2080") 
#-------------------------------------------------------------------------

results <- list()

for (i in seq_along(baselines)) {
  
  b <- baselines[i]
  s <- scenarios[i]
  
  file_path <- file.path(FINAL_SHOCKS, sub("_INCA.*","",b), b, paste0(b,".xlsx"))
  
  if (!file.exists(file_path)) {
    warning("File mancante: ", file_path)
    next
  }
  
  df <- read.xlsx(file_path)
  
  # Filtra solo i NUTS_ID presenti in final_pollination
  df <- df %>%
    filter(NUTS_ID %in% unique(final_pollination$NUTS_ID)) %>%
    dplyr::select(NUTS_ID, CNTR_CODE,
                  dplyr::contains("2030"),
                  dplyr::contains("2050"),
                  dplyr::contains("2070")
                  )
  
  df <- merge(final_pollination, df, by = "NUTS_ID", all.x = TRUE)
  df <- df %>%
    rename(CNTR_NAME = ICES_Reg_region_ACCREU) 
  
  # aggiungi colonna scenario
  df$scenario <- s
  # rinomina NAME_LATN in CNTR_NAME e riorganizza
  df <- df %>%
    select(scenario, NUTS_ID, LEVL_CODE, CNTR_NAME, everything(), -CNTR_CODE)
  
  # sostituisci eventuali NA con 0
  df[is.na(df)] <- 0
  
  # rinomina colonne SSP -> RCP se presenti
  names(df) <- gsub("SSP", "RCP", names(df))
  
  results[[b]] <- df
}

# Oggetti finali
Prestele_CLIM_NUTS  <- results[["Prestele_CLIM_INCA_cum_2020_2080"]]
Prestele_SSPs_NUTS  <- results[["Prestele_SSPs_INCA_cum_2020_2080"]]
IIASA_CLIM_NUTS     <- results[["IIASA_CLIM_INCA_cum_2020_2080"]]
IIASA_SSPs_NUTS     <- results[["IIASA_SSPs_INCA_cum_2020_2080"]]
GHSB_SSPs_NUTS      <- results[["GHSB_SSPs_INCA_cum_2020_2080"]]

unique(Prestele_CLIM_NUTS$NUTS_ID)
unique(final_pollination$NUTS_ID)
#------------------------------------------------------------------------------------

Prestele_CLIM  <- rbind(Prestele_CLIM, Prestele_CLIM_NUTS)
Prestele_SSPs  <- rbind(Prestele_SSPs, Prestele_SSPs_NUTS)
IIASA_CLIM     <- rbind(IIASA_CLIM, IIASA_CLIM_NUTS)
IIASA_SSPs     <- rbind(IIASA_SSPs, IIASA_SSPs_NUTS)
GHSB_SSPs      <- rbind(GHSB_SSPs, GHSB_SSPs_NUTS)

#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
PREST_CLIM_2.6 <- Prestele_CLIM[, c(1:4, grep("2_6", names(Prestele_CLIM)))]
PREST_CLIM_2.6$scenario <- "PREST-CLIM 2.6"
names(PREST_CLIM_2.6)[5:7] <- c("2030","2050","2070")

PREST_CLIM_4.5 <- Prestele_CLIM[, c(1:4, grep("4_5", names(Prestele_CLIM)))]
PREST_CLIM_4.5$scenario <- "PREST-CLIM 4.5"
names(PREST_CLIM_4.5)[5:7] <- c("2030","2050","2070")

PREST_CLIM_8.5 <- Prestele_CLIM[, c(1:4, grep("8_5", names(Prestele_CLIM)))]
PREST_CLIM_8.5$scenario <- "PREST-CLIM 8.5"
names(PREST_CLIM_8.5)[5:7] <- c("2030","2050","2070")
#------------------------------------------------------------------------------------
PREST_1_2.6 <- Prestele_SSPs[, c(1:4, grep("1_2_6", names(Prestele_SSPs)))]
PREST_1_2.6$scenario <- "PREST-1 2.6"
names(PREST_1_2.6)[5:7] <- c("2030","2050","2070")

PREST_1_4.5 <- Prestele_SSPs[, c(1:4, grep("1_4_5", names(Prestele_SSPs)))]
PREST_1_4.5$scenario <- "PREST-1 4.5"
names(PREST_1_4.5)[5:7] <- c("2030","2050","2070")

PREST_3_4.5 <- Prestele_SSPs[, c(1:4, grep("3_4_5", names(Prestele_SSPs)))]
PREST_3_4.5$scenario <- "PREST-3 4.5"
names(PREST_3_4.5)[5:7] <- c("2030","2050","2070")

PREST_3_8.5 <- Prestele_SSPs[, c(1:4, grep("3_8_5", names(Prestele_SSPs)))]
PREST_3_8.5$scenario <- "PREST-3 8.5"
names(PREST_3_8.5)[5:7] <- c("2030","2050","2070")
#------------------------------------------------------------------------------------
PREST_5_8.5 <- Prestele_SSPs[, c(1:4, grep("5_8_5", names(Prestele_SSPs)))]
PREST_5_8.5$scenario <- "PREST-5 8.5"
names(PREST_5_8.5)[5:7] <- c("2030","2050","2070")
#------------------------------------------------------------------------------------
IIASA_CLIM_2.6 <- IIASA_CLIM[, c(1:4, grep("2_6", names(IIASA_CLIM)))]
IIASA_CLIM_2.6$scenario <- "IIASA-CLIM 2.6"
names(IIASA_CLIM_2.6)[5:7] <- c("2030","2050","2070")

IIASA_CLIM_4.5 <- IIASA_CLIM[, c(1:4, grep("4_5", names(IIASA_CLIM)))]
IIASA_CLIM_4.5$scenario <- "IIASA-CLIM 4.5"
names(IIASA_CLIM_4.5)[5:7] <- c("2030","2050","2070")

IIASA_CLIM_7.0 <- IIASA_CLIM[, c(1:4, grep("7_0", names(IIASA_CLIM)))]
IIASA_CLIM_7.0$scenario <- "IIASA-CLIM 7.0"
names(IIASA_CLIM_7.0)[5:7] <- c("2030","2050","2070")

IIASA_CLIM_8.5 <- IIASA_CLIM[, c(1:4, grep("8_5", names(IIASA_CLIM)))]
IIASA_CLIM_8.5$scenario <- "IIASA-CLIM 8.5"
names(IIASA_CLIM_8.5)[5:7] <- c("2030","2050","2070")
#------------------------------------------------------------------------------------
IIASA_SSPs_2.6 <- IIASA_SSPs[, c(1:4, grep("2_6", names(IIASA_SSPs)))]
IIASA_SSPs_2.6$scenario <- "IIASA-2 2.6"
names(IIASA_SSPs_2.6)[5:7] <- c("2030","2050","2070")

IIASA_SSPs_4.5 <- IIASA_SSPs[, c(1:4, grep("4_5", names(IIASA_SSPs)))]
IIASA_SSPs_4.5$scenario <- "IIASA-2 4.5"
names(IIASA_SSPs_4.5)[5:7] <- c("2030","2050","2070")

IIASA_SSPs_7.0 <- IIASA_SSPs[, c(1:4, grep("7_0", names(IIASA_SSPs)))]
IIASA_SSPs_7.0$scenario <- "IIASA-2 7.0"
names(IIASA_SSPs_7.0)[5:7] <- c("2030","2050","2070")
#------------------------------------------------------------------------------------
GHSB_1_2.6 <- GHSB_SSPs[, c(1:4, grep("2_6", names(GHSB_SSPs)))]
GHSB_1_2.6$scenario <- "GHSB-1 2.6"
names(GHSB_1_2.6)[5:7] <- c("2030","2050","2070")

GHSB_3_6.0 <- GHSB_SSPs[, c(1:4, grep("6_0", names(GHSB_SSPs)))]
GHSB_3_6.0$scenario <- "GHSB-3 6.0"
names(GHSB_3_6.0)[5:7] <- c("2030","2050","2070")

GHSB_5_8.5 <- GHSB_SSPs[, c(1:4, grep("8_5", names(GHSB_SSPs)))]
GHSB_5_8.5$scenario <- "GHSB-5 8.5"
names(GHSB_5_8.5)[5:7] <- c("2030","2050","2070")

#------------------------------------------------------------------------------------
baselines_scenarios <- rbind(
  PREST_CLIM_2.6, PREST_CLIM_4.5, PREST_CLIM_8.5,
  PREST_1_2.6, PREST_1_4.5, PREST_3_4.5, PREST_3_8.5, PREST_5_8.5,
  IIASA_CLIM_2.6, IIASA_CLIM_4.5, IIASA_CLIM_7.0, IIASA_CLIM_8.5,
  IIASA_SSPs_2.6, IIASA_SSPs_4.5, IIASA_SSPs_7.0,
  GHSB_1_2.6, GHSB_3_6.0, GHSB_5_8.5
)

#------------------------------------------------------------------------------------
 
# SAVE 
setwd(output)

#write.xlsx(baselines_scenarios, "pollination_scenarios_wrt_2020.xlsx")
#saveRDS(baselines_scenarios, "pollination_scenarios_wrt_2020.rds")


#------------------------------------------#------------------------------------------#-------------------------------------
# Sensitivity analysis
#------------- -----------------------------------------------------------------------

# Creo files con valori MIN MAX e MED (median) tra i vari scenari
#------------------------------------------------------------------------------------
df <- baselines_scenarios 
df_long <- df %>%
  select(NUTS_ID, LEVL_CODE, CNTR_NAME, `2030`,`2050`,`2070`) %>%
  pivot_longer(cols = c(`2030`,`2050`,`2070`), names_to = "year", values_to = "value") %>%
  group_by(NUTS_ID, LEVL_CODE, CNTR_NAME, year) %>%
  summarise(
    MIN = min(value, na.rm = TRUE),
    MED = median(value, na.rm = TRUE),
    MAX = max(value, na.rm = TRUE),
    .groups = "drop"
  )

sensitivity_across_scenarios = df_long

# SAVE 
setwd(output)

write.xlsx(sensitivity_across_scenarios, "sensitivity_across_scenarios.xlsx")
saveRDS(sensitivity_across_scenarios, "sensitivity_across_scenarios.rds")

#------------------------------------------------------------------------------------

df_summary <- baselines_scenarios %>%
  filter(NUTS_ID != "EU") %>%   # escludo EU
  pivot_longer(cols = c(`2030`,`2050`,`2070`), names_to = "year", values_to = "value") %>%
  group_by(scenario, year) %>%
  summarise(
    MIN = min(value, na.rm = TRUE),
    MED = median(value, na.rm = TRUE),
    MAX = max(value, na.rm = TRUE),
    .groups = "drop"
  )

sensitivity_across_NUTS = df_summary

# SAVE 
setwd(output)

write.xlsx(sensitivity_across_NUTS, "sensitivity_across_NUTS.xlsx")
saveRDS(sensitivity_across_NUTS, "sensitivity_across_NUTS.rds")




 
