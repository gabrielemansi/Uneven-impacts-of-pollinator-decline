rm(list = ls())  
gc()
  
 
# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)
library(ncdf4)
library(purrr)

wd = paste0('F:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
output_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS_rasters')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')
baselines_pollination = paste0(wd, 'POTENTIAL/baselines_pollination/Prestele_SSPs')
INCA_data = paste0(wd, 'POTENTIAL/input_pollination/INCA_data')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
POLLINATION_change_area = paste0(wd, 'DEMAND/POLL_change_area/Prestele_SSPs')
FINAL_SHOCKS = paste0(wd, 'FINAL_SHOCKS/Prestele_SSPs')
SSPs_area= paste0(wd,'DEMAND/AREA_crops/SSP_changes/data_final/crops_land_use')

#-------------------------------------------------------------------------
# POLLONATION DEMAND FOR DIFFERENT CROPS

# The overlap between the pollination potential and demand for pollination is used to 
# quantify the area generating the actual flow of service, i.e. the use area
# The use area can be quantified as the number of hectares of pollinator-dependent crops 
# covered by area with different potential to support pollinators.
#-------------------------------------------------------------------------

# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]

# Load INCA data
setwd(INCA_data)
INCA_2018 = rast('potential_categories.tif')
INCA_2018 = INCA_2018[[4]] / 4
# Load CROPGRIDS
setwd(crops_area)

# -------------------------------------------------
# -------------------------------------------------

# EVALUATE MEAN SHOCK DUE TO POLLINATION CHANGE FOR EACH CROP IN EACH NUTS 3
# Average shock (average reduction in pollination potential per hectare) for each NUTS region
#------------------------------------------------------------------
 
# 1. Load NUTS polygons
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp") 
nuts <- crop(nuts, INCA_2018)  # Crop polygons to INCA extent
nuts <- nuts[, c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN"), drop=FALSE]

# 2. Select only INCA files of interest
inca_files <- list.files(
  baselines_pollination,
  pattern = "Prestele_SSPs_INCA_cum_2020_2080.*\\.tif$",
  full.names = TRUE  )

# 3. Load ALL crop rasters once 
crop_files <- list.files(output_area, pattern = "\\.tif$", full.names = TRUE)

# 4. Select only rasters with non 0 averaged impact on production (pollination dependency)
# Extract crop names (without .tif and path)
crop_names <- tools::file_path_sans_ext(basename(crop_files))
# Merge with crop_dependency table
valid_crops <- crop_dependency$CROPGRIDS[crop_dependency$Avg_impact_on_production >= 0.05]
# Subset crop_files keeping only crops with dependency > 0
crop_files <- crop_files[crop_names %in% valid_crops]

# 5. Select only rasters with non zero crop area values  
crop_rasters <- lapply(crop_files, function(cf) {
  r <- rast(cf)
  if (global(r, "max", na.rm = TRUE)[[1]] > 0) {   # check if any cell > 0
    list(
      name  = tools::file_path_sans_ext(basename(cf)), # crop name
      rast  = r     )                                   # crop raster
  } else {
    NULL     }  })       # skip crops with only zeros
crop_rasters <- Filter(Negate(is.null), crop_rasters) # remove NULL entries
# Round values 
for (i in seq_along(crop_rasters)) {
  rast_obj <- crop_rasters[[i]]$rast
  crop_rasters[[i]]$rast <- round(rast_obj, digits = 2) }
 
# CHECK DATA MATCH
# Controllo che per ogni valore di area coltivata > 0 vi sia un valore non NA di pollionation potential

check_inca <- FALSE  
if (check_inca) {
  for (inca_path in inca_files) {
    INCA_raster <- rast(inca_path)
    inca_name <- tools::file_path_sans_ext(basename(inca_path))
    
    # Count NA in INCA
    na_inca <- global(is.na(INCA_raster), "sum", na.rm = TRUE)[1,1]
    cat("\n--- INCA:", inca_name, "---\n")
    cat("Valori NA in", inca_name, ":", na_inca, "\n")
    
    for (crop in crop_rasters) {
      crop_name <- crop$name
      crop_rast <- crop$rast
      
      cat("\nCrop:", crop_name, "\n")
      
      # Count NA in crop raster
      na_crop <- global(is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      cat("Valori NA in", crop_name, ":", na_crop, "\n")
      
      # Set values < 1 to NA
      crop_rast <- classify(crop_rast, rcl = matrix(c(-Inf, 1, NA), ncol = 3, byrow = TRUE))
      na_crop <- global(is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      cat("Valori NA in", crop_name, "dopo classificazione:", na_crop, "\n")
      
      # Check for mismatches: crop > 0 but INCA is NA
      mismatch <- crop_rast & is.na(INCA_raster)
      mismatch_cells <- global(mismatch, "sum", na.rm = TRUE)[1,1]
      
      total_cells <- global(!is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      percent_na <- (mismatch_cells / total_cells) * 100
      
      cat("Celle >0 in", crop_name, ":", total_cells, "\n")
      cat("Celle agricole senza dati INCA:", mismatch_cells, "\n")
      cat("Percentuale NA:", round(percent_na, 2), "%\n")
    }
  }
}
 

#---------------------------------------------------------------------
# 6. Compute mean pollination potential % reduction (shock) per NUTS on each crop area

# At this level, the average NUTS 2 level reduction of pollination service affecting specific crops is evaluated 
# by overlapping pollination potential reduction areas with specific crops cultivation areas.
# The shock (weighted average of pollination potential reduction) is calculated by overlapping pixel‑by‑pixel between:
# crop_rasters (area per cell), INCA_raster (pollination potential per cell).
#---------------------------------------------------------------------

for (tif_file in inca_files) {
  INCA_raster <- round(rast(tif_file), 2)   # multi-layer raster
  inca_layers <- names(INCA_raster)          # scenario/year names
  base_name_inca <- tools::file_path_sans_ext(basename(tif_file))
  
  # Create subfolder for this INCA file
  inca_subfolder <- file.path(POLLINATION_change_area, base_name_inca)
  dir.create(inca_subfolder, showWarnings = FALSE, recursive = TRUE)
  
  # Loop over crops (already loaded)
  for (crop_obj in crop_rasters) {
    tryCatch({
      crop_raster <- round(crop_obj$rast, 2)
      base_name_crop <- crop_obj$name
      
      # Create subfolder for this crop inside the INCA subfolder
      crop_subfolder <- file.path(inca_subfolder, base_name_crop)
      dir.create(crop_subfolder, showWarnings = FALSE, recursive = TRUE)
      
      # Copy NUTS polygons (to attach new results)
      INCA_NUTS <- nuts
      
      # ---- compute total hectares ONCE per crop ----
      nuts_total_hectares <- extract(crop_raster, nuts, fun = sum, na.rm = TRUE)
      nuts_total_hectares <- round(nuts_total_hectares[,2], 2)  # arrotonda
      
      # Attach to polygons
      INCA_NUTS$nuts_total_hectares <- nuts_total_hectares
      INCA_NUTS$base_name_crop <- base_name_crop
      
      # Loop over each INCA layer (scenario/year)
      for (layer_name in inca_layers) {
        inca_layer <- INCA_raster[[layer_name]]
        
        # Multiply crop area × pollination potential
        crop_potential <- crop_raster * inca_layer
        
        # Extract sums by NUTS polygons
        nuts_weighted_sum <- extract(crop_potential, nuts, fun = sum, na.rm = TRUE)
        nuts_weighted_sum <- round(nuts_weighted_sum[,2], 2)       # round

        # Compute weighted mean per hectare
        nuts_total_hectares[is.null(nuts_total_hectares)] <- NA
        nuts_weighted_sum[is.null(nuts_weighted_sum)] <- NA
  
        mean_per_hectare <- ifelse(
          !is.na(nuts_total_hectares) & nuts_total_hectares > 0,
          nuts_weighted_sum / nuts_total_hectares,
          NA   )

        mean_per_hectare[is.nan(mean_per_hectare)] <- 0
        mean_per_hectare <- pmin(pmax(mean_per_hectare, -1000), 1000)
        mean_per_hectare <- round(mean_per_hectare, 2)
         
        # Add new column for this layer
        INCA_NUTS[[layer_name]] <- mean_per_hectare
      }
      
      # Convert polygons to dataframe (for Excel export)
      INCA_NUTS_df <- as.data.frame(INCA_NUTS)
      
      # Base filename for outputs
      file_base <- paste0(base_name_inca, "_", base_name_crop)
      
      # Save results in three formats (inside crop subfolder)
      saveRDS(INCA_NUTS, file.path(crop_subfolder, paste0(file_base, ".rds")))
      write.xlsx(INCA_NUTS_df, file.path(crop_subfolder, paste0(file_base, ".xlsx")))
      
      shp_dir <- file.path(crop_subfolder, "shapefile")
      dir.create(shp_dir, showWarnings = FALSE, recursive = TRUE)
      writeVector(INCA_NUTS, file.path(shp_dir, paste0(file_base, ".shp")), overwrite = TRUE)
      
      # Progress message
      cat("✅ Processed:", file_base, "\n")
    }, error = function(e) {
      cat("⚠️ Skipped corrupted crop raster:", crop_obj$name, "in", base_name_inca, "\n")
    })
  }
}
 

#---------------------------------------------------------------------
# Compute mean yield shock per NUTS on each crop
# At this level, the dependency factor is applied for each crop to determine the expected yield reduction in each crop area
#---------------------------------------------------------------------

# 7. Apply dependency factor and save updated results

# Loop through INCA folders
inca_folders <- list.dirs(POLLINATION_change_area, recursive = FALSE)

for (inca_folder in inca_folders) {
  inca_name <- basename(inca_folder)
  
  # Crop subfolders
  crop_folders <- list.dirs(inca_folder, recursive = FALSE)
  
  for (crop_folder in crop_folders) {
    crop_name <- basename(crop_folder)
    
    # Dependency value
    dependency_value <- crop_dependency$Avg_impact_on_production[
      crop_dependency$CROPGRIDS == crop_name
    ]
    dependency_value <- suppressWarnings(as.numeric(dependency_value))
    if (length(dependency_value) == 0 || is.na(dependency_value)) {
      dependency_value <- 0
    }
    
    # Output folder
    output_subfolder <- file.path(FINAL_SHOCKS, inca_name, crop_name)
    dir.create(output_subfolder, showWarnings = FALSE, recursive = TRUE)
    
    #-------------------------------
    # Excel (.xlsx) + CSV (.csv)
    #-------------------------------
    xlsx_file <- list.files(crop_folder, pattern = "\\.xlsx$", full.names = TRUE)
    if (length(xlsx_file) > 0) {
      tryCatch({
        df <- read.xlsx(xlsx_file[1])
        scenario_cols <- names(df)[7:ncol(df)]
        df[scenario_cols] <- lapply(df[scenario_cols], function(col) {
          col <- suppressWarnings(as.numeric(as.character(col)))
          col[is.na(col)] <- 0
          round(col * dependency_value, 2)
        })
        # Save as Excel
        xlsx_out_path <- file.path(output_subfolder, paste0("shock_", basename(xlsx_file[1])))
        write.xlsx(df, xlsx_out_path)
        # Save as CSV
        csv_out_path <- file.path(output_subfolder, paste0("shock_", tools::file_path_sans_ext(basename(xlsx_file[1])), ".csv"))
        write.csv(df, csv_out_path, row.names = FALSE)
      }, error = function(e) {
        cat("⚠️ Skipped corrupted Excel file:", xlsx_file[1], "\n")
      })
    }
    
    #-------------------------------
    # RDS (.rds)
    #-------------------------------
    rds_file <- list.files(crop_folder, pattern = "\\.rds$", full.names = TRUE)
    if (length(rds_file) > 0) {
      tryCatch({
        nuts_obj <- readRDS(rds_file[1])
        scenario_cols <- names(nuts_obj)[!(names(nuts_obj) %in% c(
          "NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares", "base_name_crop"
        ))]
        for (col in scenario_cols) {
          values <- suppressWarnings(as.numeric(as.character(nuts_obj[[col]])))
          values[is.na(values)] <- 0
          nuts_obj[[col]] <- round(values * dependency_value, 2)
        }
        saveRDS(nuts_obj, file.path(output_subfolder, paste0("shock_", basename(rds_file[1]))))
      }, error = function(e) {
        cat("⚠️ Skipped corrupted RDS file:", rds_file[1], "\n")
      })
    }
    
    #-------------------------------
    # Shapefile (.shp)
    #-------------------------------
    # shp_dir <- file.path(crop_folder, "shapefile")
    # shp_file <- list.files(shp_dir, pattern = "\\.shp$", full.names = TRUE)
    # if (length(shp_file) > 0) {
    #  tryCatch({
    #   nuts_vect <- vect(shp_file[1])
    #    scenario_cols <- names(nuts_vect)[!(names(nuts_vect) %in% c(
    #      "NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares", "base_name_crop"
    #    ))]
    #   for (col in scenario_cols) {
    #      values <- suppressWarnings(as.numeric(as.character(nuts_vect[[col]])))
    #     values[is.na(values)] <- 0
    #     nuts_vect[[col]] <- round(values * dependency_value, 2)
    #    }
    #    shp_out_dir <- file.path(output_subfolder, "shapefile")
    #   dir.create(shp_out_dir, showWarnings = FALSE, recursive = TRUE)
    #   writeVector(nuts_vect, file.path(shp_out_dir, paste0("shock_", basename(shp_file[1]))), overwrite = TRUE)
    #  }, error = function(e) {
    #    cat("⚠️ Skipped corrupted SHP file:", shp_file[1], "\n")
    #   })
    # }
    
    # Progress
    cat("✅ Updated with dependency:", inca_name, "/", crop_name, "\n")
  }
}

 

#---------------------------------------------------------------------
# Aggregate to match GTAP sectors and NUTS production shares
#---------------------------------------------------------------------

# SSPs projections data on future land use and crops expansion (annual percentage changes in cultivated areas),
# are provided only as NUTS2 level aggregates. 
# Therefore a pixel-by-pixel spatial overlapping is no longer plausible
# because the information on where the crops are located within the polygon is missing.
# The shock is therefore recalculated proportionally to the expected NUTS production shares, 
# so that the percentage change in area is distributed uniformly across the entire polygon, 
# assuming that the new land allocation occurs in areas close to the original ones,
# with no significant changes in projected pollination potential reduction.     
#---------------------------------------------------------------------

# 8. Import GTAP_sectors files, SSPs land use files and matching files 

setwd(paste0(wd, "/DEMAND/AREA_crops/"))

gtap_file <- file.path(wd, "DEMAND", "AREA_crops", "Row_agg_Accreu.xlsx")
getSheetNames(gtap_file)

GTAP_sectors <- read.xlsx(gtap_file, sheet = "mapping_sectors") 
GTAP_crops <- GTAP_sectors[GTAP_sectors[[4]] == "Crops", ]
GTAP_crops = GTAP_crops[c(1:3)]

Shocks_GTAP_match <- file.path(wd, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
Shocks_GTAP_match = read.xlsx(Shocks_GTAP_match)

final_pollination <- read.xlsx("Final_pollination_shocks_GTAP.xlsx")
final_pollination=final_pollination[c(1:3)]

setwd(SSPs_area)
crops_SSPs_cum = read.xlsx("Crops_Land_Use_SSPs_GTAP_cum_WIDE.xlsx")

names(crops_SSPs_cum)[names(crops_SSPs_cum) == "shock_crop_names"] <- "base_name_crop"
names(crops_SSPs_cum)[names(crops_SSPs_cum) == "GTAP.11"] <- "gtap_id"
crops_SSPs_cum = crops_SSPs_cum[c(2,4,5,7,8:74)]
 
 
#.................................................
# 9. Load pollination shocks and evaluate averaged shock for each GTAP sector at NUTS level
#    based on average production area from FAO CROPGRIDS and 
#    expected % area change (crops_SSPs_cum) within each NUTS according to SSPs land use projections from Goebel, Britz (2025)

#    Run with:
#    "Prestele_SSPs_INCA_cum_2020_2080_policy"
#    "Prestele_SSPs_INCA_cum_2020_2080"
#.................................................

#.................................................
setwd(FINAL_SHOCKS)

main_dir <- paste0(FINAL_SHOCKS, "/Prestele_SSPs_INCA_cum_2020_2080_policy")

# Main list: any element is a list of crops associated with a GTAP11. specific sector 
# Lista finale: ogni elemento è un dataframe
shocks_by_GTAP <- list()

for (i in seq_len(nrow(Shocks_GTAP_match))) {
  
  crop     <- Shocks_GTAP_match$shock_crop_names[i]
  gtap_id  <- as.character(Shocks_GTAP_match$GTAP.11[i])
  file_name <- paste0("shock_Prestele_SSPs_INCA_cum_2020_2080_policy_", crop, ".xlsx")
  file_path <- file.path(main_dir, crop, file_name)
  if (file.exists(file_path)) {
    data <- read.xlsx(file_path)
    # aggiungo le colonne richieste
   # data$gtap_id        <- gtap_id
    data$base_name_crop <- crop
    # aggiungo il dataframe alla lista, con nome = crop
    shocks_by_GTAP[[crop]] <- data
    } else {
    warning(paste("File not found:", file_path))}}

# numero totale di file caricati
total_files_loaded <- length(shocks_by_GTAP)

cols_to_remove <- c("LEVL_CODE", "CNTR_CODE", "NAME_LATN")
shocks_by_GTAP <- lapply(shocks_by_GTAP, function(df) {
  df[, setdiff(names(df), cols_to_remove), drop = FALSE]
})

almond=shocks_by_GTAP$almond
names(almond)

# Faccio filtraggio e merge dei datasets crops con dataset aree SSPS per future operazioni 
crops_shocks <- lapply(shocks_by_GTAP, function(df_crop) {
  # 1) tieni solo i base_name_crop che esistono nel df del crop
  cc_sub <- crops_SSPs_cum[crops_SSPs_cum$base_name_crop %in% unique(df_crop$base_name_crop), 1:6]
  # 2) left join: tutte le righe di cc_sub, solo match del crop
  merged <- merge(
    cc_sub,
    df_crop,
    by = c("base_name_crop", "NUTS_ID"),
    all.x = TRUE
  )
  # 3) NA → 0 nelle colonne del crop
  merged[is.na(merged)] <- 0
  merged
})
names(crops_shocks) <- names(shocks_by_GTAP)

almond=crops_shocks$almond
names(almond)

crops_shocks_ssps =  dplyr::bind_rows(crops_shocks)
crops_shocks_ssps <- crops_shocks_ssps[ , !names(crops_shocks_ssps) %in% "nuts_total_hectares"]
names(crops_shocks_ssps)

#-------------------------------------------------------
# rinomino Crops_SSPs_cum e duplico valori mancanti per merge 
crops_SSP1_2_6 = crops_SSPs_cum[c(20:32)]
names(crops_SSP1_2_6) <- sub("^SSP1_", "SSP1_2_6_", names(crops_SSP1_2_6))

crops_SSP1_4_5 = crops_SSPs_cum[c(20:32)]
names(crops_SSP1_4_5) <- sub("^SSP1_", "SSP1_4_5_", names(crops_SSP1_4_5))

crops_SSP3_4_5 = crops_SSPs_cum[c(33:45)]
names(crops_SSP3_4_5) <- sub("^SSP3_", "SSP3_4_5_", names(crops_SSP3_4_5))

crops_SSP3_8_5 = crops_SSPs_cum[c(33:45)]
names(crops_SSP3_8_5) <- sub("^SSP3_", "SSP3_8_5_", names(crops_SSP3_8_5))

crops_SSP5_8_5 = crops_SSPs_cum[c(59:71)]
names(crops_SSP5_8_5) <- sub("^SSP5_", "SSP5_8_5_", names(crops_SSP5_8_5))

crops_SSPs_cum_c = cbind(crops_SSPs_cum[c(1:6)], crops_SSP1_2_6, crops_SSP1_4_5, crops_SSP3_4_5, crops_SSP3_8_5, crops_SSP5_8_5)
names(crops_SSPs_cum_c)

# -------- creo datasets con nuove aree ricalibrate in ogni ssps -------
# creo lista datsets vuoti per  futuro processing aree
area_ssps <- lapply(crops_shocks, function(df) {
  for (j in 8:71) {
    df[[j]][] <- 0   # sostituisce tutti i valori nella colonna, mantenendo tipo e attributi
  }
  df})
names(area_ssps) <- names(crops_shocks)
almond=area_ssps$almond
names(almond)

# colonne scenario-anno (8:46)
scenario_cols <- names(area_ssps[[1]])[8:71]

# preparo un lookup più leggero
lookup <- crops_SSPs_cum_c[, c("base_name_crop", "NUTS_ID", scenario_cols)]
names(lookup)
# applico a tutta la lista
area_scaled <- lapply(area_ssps, function(df_crop) {
  # merge per ottenere gli shock corrispondenti
  merged <- merge(
    df_crop,
    lookup,
    by = c("base_name_crop", "NUTS_ID"),
    suffixes = c("", "_shock"),
    all.x = TRUE
  )
  # per ogni colonna scenario-anno:nuovi valori 
  for (col in scenario_cols) {
    shock_col <- paste0(col, "_shock")
    merged[[col]] <- round(merged$nuts_total_hectares * (1 + merged[[shock_col]] / 100), 2)}
  # rimuovo le colonne shock
  merged <- merged[, c(names(df_crop))]
  merged
})
names(area_scaled) <- names(area_ssps)

almond=area_scaled$almond
names(almond) 

crops_area_ssps <- dplyr::bind_rows(area_scaled)
names(crops_area_ssps)
  
#---------weighted_means_by_GTAP
# Calcolare i pesi relativi per coltura considerando NUTS_ID e gtap_id. Per ogni colonna SSP, il peso sarà dato dal rapporto 
# tra l'area della coltura e la somma delle aree per le colture dello stesso gtap_id e NUTS.
# Calcola il peso relativo di ogni osservazione rispetto alla superficie totale della regione NUTS in ogni scenario_anno e gruppo gtap

compute_crop_weights_df <- function(crops_area_ssps) {
  #rcp_cols <- grep("^SSP", names(crops_area_ssps[[1]]), value = TRUE)
  rcp_cols <- grep("^SSP", names(crops_area_ssps), value = TRUE)
  
  df_all <- dplyr::bind_rows(crops_area_ssps)
  gtap_totals <- df_all %>%
    dplyr::group_by(gtap_id, NUTS_ID) %>%
    dplyr::summarise(
      dplyr::across(all_of(rcp_cols), \(x) sum(x, na.rm = TRUE)),
      .groups = "drop")
  df_weights <- df_all %>%
    dplyr::left_join(
      gtap_totals,
      by = c("gtap_id", "NUTS_ID"),
      suffix = c("", "_GTAP")
    ) %>%
    dplyr::mutate(
      dplyr::across(
        all_of(rcp_cols),
        \(x) round(x / get(paste0(cur_column(), "_GTAP")), 2)
      )
    ) %>%
    dplyr::select(
      base_name_crop,
      NUTS_ID,
      gtap_id,
      GTAP.11.description,
      LEVL_CODE,
      ICES_Reg_region_ACCREU,
      all_of(rcp_cols) )
  return(df_weights)}
crops_weights_ssps <- compute_crop_weights_df(crops_area_ssps)
names(crops_weights_ssps)

# -----  calcolo media pesata degli shocks  ---------
# Identifico le colonne RCP
rcp_cols <- grep("^SSP", names(crops_weights_ssps), value = TRUE)
# Copio la parte identificativa
weighted_shocks_ssps <- crops_weights_ssps[, 1:6]
names(crops_weights_ssps)
names(crops_shocks_ssps)
# Prodotto peso × shock per ogni colonna RCP
for (col in rcp_cols) {
  weighted_shocks_ssps[[col]] <- 
    crops_weights_ssps[[col]] * crops_shocks_ssps[[col]]}
names(weighted_shocks_ssps)
# raggruppo per gtap_id 
rcp_cols <- grep("^SSP", names(weighted_shocks_ssps), value = TRUE)

# Identifico NUTS
all_nuts <- weighted_shocks_ssps %>% distinct(NUTS_ID)

# funzione di aggregazione
aggregate_category <- function(df, category, all_nuts, rcp_cols) {
  aggregated <- df %>%
    filter(gtap_id == category) %>%
    group_by(NUTS_ID) %>%
    summarise(
      across(all_of(rcp_cols), sum, na.rm = TRUE),
      .groups = "drop"
    )
  out <- all_nuts %>%
    left_join(aggregated, by = "NUTS_ID") %>%
    mutate(
      gtap_id = category,
      across(all_of(rcp_cols), ~ tidyr::replace_na(.x, 0))
    ) %>%
    select(gtap_id, NUTS_ID, all_of(rcp_cols))  # 👈 gtap_id PRIMA COLONNA
  out
}

gro <- aggregate_category(weighted_shocks_ssps, "gro", all_nuts, rcp_cols)
v_f <- aggregate_category(weighted_shocks_ssps, "v_f", all_nuts, rcp_cols)
osd <- aggregate_category(weighted_shocks_ssps, "osd", all_nuts, rcp_cols)
c_b <- aggregate_category(weighted_shocks_ssps, "c_b", all_nuts, rcp_cols)
ocr <- aggregate_category(weighted_shocks_ssps, "ocr", all_nuts, rcp_cols)


weighted_dfs <- list(
  gro = gro,
  v_f = v_f,
  osd = osd,
  c_b = c_b,
  ocr = ocr)

     
#---------------------------------------------------------
# Aggiungo nomi ICES_Reg_region_ACCREU
#---------------------------------------------------------

weighted_dfs <- lapply(weighted_dfs, function(df) {
  # left join per aggiungere colonne di identificazione
  merged_df <- final_pollination %>%
    left_join(df, by = "NUTS_ID")
  
  # opzionale: riordina colonne con gtap_id e NUTS_ID primi
  merged_df <- merged_df %>%
    select(gtap_id, NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, everything())
  
  merged_df
})


# SAVE RESULTS
GTAP_shocks_dir <- paste0(FINAL_SHOCKS, "/GTAP_shocks/GTAP_2020_2080_policy/")
dir.create(GTAP_shocks_dir, recursive = TRUE, showWarnings = FALSE)

#  .rds, .csv e .xlsx
for (gtap_id in names(weighted_dfs)) {
  df <- weighted_dfs[[gtap_id]]
  
  rds_path   <- file.path(GTAP_shocks_dir, paste0("Prest_SSPs_shocks_GTAP_", gtap_id, "_policy.rds"))
  csv_path   <- file.path(GTAP_shocks_dir, paste0("Prest_SSPs_shocks_GTAP_", gtap_id, "_policy.csv"))
  xlsx_path  <- file.path(GTAP_shocks_dir, paste0("Prest_SSPs_shocks_GTAP_", gtap_id, "_policy.xlsx"))
  
  # Save
  saveRDS(df, rds_path)
  write.csv(df, csv_path, row.names = FALSE)
  write.xlsx(df, xlsx_path)
}
  
    
