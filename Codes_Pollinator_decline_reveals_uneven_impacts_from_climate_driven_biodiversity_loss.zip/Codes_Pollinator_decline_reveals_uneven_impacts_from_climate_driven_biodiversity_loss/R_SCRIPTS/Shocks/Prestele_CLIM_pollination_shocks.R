rm(list = ls())  
gc()
  
 
# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)
library(ncdf4)


wd = paste0('F:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
output_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS_rasters')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')
baselines_pollination = paste0(wd, 'POTENTIAL/baselines_pollination/Prestele_CLIM')
INCA_data = paste0(wd, 'POTENTIAL/input_pollination/INCA_data')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
POLLINATION_change_area = paste0(wd, 'DEMAND/POLL_change_area/Prestele_CLIM')
FINAL_SHOCKS = paste0(wd, 'FINAL_SHOCKS/Prestele_CLIM')


#-------------------------------------------------------------------------
# POLLONATION DEMAND FOR DIFFERENT CROPS

# The overlap between the pollination potential and demand for pollination is used to 
# quantify the area generating the actual flow of service, i.e. the use area
# The use area can be quantified as the number of hectares of pollinator-dependent crops 
# covered by area with different potential to support pollinators.
#-------------------------------------------------------------------------

# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]

# Load INCA data
setwd(INCA_data)
INCA_2018 = rast('potential_categories.tif')
INCA_2018 = INCA_2018[[4]] / 4
# Load CROPGRIDS
setwd(crops_area)

    
# -------------------------------------------------
# -------------------------------------------------

# EVALUATE MEAN SHOCK DUE TO POLLINATION CHANGE FOR EACH CROP IN EACH NUTS 3
# Average shock (average reduction in pollination potential per hectare) for each NUTS region
#------------------------------------------------------------------
  
# 1. Load NUTS polygons
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp") 
nuts <- crop(nuts, INCA_2018)  # Crop polygons to INCA extent
nuts <- nuts[, c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN"), drop=FALSE]

# 2. Select only INCA files of interest
inca_files <- list.files(
  baselines_pollination,
  pattern = "Prestele_CLIM_INCA_cum_2020_2080.*\\.tif$",
  full.names = TRUE  )

# 3. Load ALL crop rasters once 
crop_files <- list.files(output_area, pattern = "\\.tif$", full.names = TRUE)

# 4. Select only rasters with non 0 averaged impact on production (pollination dependency)
# Extract crop names (without .tif and path)
crop_names <- tools::file_path_sans_ext(basename(crop_files))
# Merge with crop_dependency table
valid_crops <- crop_dependency$CROPGRIDS[crop_dependency$Avg_impact_on_production >= 0.05]
# Subset crop_files keeping only crops with dependency > 0
crop_files <- crop_files[crop_names %in% valid_crops]

# 5. Select only rasters with non zero crop area values  
crop_rasters <- lapply(crop_files, function(cf) {
  r <- rast(cf)
  if (global(r, "max", na.rm = TRUE)[[1]] > 0) {   # check if any cell > 0
    list(
      name  = tools::file_path_sans_ext(basename(cf)), # crop name
      rast  = r     )                                   # crop raster
  } else {
    NULL     }  })       # skip crops with only zeros
crop_rasters <- Filter(Negate(is.null), crop_rasters) # remove NULL entries
# Round values 
for (i in seq_along(crop_rasters)) {
  rast_obj <- crop_rasters[[i]]$rast
  crop_rasters[[i]]$rast <- round(rast_obj, digits = 2) }
 
# CHECK DATA MATCH
# Controllo che per ogni valore di area coltivata > 0 vi sia un valore non NA di pollionation potential

check_inca <- FALSE  
if (check_inca) {
  for (inca_path in inca_files) {
    INCA_raster <- rast(inca_path)
    inca_name <- tools::file_path_sans_ext(basename(inca_path))
    
    # Count NA in INCA
    na_inca <- global(is.na(INCA_raster), "sum", na.rm = TRUE)[1,1]
    cat("\n--- INCA:", inca_name, "---\n")
    cat("Valori NA in", inca_name, ":", na_inca, "\n")
    
    for (crop in crop_rasters) {
      crop_name <- crop$name
      crop_rast <- crop$rast
      
      cat("\nCrop:", crop_name, "\n")
      
      # Count NA in crop raster
      na_crop <- global(is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      cat("Valori NA in", crop_name, ":", na_crop, "\n")
      
      # Set values < 1 to NA
      crop_rast <- classify(crop_rast, rcl = matrix(c(-Inf, 1, NA), ncol = 3, byrow = TRUE))
      na_crop <- global(is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      cat("Valori NA in", crop_name, "dopo classificazione:", na_crop, "\n")
      
      # Check for mismatches: crop > 0 but INCA is NA
      mismatch <- crop_rast & is.na(INCA_raster)
      mismatch_cells <- global(mismatch, "sum", na.rm = TRUE)[1,1]
      
      total_cells <- global(!is.na(crop_rast), "sum", na.rm = TRUE)[1,1]
      percent_na <- (mismatch_cells / total_cells) * 100
      
      cat("Celle >0 in", crop_name, ":", total_cells, "\n")
      cat("Celle agricole senza dati INCA:", mismatch_cells, "\n")
      cat("Percentuale NA:", round(percent_na, 2), "%\n")
    }
  }
}

 
#---------------------------------------------------------------------
# 6. Compute mean pollination potential % reduction (shock) per NUTS on each crop area

# At this level, the average NUTS 2 level reduction of pollination service affecting specific crops is evaluated 
# by overlapping pollination potential reduction areas with specific crops cultivation areas.
# The shock (weighted average of pollination potential reduction) is calculated by overlapping pixel‑by‑pixel between:
# crop_rasters (area per cell), INCA_raster (pollination potential per cell).
#---------------------------------------------------------------------

for (tif_file in inca_files) {
  INCA_raster <- round(rast(tif_file), 2)   # multi-layer raster
  inca_layers <- names(INCA_raster)          # scenario/year names
  base_name_inca <- tools::file_path_sans_ext(basename(tif_file))
  
  # Create subfolder for this INCA file
  inca_subfolder <- file.path(POLLINATION_change_area, base_name_inca)
  dir.create(inca_subfolder, showWarnings = FALSE, recursive = TRUE)
  
  # Loop over crops (already loaded)
  for (crop_obj in crop_rasters) {
    tryCatch({
      crop_raster <- round(crop_obj$rast, 2)
      base_name_crop <- crop_obj$name
      
      # Create subfolder for this crop inside the INCA subfolder
      crop_subfolder <- file.path(inca_subfolder, base_name_crop)
      dir.create(crop_subfolder, showWarnings = FALSE, recursive = TRUE)
      
      # Copy NUTS polygons (to attach new results)
      INCA_NUTS <- nuts
      
      # ---- compute total hectares ONCE per crop ----
      nuts_total_hectares <- extract(crop_raster, nuts, fun = sum, na.rm = TRUE)
      nuts_total_hectares <- round(nuts_total_hectares[,2], 2)  # arrotonda
      
      # Attach to polygons
      INCA_NUTS$nuts_total_hectares <- nuts_total_hectares
      INCA_NUTS$base_name_crop <- base_name_crop
      
      # Loop over each INCA layer (scenario/year)
      for (layer_name in inca_layers) {
        inca_layer <- INCA_raster[[layer_name]]
        
        # Multiply crop area × pollination potential
        crop_potential <- crop_raster * inca_layer
        
        # Extract sums by NUTS polygons
        nuts_weighted_sum <- extract(crop_potential, nuts, fun = sum, na.rm = TRUE)
        nuts_weighted_sum <- round(nuts_weighted_sum[,2], 2)       # round

        # Compute weighted mean per hectare
        nuts_total_hectares[is.null(nuts_total_hectares)] <- NA
        nuts_weighted_sum[is.null(nuts_weighted_sum)] <- NA
  
        mean_per_hectare <- ifelse(
          !is.na(nuts_total_hectares) & nuts_total_hectares > 0,
          nuts_weighted_sum / nuts_total_hectares,
          NA   )

        mean_per_hectare[is.nan(mean_per_hectare)] <- 0
        mean_per_hectare <- pmin(pmax(mean_per_hectare, -1000), 1000)
        mean_per_hectare <- round(mean_per_hectare, 2)
         
        # Add new column for this layer
        INCA_NUTS[[layer_name]] <- mean_per_hectare
      }
      
      # Convert polygons to dataframe (for Excel export)
      INCA_NUTS_df <- as.data.frame(INCA_NUTS)
      
      # Base filename for outputs
      file_base <- paste0(base_name_inca, "_", base_name_crop)
      
      # Save results in three formats (inside crop subfolder)
      saveRDS(INCA_NUTS, file.path(crop_subfolder, paste0(file_base, ".rds")))
      write.xlsx(INCA_NUTS_df, file.path(crop_subfolder, paste0(file_base, ".xlsx")))
      
      shp_dir <- file.path(crop_subfolder, "shapefile")
      dir.create(shp_dir, showWarnings = FALSE, recursive = TRUE)
      writeVector(INCA_NUTS, file.path(shp_dir, paste0(file_base, ".shp")), overwrite = TRUE)
      
      # Progress message
      cat("✅ Processed:", file_base, "\n")
    }, error = function(e) {
      cat("⚠️ Skipped corrupted crop raster:", crop_obj$name, "in", base_name_inca, "\n")
    })
  }
}
 

#---------------------------------------------------------------------
# Compute mean yield shock per NUTS on each crop
# At this level, the dependency factor is applied for each crop to determine the expected yield reduction in each crop area
#---------------------------------------------------------------------
 
# 7. Apply dependency factor and save updated results

# Loop through INCA folders
inca_folders <- list.dirs(POLLINATION_change_area, recursive = FALSE)

for (inca_folder in inca_folders) {
  inca_name <- basename(inca_folder)
  
  # Crop subfolders
  crop_folders <- list.dirs(inca_folder, recursive = FALSE)
  
  for (crop_folder in crop_folders) {
    crop_name <- basename(crop_folder)
    
    # Dependency value
    dependency_value <- crop_dependency$Avg_impact_on_production[
      crop_dependency$CROPGRIDS == crop_name
    ]
    dependency_value <- suppressWarnings(as.numeric(dependency_value))
    if (length(dependency_value) == 0 || is.na(dependency_value)) {
      dependency_value <- 0
    }
    
    # Output folder
    output_subfolder <- file.path(FINAL_SHOCKS, inca_name, crop_name)
    dir.create(output_subfolder, showWarnings = FALSE, recursive = TRUE)
    
    #-------------------------------
    # Excel (.xlsx) + CSV (.csv)
    #-------------------------------
    xlsx_file <- list.files(crop_folder, pattern = "\\.xlsx$", full.names = TRUE)
    if (length(xlsx_file) > 0) {
      tryCatch({
        df <- read.xlsx(xlsx_file[1])
        scenario_cols <- names(df)[7:ncol(df)]
        df[scenario_cols] <- lapply(df[scenario_cols], function(col) {
          col <- suppressWarnings(as.numeric(as.character(col)))
          col[is.na(col)] <- 0
          round(col * dependency_value, 2)
        })
        # Save as Excel
        xlsx_out_path <- file.path(output_subfolder, paste0("shock_", basename(xlsx_file[1])))
        write.xlsx(df, xlsx_out_path)
        # Save as CSV
        csv_out_path <- file.path(output_subfolder, paste0("shock_", tools::file_path_sans_ext(basename(xlsx_file[1])), ".csv"))
        write.csv(df, csv_out_path, row.names = FALSE)
      }, error = function(e) {
        cat("⚠️ Skipped corrupted Excel file:", xlsx_file[1], "\n")
      })
    }
    
    #-------------------------------
    # RDS (.rds)
    #-------------------------------
    rds_file <- list.files(crop_folder, pattern = "\\.rds$", full.names = TRUE)
    if (length(rds_file) > 0) {
      tryCatch({
        nuts_obj <- readRDS(rds_file[1])
        scenario_cols <- names(nuts_obj)[!(names(nuts_obj) %in% c(
          "NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares", "base_name_crop"
        ))]
        for (col in scenario_cols) {
          values <- suppressWarnings(as.numeric(as.character(nuts_obj[[col]])))
          values[is.na(values)] <- 0
          nuts_obj[[col]] <- round(values * dependency_value, 2)
        }
        saveRDS(nuts_obj, file.path(output_subfolder, paste0("shock_", basename(rds_file[1]))))
      }, error = function(e) {
        cat("⚠️ Skipped corrupted RDS file:", rds_file[1], "\n")
      })
    }
    
    #-------------------------------
    # Shapefile (.shp)
    #-------------------------------
    # shp_dir <- file.path(crop_folder, "shapefile")
    # shp_file <- list.files(shp_dir, pattern = "\\.shp$", full.names = TRUE)
    # if (length(shp_file) > 0) {
    #  tryCatch({
    #   nuts_vect <- vect(shp_file[1])
    #    scenario_cols <- names(nuts_vect)[!(names(nuts_vect) %in% c(
    #      "NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares", "base_name_crop"
    #    ))]
    #   for (col in scenario_cols) {
    #      values <- suppressWarnings(as.numeric(as.character(nuts_vect[[col]])))
    #     values[is.na(values)] <- 0
    #     nuts_vect[[col]] <- round(values * dependency_value, 2)
    #    }
    #    shp_out_dir <- file.path(output_subfolder, "shapefile")
    #   dir.create(shp_out_dir, showWarnings = FALSE, recursive = TRUE)
    #   writeVector(nuts_vect, file.path(shp_out_dir, paste0("shock_", basename(shp_file[1]))), overwrite = TRUE)
    #  }, error = function(e) {
    #    cat("⚠️ Skipped corrupted SHP file:", shp_file[1], "\n")
    #   })
    # }
    
    # Progress
    cat("✅ Updated with dependency:", inca_name, "/", crop_name, "\n")
  }
}


#-------------------------------
   
#---------------------------------------------------------------------
# Aggregate to match GTAP sectors and NUTS production shares
#---------------------------------------------------------------------

# 8. Import GTAP_sectors ESTAT files and matching files 

setwd(paste0(wd, "/DEMAND/AREA_crops/"))

gtap_file <- file.path(wd, "DEMAND", "AREA_crops", "Row_agg_Accreu.xlsx")
getSheetNames(gtap_file)

GTAP_sectors <- read.xlsx(gtap_file, sheet = "mapping_sectors") 
GTAP_crops <- GTAP_sectors[GTAP_sectors[[4]] == "Crops", ]
GTAP_crops = GTAP_crops[c(1:3)]

Shocks_GTAP_match <- file.path(wd, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
Shocks_GTAP_match = read.xlsx(Shocks_GTAP_match)

 
#.................................................
# 9. Load pollination shocks and evaluate averaged shock for each GTAP sector at NUTS level
#    based on average production area from FAO CROPGRIDS
#    Run with:
#    "Prestele_CLIM_INCA_cum_2020_2080_policy"
#    "Prestele_CLIM_INCA_cum_2020_2080"
#.................................................
 
setwd(FINAL_SHOCKS)

# Scegli qui quale scenario usare:
inca_scenarios <- c(
  "Prestele_CLIM_INCA_cum_2020_2080_policy",
  "Prestele_CLIM_INCA_cum_2020_2080"
)

for (inca_name in inca_scenarios) {
  
  cat("\n=== Processing scenario:", inca_name, "===\n")
  
  main_dir <- file.path(FINAL_SHOCKS, inca_name)
  
  # Main list: ogni elemento è una lista di crop associati a un settore GTAP11
  shocks_by_GTAP <- list()
  
  for (i in seq_len(nrow(Shocks_GTAP_match))) {
    crop    <- Shocks_GTAP_match$shock_crop_names[i]
    gtap_id <- as.character(Shocks_GTAP_match$GTAP.11[i])
    
    crop_dir <- file.path(main_dir, crop)
    if (!dir.exists(crop_dir)) {
      warning(paste("Crop folder not found:", crop_dir))
      next
    }
    
    # Cerca un file shock_*.csv nella cartella del crop
    csv_files <- list.files(crop_dir, pattern = "^shock_.*\\.csv$", full.names = TRUE)
    if (length(csv_files) == 0) {
      warning(paste("No shock_*.csv file found in:", crop_dir))
      next
    }
    
    # Prendi il primo (coerente con la logica precedente)
    file_path <- csv_files[1]
    
    # Carica il file
    data <- tryCatch(
      read.csv(file_path),
      error = function(e) {
        warning(paste("Error reading file:", file_path, "->", e$message))
        NULL
      }
    )
    
    if (is.null(data)) next
    
    # Inizializza sottolista GTAP se mancante
    if (!gtap_id %in% names(shocks_by_GTAP)) {
      shocks_by_GTAP[[gtap_id]] <- list()
    }
    
    # Aggiungi dati per questo crop
    shocks_by_GTAP[[gtap_id]][[crop]] <- data
  }
  
  # Diagnostica: quanti file caricati?
  valid_lengths <- sapply(shocks_by_GTAP, function(x) if (is.list(x)) length(x) else 0)
  total_files_loaded <- sum(valid_lengths)
  cat("Total files loaded for", inca_name, ":", total_files_loaded, "\n")
  
  # Se non c'è nulla, passa allo scenario successivo
  if (total_files_loaded == 0) {
    warning(paste("No valid shock files loaded for scenario:", inca_name))
    next
  }
  
  #---------weighted_means_by_GTAP
  weighted_mean_category <- function(category_list) {
    df_all <- bind_rows(category_list)
    
    rcp_cols <- grep("^RCP", names(df_all), value = TRUE)
    
    df_weighted <- df_all %>%
      group_by(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN) %>%
      mutate(total_area = sum(nuts_total_hectares, na.rm = TRUE)) %>%
      mutate(weight = nuts_total_hectares / total_area) %>%
      summarise(
        total_area = first(total_area),
        across(all_of(rcp_cols), ~ weighted.mean(.x, w = weight, na.rm = TRUE)),
        .groups = "drop"
      ) %>%
      mutate(across(where(is.numeric), ~ round(.x, 2)))
    
    return(df_weighted)
  } 
   
  # Calcola medie pesate per ciascun GTAP
  weighted_dfs <- list()
  if (!is.null(shocks_by_GTAP$gro)) weighted_dfs$gro <- weighted_mean_category(shocks_by_GTAP$gro)
  if (!is.null(shocks_by_GTAP$v_f)) weighted_dfs$v_f <- weighted_mean_category(shocks_by_GTAP$v_f)
  if (!is.null(shocks_by_GTAP$osd)) weighted_dfs$osd <- weighted_mean_category(shocks_by_GTAP$osd)
  if (!is.null(shocks_by_GTAP$c_b)) weighted_dfs$c_b <- weighted_mean_category(shocks_by_GTAP$c_b)
  if (!is.null(shocks_by_GTAP$ocr)) weighted_dfs$ocr <- weighted_mean_category(shocks_by_GTAP$ocr)
  
  # SAVE RESULTS
  # Aggiungi "_policy" solo se presente nel nome scenario
  policy_suffix <- if (grepl("policy", inca_name)) "_policy" else ""
  
  GTAP_shocks_dir <- file.path(FINAL_SHOCKS, "GTAP_shocks", paste0("GTAP_cum_2020_2080", policy_suffix))
  dir.create(GTAP_shocks_dir, recursive = TRUE, showWarnings = FALSE)
  
  for (gtap_id in names(weighted_dfs)) {
    df <- weighted_dfs[[gtap_id]]
    
    rds_path  <- file.path(GTAP_shocks_dir, paste0("mean_shocks_GTAP_", gtap_id, policy_suffix, ".rds"))
    csv_path  <- file.path(GTAP_shocks_dir, paste0("mean_shocks_GTAP_", gtap_id, policy_suffix, ".csv"))
    xlsx_path <- file.path(GTAP_shocks_dir, paste0("mean_shocks_GTAP_", gtap_id, policy_suffix, ".xlsx"))
    
    saveRDS(df, rds_path)
    write.csv(df, csv_path, row.names = FALSE)
    write.xlsx(df, xlsx_path)
  }
  
  cat("✅ Finished scenario:", inca_name, "\n")
}
 
  
#-----------------------------------------------------------------------
# 10. Final aggregation 
#-----------------------------------------------------------------------
setwd(paste0(wd, "/DEMAND/AREA_crops/"))

final_pollination <- read.xlsx("Final_pollination_shocks_GTAP.xlsx")
final_pollination <- final_pollination[c(1:3)]   # NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU

#----------------------------------------------------------------------
GTAP_final <- paste0(FINAL_SHOCKS, "/GTAP_shocks/")
setwd(GTAP_final)

merge_crop_data <- function(folder, suffix = "") {
  
  path <- file.path(GTAP_final, folder)
  files <- list.files(path, pattern = paste0("mean_shocks_GTAP_.*", suffix, ".xlsx"), full.names = TRUE)
  
  merged_list <- list()
  
  for (file in files) {
    
    crop_name <- sub(paste0("mean_shocks_GTAP_(.*)", suffix, ".xlsx"), "\\1", basename(file))
    crop_data <- read.xlsx(file)
    
    # Seleziona NUTS_ID + tutte le colonne RCP
    crop_data_selected <- crop_data %>%
      select(NUTS_ID, starts_with("RCP"))
    
    # Join con final_pollination (mantiene ICES_Reg_region_ACCREU)
    merged <- final_pollination %>%
      left_join(crop_data_selected, by = "NUTS_ID")
    
    # Aggiunge crop_group come prima colonna
    merged <- merged %>%
      mutate(crop_group = crop_name, .before = 1) %>%
      select(crop_group, everything())
    
    merged_list[[crop_name]] <- merged
  }
  
  return(merged_list)
}

final_GTAP_pollination_shocks <- merge_crop_data("GTAP_cum_2020_2080")
final_GTAP_pollination_shocks_policy <- merge_crop_data("GTAP_cum_2020_2080_policy", "_policy")

#----------------------------------------------------------------------
# SAVE RESULTS (.xlsx, .csv, .rds)
#----------------------------------------------------------------------
output_dir <- file.path(GTAP_final, "GTAP_final_pollination_shocks")
if (!dir.exists(output_dir)) dir.create(output_dir)

save_merged_list <- function(merged_list, suffix) {
  
  for (crop_name in names(merged_list)) {
    
    df <- merged_list[[crop_name]]
    
    # File names
    base_name <- paste0("shock_", crop_name, suffix)
    
    # Paths
    xlsx_path <- file.path(output_dir, paste0(base_name, ".xlsx"))
    csv_path  <- file.path(output_dir, paste0(base_name, ".csv"))
    rds_path  <- file.path(output_dir, paste0(base_name, ".rds"))
    
    # Save
    write.xlsx(df, xlsx_path)
    write.csv(df, csv_path, row.names = FALSE)
    saveRDS(df, rds_path)
    
    message(paste("✅ Salvato:", base_name))
  }
}

save_merged_list(final_GTAP_pollination_shocks, "_no_policy")
save_merged_list(final_GTAP_pollination_shocks_policy, "_policy")


 

