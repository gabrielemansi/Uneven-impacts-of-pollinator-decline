# ==============================================================================
# Prestele_CLIM_pollination_shocks.R
# ------------------------------------------------------------------------------
# Crop yield shocks from the change in pollination potential projected with the
# climate-only (CLIM) scenarios of Prestele et al. (2021)
# (Prestele_CLIM_INCA_cum_2020_2080), by NUTS region, crop and GTAP sector.
#
# Method
#   1. For each CROPGRIDS crop, NUTS region and layer (scenario and year), the % change in
#      pollination potential relative to 2020 is averaged over the harvested
#      area of the crop (area-weighted mean, bounded to [-1000, 1000]).
#   2. Yield shock of each crop: mean change multiplied by the pollination
#      dependency of the crop.
#   3. Yield shock of each crop: mean change multiplied by the pollination
#      dependency of the crop.
#   4. The shocks of the crops of each GTAP sector (gro, v_f, osd, c_b, ocr) are
#      averaged, weighted by the 2020 harvested area of each crop in each NUTS
#      region, and joined to the regions of the economic model.
#
# Inputs (paths relative to the project root)
#   POTENTIAL/baselines_pollination/Prestele_CLIM/Prestele_CLIM_INCA_cum_2020_2080.tif
#   POTENTIAL/input_pollination/INCA_data/potential_categories.tif
#   DEMAND/AREA_crops/FAO_CROPGRIDS_rasters/<crop>.tif
#   DEMAND/DEPENDENCY_crops/FAO_CROPGRIDS_pollinatio_dependency.xlsx
#   DEMAND/AREA_crops/Shocks_GTAP_match.xlsx
#   DEMAND/AREA_crops/Final_pollination_shocks_GTAP.xlsx
#   EU_boundaries/NUTS_RG_10M_2024_3035/NUTS_RG_10M_2024_3035.shp
#
# Outputs
#   DEMAND/POLL_change_area/Prestele_CLIM/Prestele_CLIM_INCA_cum_2020_2080/<crop>/
#     Prestele_CLIM_INCA_cum_2020_2080_<crop>.xlsx and .rds
#       mean change in pollination potential over the crop area, by NUTS region
#   FINAL_SHOCKS/Prestele_CLIM/Prestele_CLIM_INCA_cum_2020_2080/<crop>/
#     shock_Prestele_CLIM_INCA_cum_2020_2080_<crop>.xlsx, .csv and .rds
#       crop yield shock, by NUTS region
#   FINAL_SHOCKS/Prestele_CLIM/GTAP_shocks/GTAP_cum_2020_2080/
#     mean_shocks_GTAP_<sector>.xlsx, .csv and .rds
#       yield shock by GTAP sector, by NUTS region
#   FINAL_SHOCKS/Prestele_CLIM/GTAP_shocks/GTAP_final_pollination_shocks/
#     shock_<sector>.xlsx, .csv and .rds
#       yield shock by GTAP sector, for the regions of the economic model
#
# Run after INCA_pollination_baselines.R and
# Prestele_CLIM_pollination_baselines.R
# ==============================================================================

library(terra)
library(dplyr)
library(openxlsx)

# Paths ------------------------------------------------------------------------

base_dir <- "."  # project root (POLLINATION folder)

dataset   <- "Prestele_CLIM"                     # dataset folder name
inca_name <- "Prestele_CLIM_INCA_cum_2020_2080"  # % change in pollination potential

inca_file       <- file.path(base_dir, "POTENTIAL", "baselines_pollination", dataset,
                             paste0(inca_name, ".tif"))
inca_grid_file  <- file.path(base_dir, "POTENTIAL", "input_pollination", "INCA_data",
                             "potential_categories.tif")
crops_dir       <- file.path(base_dir, "DEMAND", "AREA_crops", "FAO_CROPGRIDS_rasters")
dependency_file <- file.path(base_dir, "DEMAND", "DEPENDENCY_crops",
                             "FAO_CROPGRIDS_pollinatio_dependency.xlsx")
gtap_match_file <- file.path(base_dir, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
regions_file    <- file.path(base_dir, "DEMAND", "AREA_crops",
                             "Final_pollination_shocks_GTAP.xlsx")
nuts_file       <- file.path(base_dir, "EU_boundaries", "NUTS_RG_10M_2024_3035",
                             "NUTS_RG_10M_2024_3035.shp")
change_dir      <- file.path(base_dir, "DEMAND", "POLL_change_area", dataset, inca_name)
shocks_dir      <- file.path(base_dir, "FINAL_SHOCKS", dataset)

# Functions --------------------------------------------------------------------

na_to_zero <- function(x) {
  x[is.na(x)] <- 0
  x
}

# Sum of the raster values over each NUTS region, rounded to 2 decimals
nuts_sum <- function(r, nuts) {
  na_to_zero(round(extract(r, nuts, fun = sum, na.rm = TRUE)[, 2], 2))
}

# Mean change in pollination potential over the harvested area of a crop in
# each NUTS region (area-weighted), for each layer of inca_change
mean_change_on_crop <- function(crop_area, crop_name, inca_change, nuts) {
  hectares <- nuts_sum(crop_area, nuts)
  out <- nuts
  out$nuts_total_hectares <- hectares
  out$base_name_crop <- crop_name
  for (layer in names(inca_change)) {
    weighted_sum <- nuts_sum(crop_area * inca_change[[layer]], nuts)
    mean_change <- ifelse(hectares > 0, weighted_sum / hectares, 0)
    mean_change[is.nan(mean_change)] <- 0
    out[[layer]] <- round(pmin(pmax(mean_change, -1000), 1000), 2)
  }
  out
}

# Pollination dependency of a crop (0 if missing)
crop_dependency <- function(crop, dependency) {
  d <- dependency$Avg_impact_on_production[dependency$CROPGRIDS == crop]
  d <- suppressWarnings(as.numeric(d))
  if (length(d) == 0 || is.na(d)) 0 else d
}

# Yield shock: change in pollination potential times the crop dependency
apply_dependency <- function(x, dependency) {
  x <- na_to_zero(suppressWarnings(as.numeric(as.character(x))))
  round(x * dependency, 2)
}

# Mean of the crop shocks of a sector, weighted by the harvested area of each
# crop in each NUTS region
weighted_sector_mean <- function(crop_tables, pattern) {
  df <- bind_rows(crop_tables)
  cols <- grep(pattern, names(df), value = TRUE)
  df %>%
    group_by(NUTS_ID, LEVL_CODE, CNTR_CODE, NAME_LATN) %>%
    mutate(total_area = sum(nuts_total_hectares, na.rm = TRUE),
           weight     = nuts_total_hectares / total_area) %>%
    summarise(total_area = first(total_area),
              across(all_of(cols), ~ weighted.mean(.x, w = weight, na.rm = TRUE)),
              .groups = "drop") %>%
    mutate(across(where(is.numeric), ~ round(.x, 2)))
}

# Save a table as .rds, .csv and .xlsx
save_table <- function(df, path_stem) {
  saveRDS(df, paste0(path_stem, ".rds"))
  write.csv(df, paste0(path_stem, ".csv"), row.names = FALSE)
  write.xlsx(df, paste0(path_stem, ".xlsx"))
}

# 1. Inputs --------------------------------------------------------------------

dependency <- read.xlsx(dependency_file)[, c("CROPGRIDS", "Avg_impact_on_production")]

nuts <- vect(nuts_file)
nuts <- crop(nuts, rast(inca_grid_file))  # NUTS regions within the INCA extent
nuts <- nuts[, c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN"), drop = FALSE]

# Pollinator-dependent crops (average impact >= 5%) with a non-zero harvested area
dependent_crops <- dependency$CROPGRIDS[dependency$Avg_impact_on_production >= 0.05]
crop_files <- list.files(crops_dir, pattern = "\\.tif$", full.names = TRUE)
crop_files <- crop_files[tools::file_path_sans_ext(basename(crop_files)) %in% dependent_crops]

crop_rasters <- list()
for (f in crop_files) {
  r <- rast(f)
  if (global(r, "max", na.rm = TRUE)[[1]] > 0) {
    crop_rasters[[tools::file_path_sans_ext(basename(f))]] <- round(r, 2)
  }
}

inca_change <- round(rast(inca_file), 2)

# 2. Change in pollination potential over the crop areas -----------------------

for (crop_name in names(crop_rasters)) {
  tryCatch({
    result <- mean_change_on_crop(crop_rasters[[crop_name]], crop_name, inca_change, nuts)
    out_dir <- file.path(change_dir, crop_name)
    dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
    stem <- file.path(out_dir, paste0(inca_name, "_", crop_name))
    saveRDS(result, paste0(stem, ".rds"))
    write.xlsx(as.data.frame(result), paste0(stem, ".xlsx"))
    message("Mean change computed: ", crop_name)
  }, error = function(e) {
    message("Skipped ", crop_name, ": ", conditionMessage(e))
  })
}

# 3. Crop yield shocks ---------------------------------------------------------

id_cols <- c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares",
             "base_name_crop")

for (crop_dir in list.dirs(change_dir, recursive = FALSE)) {
  crop_name <- basename(crop_dir)
  dep <- crop_dependency(crop_name, dependency)
  out_dir <- file.path(shocks_dir, inca_name, crop_name)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

  xlsx_file <- list.files(crop_dir, pattern = "\\.xlsx$", full.names = TRUE)
  if (length(xlsx_file) > 0) {
    tryCatch({
      df <- read.xlsx(xlsx_file[1])
      shock_cols <- setdiff(names(df), id_cols)
      df[shock_cols] <- lapply(df[shock_cols], apply_dependency, dependency = dep)
      stem <- tools::file_path_sans_ext(basename(xlsx_file[1]))
      stem <- file.path(out_dir, paste0("shock_", stem))
      write.xlsx(df, paste0(stem, ".xlsx"))
      write.csv(df, paste0(stem, ".csv"), row.names = FALSE)
    }, error = function(e) {
      message("Skipped ", xlsx_file[1], ": ", conditionMessage(e))
    })
  }

  rds_file <- list.files(crop_dir, pattern = "\\.rds$", full.names = TRUE)
  if (length(rds_file) > 0) {
    tryCatch({
      v <- readRDS(rds_file[1])
      for (col in setdiff(names(v), id_cols)) {
        v[[col]] <- apply_dependency(v[[col]], dep)
      }
      saveRDS(v, file.path(out_dir, paste0("shock_", basename(rds_file[1]))))
    }, error = function(e) {
      message("Skipped ", rds_file[1], ": ", conditionMessage(e))
    })
  }
  message("Yield shock computed: ", crop_name)
}

# 4. Yield shocks by GTAP sector -----------------------------------------------

gtap_match <- read.xlsx(gtap_match_file)
sectors <- c("gro", "v_f", "osd", "c_b", "ocr")

# Crop shock tables grouped by GTAP sector
crop_tables <- list()
for (i in seq_len(nrow(gtap_match))) {
  crop_name <- gtap_match$shock_crop_names[i]
  sector <- as.character(gtap_match$GTAP.11[i])

  crop_dir <- file.path(shocks_dir, inca_name, crop_name)
  if (!dir.exists(crop_dir)) {
    warning("Crop folder not found: ", crop_dir)
    next
  }
  shock_file <- list.files(crop_dir, pattern = "^shock_.*\\.xlsx$", full.names = TRUE)
  if (length(shock_file) == 0) {
    warning("No shock_*.xlsx file found in: ", crop_dir)
    next
  }
  data <- tryCatch(read.xlsx(shock_file[1]), error = function(e) {
    warning("Error reading file: ", shock_file[1], " -> ", conditionMessage(e))
    NULL
  })
  if (is.null(data)) next

  if (is.null(crop_tables[[sector]])) crop_tables[[sector]] <- list()
  crop_tables[[sector]][[crop_name]] <- data
}

gtap_dir <- file.path(shocks_dir, "GTAP_shocks", "GTAP_cum_2020_2080")
dir.create(gtap_dir, recursive = TRUE, showWarnings = FALSE)

for (sector in intersect(sectors, names(crop_tables))) {
  save_table(weighted_sector_mean(crop_tables[[sector]], "^RCP"),
             file.path(gtap_dir, paste0("mean_shocks_GTAP_", sector)))
}

# 5. Yield shocks by GTAP sector for the regions of the economic model ---------

regions <- read.xlsx(regions_file)[, 1:3]  # NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU

final_dir <- file.path(shocks_dir, "GTAP_shocks", "GTAP_final_pollination_shocks")
dir.create(final_dir, recursive = TRUE, showWarnings = FALSE)

for (f in list.files(gtap_dir, pattern = "^mean_shocks_GTAP_.*\\.xlsx$", full.names = TRUE)) {
  sector <- sub("^mean_shocks_GTAP_(.*)\\.xlsx$", "\\1", basename(f))
  shocks <- read.xlsx(f) %>%
    select(NUTS_ID, starts_with("RCP"))
  final <- regions %>%
    left_join(shocks, by = "NUTS_ID") %>%
    mutate(crop_group = sector, .before = 1)
  save_table(final, file.path(final_dir, paste0("shock_", sector)))
}
