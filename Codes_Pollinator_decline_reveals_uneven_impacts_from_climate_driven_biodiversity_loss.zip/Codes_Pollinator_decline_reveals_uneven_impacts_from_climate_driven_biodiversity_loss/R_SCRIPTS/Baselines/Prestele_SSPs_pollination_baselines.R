#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# This file produces pollination potential projections and % changes. 
# Pollination potential projections are generated starting from INCA_2000_2080 data with climate change shock from Prestele et al., 2021,
# i.e. the % change in average pollinator presence under different climate scenarios (rcp2.6; rcp4.5; rcp8.5) and land use trajectories (SSPs 1,3,5)
# These changes are derived from the COMB experiment. 

# Output files:
# Prestele_SSPs_mean_prob_all_species.tif: mean pollinators probablility under SSPsate change from Prestele 2021
# Prestele_SSPs_2010_pct_2050_2080.tif : total % changes of mean probability of occurrence in each RCP scenario in 2050 and 2080 respect to base year 2010
# Prestele_SSPs_pct_change_2020_2080.tif = Prestele 5 years shock on pollination probability (5y % increase) NOT cumulative in each SSPsate scenario due to SSPs
# Prestele_SSPs_pct_cum_2020_2080.tif : Prestele 5 years shock of pollination probability (5y % increase) CUMULATIVE (y3= y1+y2) in each RCP wrt 2020

# Prestele_SSPs_INCA_poll_potent_2020_2080.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080 baseline with SSPsate shocks (RCP scenarios)
# Prestele_SSPs_INCA_pct_2020_2080.tif: Shock on pollination potential due to SSPsate (under RCP scenarios) as % change respect to baseline INCA_2020_2080 value in the same year
# Prestele_SSPs_INCA_cum_2020_2080.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios

# Prestele_SSPs_INCA_poll_pot_2020_2080_policy.tif: Pollination potential projections (2020-2080) based on INCA_2020_2080_policy baseline with SSPs shocks (RCP scenarios)
# Prestele_SSPs_INCA_pct_2020_2080_policy.tif: Shock on pollination potential due to SSPsate (under RCP scenarios) as % change respect to baseline INCA_2020_2080_policy value in the same year
# Prestele_SSPs_INCA_cum_2020_2080_policy.tif : Cumulative shock in each year respect to base year (% change in pollination potential respect to 2020 baseline value), under RCP scenarios and policy applied 

# baselines_pollination_potential_means_2020_2080.xlsx : means of all rasters
# same FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------


rm(list = ls())  
gc()

# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)

wd = paste0('G:/My Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

output_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/Prestele_SSPs/')
output_baselines_nuts  = paste0(wd, '/POTENTIAL/baselines_NUTS/Prestele_SSPs/')
inca_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/INCA')
Prestele_data = paste0(wd, 'POTENTIAL/input_pollination/Prestele_data')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Load the INCA_2020_2080 baselines
setwd(inca_baselines)
INCA_2020_2080 <- rast("INCA_2020_2080.tif")
INCA_2020_2080_policy <- rast("INCA_2020_2080_policy.tif")
INCA_2020 = INCA_2020_2080$`2020`

# Load the Prestele SSPs probability file for SSPs shoks on pollinators 
setwd(Prestele_data)
probability = read.csv("Bumblebee-Projections-Probability.csv", header=T)
variable.names(probability)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
setwd(output_baselines)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
gc()
#--------------------------------------------------------------------------------------------------------------------
# A) Future pollination potential projections based on INCA 2020-2080 baseline with climate change and NO conservation policy
#---------------------------------------------------------------------------------------------------------------
# PROCESS PRESTELE DATA 
# First work on Prestele data to produce % shocks on pollinators 
#  FIND GRANULARITY
x_diff <- min(diff(sort(unique(probability$X))))
y_diff <- min(diff(sort(unique(probability$Y))))

granularity_km2 <- (x_diff * y_diff) / 1e6
cat("✅ Spatial resolution:\n")
cat("  X (m):", x_diff, "\n")
cat("  Y (m):", y_diff, "\n")
cat("  Cell area:", granularity_km2, "km²\n")

# PROCESS ALL COMBINATIONS and COMBINE ALL INTO RASTER STACK
# this loop rasterize the csv, extracting information about the probability of occurrence of each species in each year/scenario
# then the total summed probability is assessed as the sum of all the probability of each species

# Identify species columns
species_cols <- setdiff(names(probability), c("X", "Y", "Scenario", "Year"))
# Get unique combinations
groups <- dplyr::distinct(probability, Scenario, Year)
# Raster list
raster_list <- list()
for (i in seq_len(nrow(groups))) {
  scen <- groups$Scenario[i]
  yr <- groups$Year[i]
  cat("Processing:", scen, "-", yr, "\n")
  # Filter + sum
  summed <- probability %>%
    dplyr::filter(Scenario == scen, Year == yr) %>%
    dplyr::rowwise() %>%
    dplyr::mutate(total_probability = sum(c_across(all_of(species_cols)))) %>%
    dplyr::ungroup() %>%
    dplyr::select(X, Y, total_probability)
  # Spatial -> Raster
  sp::coordinates(summed) <- ~ X + Y
  sp::proj4string(summed) <- CRS("+proj=utm +zone=32 +datum=WGS84 +units=m +no_defs")
  r <- raster::rasterFromXYZ(as.data.frame(summed))
  # Name & save
  name <- paste0(scen, "_", yr)
  names(r) <- name
  raster_list[[name]] <- r  }

# COMBINE ALL INTO STACK 
probability_all_species_sum <- stack(raster_list)

probability_all_species_sum_rast = rast(probability_all_species_sum)

# Resample the SpatRaster to match the resolution and extent of INCA_2020
probability_all_species_sum_rast <- resample(probability_all_species_sum_rast, INCA_2020, method = "bilinear")
names(probability_all_species_sum_rast)

# Compute the mean value of all species probability (0-1)
mean_probability_all_species = probability_all_species_sum_rast/47

gc()
#####
## CREATE RASTER WITH % CHANGES in 2050 and 2080 RESPECT TO 2010 BASE YEAR

base <- probability_all_species_sum[[1]]
baseline_name <- names(probability_all_species_sum)[1]
cat("Baseline layer:", baseline_name, "\n")
#  Initialize list
pct_change_list <- list()
#  Loop through other layers
for (i in 2:nlayers(probability_all_species_sum)) {
  lyr <- probability_all_species_sum[[i]]
  lyr_name <- names(probability_all_species_sum)[i]
  # Calculate % change
  pct_change <- overlay(lyr, base, fun = function(x, base) {
    result <- (x - base) / base * 100
    result[is.infinite(result) | is.nan(result)] <- NA
    return(result)})
  names(pct_change) <- paste0("pct_change_", lyr_name)
  pct_change_list[[i - 1]] <- pct_change }
pct_change_stack <- stack(pct_change_list)

# Pulisco dal 99° percentile max che è fuori scala
values_all <- getValues(pct_change_stack)
values_all <- as.vector(values_all)  # flatten to single numeric vector
values_all <- values_all[!is.na(values_all)]
# Calcola vmax = 99° percentile dei valori positivi
vmax <- quantile(values_all[values_all > 0], probs = 0.99)

gc()

pct_change_stack <- stack(lapply(1:nlayers(pct_change_stack), function(i) {
  r <- pct_change_stack[[i]]
  r_clipped <- calc(r, function(x) {
    x[x > vmax] <- vmax
    return(x)})
  names(r_clipped) <- names(r)
  return(r_clipped)}))

pct_change = rast(pct_change_stack)
pct_change <- resample(pct_change, INCA_2020, method = "bilinear")
names(pct_change)

keep <- c(
  "pct_change_COMB.RCP2_6.SSP1_2050",
  "pct_change_COMB.RCP2_6.SSP1_2080",
  "pct_change_COMB.RCP4_5.SSP1_2050",
  "pct_change_COMB.RCP4_5.SSP1_2080",
  "pct_change_COMB.RCP4_5.SSP3_2050",
  "pct_change_COMB.RCP4_5.SSP3_2080",
  "pct_change_COMB.RCP8_5.SSP3_2050",
  "pct_change_COMB.RCP8_5.SSP3_2080",
  "pct_change_COMB.RCP8_5.SSP5_2050",
  "pct_change_COMB.RCP8_5.SSP5_2080"
)

SSPs_pct_change_2010_2050_2080 <- pct_change[[keep]]
SSPs_pct_change_2010_2050_2080 <- round(SSPs_pct_change_2010_2050_2080, 0)

old_names <- names(SSPs_pct_change_2010_2050_2080)
new_names <- old_names |>
  gsub("pct_change_COMB\\.", "pct_change_", x = _) |>
  gsub("\\.", "_", x = _)

names(SSPs_pct_change_2010_2050_2080) <- new_names

######
# CREATE RASTER WITH ANNUAL % CHANGE FOR EACH RCPs from 2020 to 2080  

# Loops through the three climate scenarios (RCP2_6, RCP4_5, RCP8_5).
# Applies the exponential decay formula to match the changes in 2050 and 2080 based on the provided percentage changes.
# Computes the decay rates (r) for each pixel. 
# The SSPs raster is based on values from 2010, and the percentage change values for 2050 and 2080 reflect changes from 2010.
# The lower-resolution SSPs rasters are upscaled to the higher-resolution INCA raster.

# Extract the layers for each RCP scenario (2050 and 2080)
rcp_2050 <- SSPs_pct_change_2010_2050_2080[[c(1, 3, 5, 7, 9)]]  # Layers for 2050
rcp_2080 <- SSPs_pct_change_2010_2050_2080[[c(2, 4, 6, 8, 10)]]  # Layers for 2080

# Calculate the 5-year changes from 2010 to 2050 (linear interpolation)
change_2010_2050 <- rcp_2050 / 8  # 8 intervals of 5 years between 2010 and 2050
# Calculate the 5-year changes from 2050 to 2080 (linear interpolation)
change_2050_2080 <- (rcp_2080 - rcp_2050) / 6  # 6 intervals of 5 years between 2050 and 2080
# Combine the changes to create a final raster with linear trends
five_year_pct_change <- c(change_2010_2050, change_2050_2080)

# RCP2.6 (SSP1)
base_layer <- five_year_pct_change[["pct_change_RCP2_6_SSP1_2050"]]

SSP1_2_6_2020_2080 <- rep(base_layer, 13)
SSP1_2_6_2020_2080[[1]] = setValues(SSP1_2_6_2020_2080[[1]], 0)
SSP1_2_6_2020_2080[[2:7]]  = rep(five_year_pct_change[["pct_change_RCP2_6_SSP1_2050"]], 6)
SSP1_2_6_2020_2080[[8:13]] = rep(five_year_pct_change[["pct_change_RCP2_6_SSP1_2080"]], 6)
names(SSP1_2_6_2020_2080) <- paste0("SSP1_2_6_", seq(2020, 2080, 5))
gc()

# RCP4.5 (SSP1)
base_layer <- five_year_pct_change[["pct_change_RCP4_5_SSP1_2050"]]

SSP1_4_5_2020_2080 <- rep(base_layer, 13)
SSP1_4_5_2020_2080[[1]] = setValues(SSP1_4_5_2020_2080[[1]], 0)
SSP1_4_5_2020_2080[[2:7]]  = rep(five_year_pct_change[["pct_change_RCP4_5_SSP1_2050"]], 6)
SSP1_4_5_2020_2080[[8:13]] = rep(five_year_pct_change[["pct_change_RCP4_5_SSP1_2080"]], 6)
names(SSP1_4_5_2020_2080) <- paste0("SSP1_4_5_", seq(2020, 2080, 5))
gc()

# RCP4.5 (SSP3)
base_layer <- five_year_pct_change[["pct_change_RCP4_5_SSP3_2050"]]

SSP3_4_5_2020_2080 <- rep(base_layer, 13)
SSP3_4_5_2020_2080[[1]] = setValues(SSP3_4_5_2020_2080[[1]], 0)
SSP3_4_5_2020_2080[[2:7]]  = rep(five_year_pct_change[["pct_change_RCP4_5_SSP3_2050"]], 6)
SSP3_4_5_2020_2080[[8:13]] = rep(five_year_pct_change[["pct_change_RCP4_5_SSP3_2080"]], 6)
names(SSP3_4_5_2020_2080) <- paste0("SSP3_4_5_", seq(2020, 2080, 5))
gc()

#RCP8.5 (SSP3)
base_layer <- five_year_pct_change[["pct_change_RCP8_5_SSP3_2050"]]

SSP3_8_5_2020_2080 <- rep(base_layer, 13)
SSP3_8_5_2020_2080[[1]] = setValues(SSP3_8_5_2020_2080[[1]], 0)
SSP3_8_5_2020_2080[[2:7]]  = rep(five_year_pct_change[["pct_change_RCP8_5_SSP3_2050"]], 6)
SSP3_8_5_2020_2080[[8:13]] = rep(five_year_pct_change[["pct_change_RCP8_5_SSP3_2080"]], 6)
names(SSP3_8_5_2020_2080) <- paste0("SSP3_8_5_", seq(2020, 2080, 5))
gc()


#RCP8.5 (SSP5)
base_layer <- five_year_pct_change[["pct_change_RCP8_5_SSP5_2050"]]

SSP5_8_5_2020_2080 <- rep(base_layer, 13)
SSP5_8_5_2020_2080[[1]] = setValues(SSP5_8_5_2020_2080[[1]], 0)
SSP5_8_5_2020_2080[[2:7]]  = rep(five_year_pct_change[["pct_change_RCP8_5_SSP5_2050"]], 6)
SSP5_8_5_2020_2080[[8:13]] = rep(five_year_pct_change[["pct_change_RCP8_5_SSP5_2080"]], 6)
names(SSP5_8_5_2020_2080) <- paste0("SSP5_8_5_", seq(2020, 2080, 5))
gc()


# combine in a single raster
SSPs_pct_change_2020_2080 <- c(SSP1_2_6_2020_2080,
                               SSP1_4_5_2020_2080,
                               SSP3_4_5_2020_2080,
                               SSP3_8_5_2020_2080,
                               SSP5_8_5_2020_2080)
names(SSPs_pct_change_2020_2080)
SSPs_pct_change_2020_2080 <- app( SSPs_pct_change_2020_2080, fun = function(x) round(x, 2))

gc()

# CREATE RASTER WITH CUMULATIVE % CHANGE FOR EACH RCPs from 2020 to 2080 (SSPs_pct_change_2020_2080)

pct_change_SSP1_2_6 <- SSPs_pct_change_2020_2080[[grep("SSP1_2_6_", names(SSPs_pct_change_2020_2080))]]
pct_change_SSP1_4_5 <- SSPs_pct_change_2020_2080[[grep("SSP1_4_5_", names(SSPs_pct_change_2020_2080))]]
pct_change_SSP3_4_5 <- SSPs_pct_change_2020_2080[[grep("SSP3_4_5_", names(SSPs_pct_change_2020_2080))]]
pct_change_SSP3_8_5 <- SSPs_pct_change_2020_2080[[grep("SSP3_8_5_", names(SSPs_pct_change_2020_2080))]]
pct_change_SSP5_8_5 <- SSPs_pct_change_2020_2080[[grep("SSP5_8_5_", names(SSPs_pct_change_2020_2080))]]

shock_cum_SSP1_2_6 <- app(pct_change_SSP1_2_6, fun = cumsum)
shock_cum_SSP1_4_5 <- app(pct_change_SSP1_4_5, fun = cumsum)
shock_cum_SSP3_4_5 <- app(pct_change_SSP3_4_5, fun = cumsum)
shock_cum_SSP3_8_5 <- app(pct_change_SSP3_8_5, fun = cumsum)
shock_cum_SSP5_8_5 <- app(pct_change_SSP5_8_5, fun = cumsum)


SSPs_pct_cumulative_2020_2080= c(shock_cum_SSP1_2_6, shock_cum_SSP1_4_5, shock_cum_SSP3_4_5,shock_cum_SSP3_8_5, shock_cum_SSP5_8_5)
SSPs_pct_cumulative_2020_2080 <- app( SSPs_pct_cumulative_2020_2080, fun = function(x) round(x, 2))


#################
# CREATE POLLINATION POTENTIAL PROJECTIONS FROM 2020 TO 2080 FOR EACH RCPs 
# Future pollination potential projections based on INCA 2018 with SSPsate change and NO CONSERVATION POLICY

INCA_SSP1_2_6_2020_2080 <-  (1 + shock_cum_SSP1_2_6 / 100) * INCA_2020_2080 
INCA_SSP1_4_5_2020_2080 <-  (1 + shock_cum_SSP1_4_5 / 100) * INCA_2020_2080 
INCA_SSP3_4_5_2020_2080 <-  (1 + shock_cum_SSP3_4_5 / 100) * INCA_2020_2080
INCA_SSP3_8_5_2020_2080 <-  (1 + shock_cum_SSP3_8_5 / 100) * INCA_2020_2080
INCA_SSP5_8_5_2020_2080 <-  (1 + shock_cum_SSP5_8_5 / 100) * INCA_2020_2080

gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_SSP1_2_6_2020_2080 <- clamp(INCA_SSP1_2_6_2020_2080, lower = 0, upper = 1)
INCA_SSP1_4_5_2020_2080 <- clamp(INCA_SSP1_4_5_2020_2080, lower = 0, upper = 1)
INCA_SSP3_4_5_2020_2080 <- clamp(INCA_SSP3_4_5_2020_2080, lower = 0, upper = 1)
INCA_SSP3_8_5_2020_2080 <- clamp(INCA_SSP3_8_5_2020_2080, lower = 0, upper = 1)
INCA_SSP5_8_5_2020_2080 <- clamp(INCA_SSP5_8_5_2020_2080, lower = 0, upper = 1)

INCA_SSPs_pollination_potential_2020_2080 <- c(INCA_SSP1_2_6_2020_2080,
                                               INCA_SSP1_4_5_2020_2080,
                                               INCA_SSP3_4_5_2020_2080,
                                               INCA_SSP3_8_5_2020_2080,
                                               INCA_SSP5_8_5_2020_2080)

names(INCA_SSPs_pollination_potential_2020_2080)
INCA_SSPs_pollination_potential_2020_2080 <- app( INCA_SSPs_pollination_potential_2020_2080, fun = function(x) round(x, 2))

 
#----------------------------------
#################   
#  Climate SSPs  % SHOCK ON POLLINATION POTENTIAL RESPECT TO BASELINE
# It measure the shock that baseline pollination potential will obtain under SSPsate change respect to baseline

pct_change_SSP1_2_6 <- (INCA_SSP1_2_6_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP1_4_5 <- (INCA_SSP1_4_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP3_4_5 <- (INCA_SSP3_4_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP3_8_5 <- (INCA_SSP3_8_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP5_8_5 <- (INCA_SSP5_8_5_2020_2080 - INCA_2020_2080) / INCA_2020_2080 * 100

INCA_SSPs_pct_change_2020_2080 <- c(pct_change_SSP1_2_6, pct_change_SSP1_4_5, pct_change_SSP3_4_5, pct_change_SSP3_8_5, pct_change_SSP5_8_5)

INCA_SSPs_pct_change_2020_2080 <- app( INCA_SSPs_pct_change_2020_2080, fun = function(x) round(x, 2))


# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_SSPs_pct_cumulative_2020_2080 <- (INCA_SSPs_pollination_potential_2020_2080 - INCA_2020) / INCA_2020 * 100
INCA_SSPs_pct_cumulative_2020_2080 <- app(INCA_SSPs_pct_cumulative_2020_2080, fun = function(x) round(x, 2))


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

##  save 
writeRaster(mean_probability_all_species, "Prestele_SSPs_mean_prob_all_species.tif", overwrite = TRUE)
writeRaster(SSPs_pct_change_2010_2050_2080, filename = "Prestele_SSPs_2010_pct_2050_2080.tif",  overwrite = TRUE)
writeRaster(SSPs_pct_change_2020_2080, "Prestele_SSPs_pct_change_2020_2080.tif", overwrite = TRUE)
writeRaster(SSPs_pct_cumulative_2020_2080, "Prestele_SSPs_pct_cum_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_SSPs_pollination_potential_2020_2080, "Prestele_SSPs_INCA_poll_potent_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_SSPs_pct_change_2020_2080, "Prestele_SSPs_INCA_pct_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_SSPs_pct_cumulative_2020_2080, "Prestele_SSPs_INCA_cum_2020_2080.tif", overwrite = TRUE)

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# C) Future pollination potential projections based on INCA_2020_2080 with climate change (SSPS) and CONSERVATION POLICY APPLIED 
#---------------------------------------------------------------------------------------------------------------------

# Apply year % shock for each RCPs on INCA 2020_2080 pollination potential under the conservation policy scenario.
gc()
INCA_SSP1_2_6_2020_2080_policy <-  (1 + shock_cum_SSP1_2_6 / 100) * INCA_2020_2080_policy 
INCA_SSP1_4_5_2020_2080_policy <-  (1 + shock_cum_SSP1_4_5 / 100) * INCA_2020_2080_policy 
INCA_SSP3_4_5_2020_2080_policy <-  (1 + shock_cum_SSP3_4_5 / 100) * INCA_2020_2080_policy
INCA_SSP3_8_5_2020_2080_policy <-  (1 + shock_cum_SSP3_8_5 / 100) * INCA_2020_2080_policy
INCA_SSP5_8_5_2020_2080_policy <-  (1 + shock_cum_SSP5_8_5 / 100) * INCA_2020_2080_policy


gc()
# Limita i valori a un intervallo compreso tra 0 e 1
INCA_SSP1_2_6_2020_2080_policy <- clamp(INCA_SSP1_2_6_2020_2080_policy, lower = 0, upper = 1)
INCA_SSP1_4_5_2020_2080_policy <- clamp(INCA_SSP1_4_5_2020_2080_policy, lower = 0, upper = 1)
INCA_SSP3_4_5_2020_2080_policy <- clamp(INCA_SSP3_4_5_2020_2080_policy, lower = 0, upper = 1)
INCA_SSP3_8_5_2020_2080_policy <- clamp(INCA_SSP3_8_5_2020_2080_policy, lower = 0, upper = 1)
INCA_SSP5_8_5_2020_2080_policy <- clamp(INCA_SSP5_8_5_2020_2080_policy, lower = 0, upper = 1)

INCA_SSPs_pollination_potential_2020_2080_policy <- c(INCA_SSP1_2_6_2020_2080_policy,
                                                      INCA_SSP1_4_5_2020_2080_policy,
                                                      INCA_SSP3_4_5_2020_2080_policy,
                                                      INCA_SSP3_8_5_2020_2080_policy,
                                                      INCA_SSP5_8_5_2020_2080_policy)

names(INCA_SSPs_pollination_potential_2020_2080_policy)


#################   
#  Climate (SSPS) ANNUAL % SHOCK ON POLLINATION POTENTIAL RESPECT TO 2020 WITH CONSERVATION
# This raster contain the shock to be used when both the SSPsate shock and the conservation policies are active. 
# It measure the shock that baseline pollination potential will obtain under a conservation policy scenario

pct_change_SSP1_2_6_policy <- (INCA_SSP1_2_6_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP1_4_5_policy <- (INCA_SSP1_4_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP3_4_5_policy <- (INCA_SSP3_4_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP3_8_5_policy <- (INCA_SSP3_8_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
pct_change_SSP5_8_5_policy <- (INCA_SSP5_8_5_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100

INCA_SSPs_pct_change_2020_2080_policy <- c(pct_change_SSP1_2_6_policy, pct_change_SSP1_4_5_policy, pct_change_SSP3_4_5_policy, pct_change_SSP3_8_5_policy, pct_change_SSP5_8_5_policy)
INCA_SSPs_pct_change_2020_2080_policy <- app( INCA_SSPs_pct_change_2020_2080_policy, fun = function(x) round(x, 2))

# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_SSPs_pct_cumulative_2020_2080_policy <- (INCA_SSPs_pollination_potential_2020_2080_policy - INCA_2020) / INCA_2020 * 100
INCA_SSPs_pct_cumulative_2020_2080_policy <- app(INCA_SSPs_pct_cumulative_2020_2080_policy, fun = function(x) round(x, 2))


# save
writeRaster(INCA_SSPs_pollination_potential_2020_2080_policy, filename = "Prestele_SSPs_INCA_poll_pot_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_SSPs_pct_change_2020_2080_policy, filename = "Prestele_SSPs_INCA_pct_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_SSPs_pct_cumulative_2020_2080_policy, filename = "Prestele_SSPs_INCA_cum_2020_2080_policy.tif", overwrite = TRUE)

#-----------------------------------------------------------------------------------------



## some statistics - means

# Function to extract mean values from all layers of a SpatRaster
extract_means <- function(rast_obj, dataset_name) {
  layer_names <- names(rast_obj)
  means <- global(rast_obj, mean, na.rm = TRUE)
  
  # Create data frame
  df <- data.frame(
    Layer = layer_names,
    Mean = round(means[, 1], 5),
    Dataset = dataset_name )
  return(df)}

# Compute mean values

i <- extract_means(SSPs_pct_change_2010_2050_2080, "Pestele_SSPs_2010_pct_2050_2080")
l <- extract_means(SSPs_pct_change_2020_2080, "Prestele_SSPs_pct_change_2020_2080")
m <- extract_means(INCA_SSPs_pollination_potential_2020_2080, "Prestele_SSPs_INCA_poll_potent_2020_2080")
n <- extract_means(SSPs_pct_cumulative_2020_2080, "Prestele_SSPs_pct_cum_2020_2080")
o <- extract_means(INCA_SSPs_pct_change_2020_2080, "Prestele_SSPs_INCA_pct_2020_2080")
p <- extract_means(INCA_SSPs_pollination_potential_2020_2080_policy, "Prestele_SSPs_INCA_poll_pot_2020_2080_policy")
q <- extract_means(INCA_SSPs_pct_change_2020_2080_policy, "Prestele_SSPs_INCA_pct_2020_2080_policy")


# Combine and export
means_all <- rbind(i,l,m,n,o,p,q)

# Save to CSV
write.xlsx(means_all, file = "beselines_pollination_potential_means_2020_2080.xlsx", row.names = FALSE)
write.csv(means_all, file = "beselines_pollination_potential_means_2020_2080.csv", row.names = FALSE)



#-------------------------------------------------------------------------
# CREATE FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 
#-------------------------------------------------------------------------

#-------------------------------------------------------------------------
# Load file .shp with NUTS3 boundaries 
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp")   ## Shapefile with NUts 1,2,3 boudaries 
# Rimuovi solo il livello NUTS3, mantieni 0, 1, 2
nuts <- nuts[nuts$LEVL_CODE != 3, ]
cat("Nuts regions retained:", nrow(nuts), "\n")

#------------------------

# Loop over input folders
for (input_path in output_baselines) {
  tif_files <- list.files(input_path, pattern = "Prestele_SSPs_INCA_cum_2020_2080.tif$", full.names = TRUE)
  
  for (tif_file in tif_files) {
    # Load raster
    INCA_raster <- rast(tif_file)
    
    # Crop NUTS to raster extent
    nuts_cropped <- crop(nuts, INCA_raster)
    
    # Extract mean values per polygon
    nuts_means <- extract(INCA_raster, nuts_cropped, fun = mean, na.rm = TRUE)
    
    # Remove polygons with NA (no raster coverage)
    valid_idx <- !is.na(nuts_means[,2])
    nuts_cropped <- nuts_cropped[valid_idx, ]
    nuts_means <- nuts_means[valid_idx, ]
    
    # Round the mean values to 2 decimals
    nuts_means[,-1] <- round(nuts_means[,-1], 2)
    
    # Combine with attributes
    INCA_NUTS <- cbind(nuts_cropped, nuts_means[,-1])
    INCA_NUTS_df <- as.data.frame(INCA_NUTS)
    
    # Codici non UE da escludere
    non_eu_codes <- c("AL","BA","CH","LI","MK","RS","TR","UA", "UK")
    # Filtra via i NUTS_ID che iniziano con codici non UE
    INCA_NUTS_df <- INCA_NUTS_df[!substr(INCA_NUTS_df$NUTS_ID, 1, 2) %in% non_eu_codes, ]
    
    #creo valori mean EU 
    eu_vals <- global(INCA_raster, fun = mean, na.rm = TRUE)
    EU_mean <- data.frame(
      NUTS_ID    = "EU",
      LEVL_CODE  = 0,
      CNTR_CODE  = "EU",
      NAME_LATN  = "EU",
      NUTS_NAME  = "EU",
      MOUNT_TYPE = NA,
      URBN_TYPE  = NA,
      COAST_TYPE = NA,
      t(round(eu_vals$mean, 2))
    )
    
    colnames(EU_mean)[9:ncol(EU_mean)] <- rownames(eu_vals)
    rownames(EU_mean) <- NULL
    
    INCA_NUTS_df=rbind(INCA_NUTS_df, EU_mean)
    
    INCA_NUTS_df <- INCA_NUTS_df[, !names(INCA_NUTS_df) %in% 
                                   c("NUTS_NAME", "MOUNT_TYPE", "URBN_TYPE", "COAST_TYPE")]
    
    # Create output subfolder named after the raster file
    base_name <- tools::file_path_sans_ext(basename(tif_file))
    subfolder <- paste0(output_baselines_nuts, "/", base_name)
    dir.create(subfolder, showWarnings = FALSE)
    
    # Save RDS
    saveRDS(INCA_NUTS, paste0(subfolder, "/", base_name, ".rds"))
    
    # Save Excel
    write.xlsx(INCA_NUTS_df, paste0(subfolder, "/", base_name, ".xlsx"))
    
    
    cat("✅ Processed:", base_name, "\n")
  }
} 

#------------------------------ 