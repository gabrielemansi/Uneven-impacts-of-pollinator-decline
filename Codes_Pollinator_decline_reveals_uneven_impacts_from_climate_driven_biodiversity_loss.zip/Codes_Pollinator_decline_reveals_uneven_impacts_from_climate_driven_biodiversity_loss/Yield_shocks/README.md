# Pollination potential and crop yield shocks for the EU, 2020–2080

R scripts that project the pollination potential of European ecosystems from 2020 to 2080 and
derive the resulting crop yield shocks by NUTS region and GTAP sector, for use in an economic
model. A baseline projection is built from the INCA crop pollination potential maps. Climate and
land-use change scenarios from three sets of pollinator projections (IIASA, Ghisbain et al.,
2024, and Prestele et al., 2021) are then applied to the baseline. The change in pollination
potential over the harvested area of each pollinator-dependent crop (CROPGRIDS), weighted by
the pollination dependency of the crop, gives its yield shock; crop shocks are then aggregated
to GTAP sectors and NUTS 0-2 regions. 

## Execution order

| Step | Script | Content |
|:----:|--------|---------|
| 1 | `INCA_pollination_baselines.R` | Baseline pollination potential, 2020–2080 (no climate change); CROPGRIDS harvested-area maps aligned with the INCA grid |
| 2 | `IIASA_CLIM_pollination_baselines.R` | IIASA, climate only: RCP2.6, RCP4.5, RCP7.0, RCP8.5 |
| 2 | `IIASA_SSPs_pollination_baselines.R` | IIASA, climate and land use (SSP2): RCP2.6, RCP4.5, RCP7.0 |
| 2 | `GHSB_pollination_baselines.R` | Ghisbain et al. (2024), climate and land use: SSP1-RCP2.6, SSP3-RCP6.0, SSP5-RCP8.5 |
| 2 | `Prestele_CLIM_pollination_baselines.R` | Prestele et al. (2021), climate only: RCP2.6, RCP4.5, RCP8.5 |
| 2 | `Prestele_SSPs_pollination_baselines.R` | Prestele et al. (2021), climate and land use: SSP1-RCP2.6, SSP1-RCP4.5, SSP3-RCP4.5, SSP3-RCP8.5, SSP5-RCP8.5 |
| 3 | `SSPs_Land.R` | Crop areas and land use under the SSPs (Goebel and Britz, 2025), by NUTS region and GTAP sector: crop-area weights for the SSP shocks and land-use tables for the calibration of the economic model |
| 4 | `IIASA_CLIM_pollination_shocks.R` | Crop yield shocks, IIASA climate only |
| 4 | `IIASA_SSPs_pollination_shocks.R` | Crop yield shocks, IIASA climate and land use |
| 4 | `GHSB_SSPs_pollination_shocks.R` | Crop yield shocks, Ghisbain et al. (2024) |
| 4 | `Prestele_CLIM_pollination_shocks.R` | Crop yield shocks, Prestele et al. (2021) climate only |
| 4 | `Prestele_SSPs_pollination_shocks.R` | Crop yield shocks, Prestele et al. (2021) climate and land use |
| 5 | `Impacts_wrt_2020.R` | Yield shocks of all datasets by GTAP sector and for the whole agricultural sector, weighted by the 2020 crop areas; EU summary for 2030, 2050 and 2070; range across scenarios in 2070 |

Dependencies between the steps:

- Step 1 is independent of steps 2.
- Step 2 scripts (`IIASA_SSPs_`, `GHSB_SSPs_` and `Prestele_SSPs_pollination_shocks.R`) read the pollination potential datasets. 

From the repository root:

```sh
# 1. Baseline
Rscript INCA_pollination_baselines.R

# 2. Pollination potential under the climate and land-use scenarios
Rscript IIASA_CLIM_pollination_baselines.R
Rscript IIASA_SSPs_pollination_baselines.R
Rscript GHSB_pollination_baselines.R
Rscript Prestele_CLIM_pollination_baselines.R
Rscript Prestele_SSPs_pollination_baselines.R

# 3. Crop areas and land use under the SSPs
Rscript SSPs_Land.R

# 4. Crop yield shocks
Rscript IIASA_CLIM_pollination_shocks.R
Rscript IIASA_SSPs_pollination_shocks.R
Rscript GHSB_SSPs_pollination_shocks.R
Rscript Prestele_CLIM_pollination_shocks.R
Rscript Prestele_SSPs_pollination_shocks.R

# 5. Yield shocks relative to 2020, all datasets
Rscript Impacts_wrt_2020.R
```

## Method in brief

**Crop areas and land use under the SSPs (1).** The NUTS 2 land use and land cover
projections of Goebel and Britz (2025) for 2020–2050 are aggregated by crop (irrigated and
rainfed areas summed) and by GTAP sector, from NUTS 2 to NUTS 1 and 0 regions, and matched to
the regions of the economic model. The % changes in area, relative to 2020 and over each 5-year
step, are computed for 2020–2050 and extended linearly to 2080. The crop tables weight the SSP
shocks of step 4; the land-use tables by GTAP sector, which include the rest of the world, are
used to calibrate the economic model.

**Crop yield shocks (2).** Crops area in the Eu is from FAO CROPGRIDS 2020. For each
crop, NUTS region, scenario and year, the % change in pollination potential relative to 2020 is
averaged over the harvested area of the crop and multiplied by the pollination dependency of the
crop. The crop shocks are averaged by GTAP sector (gro, v_f, osd, c_b, ocr), weighted by the
crop areas: the 2020 harvested areas for the climate-only datasets, and the 2020 areas scaled by
the projected change in crop area under the SSP of each scenario (step 3) for the climate and
land-use datasets. The sector shocks are joined to the regions of the economic model.

**Summary.** The crop shocks of the five datasets are averaged by GTAP sector and over
all crops, weighted by the 2020 harvested areas. The shocks of all 18 scenarios are combined for
the EU regions in 2030, 2050 and 2070, and their minimum, median and maximum in 2070 are computed
for each EU country and sector, with the EU mean weighted by crop area.

The header of each script describes its method, inputs and outputs in detail.

## Setup

### Software

R with the following packages:

| Package | Used for |
|---------|----------|
| `terra` | Raster and vector processing (steps 1, 2 and 4) |
| `openxlsx` | Excel input and output (all scripts) |
| `dplyr` | Table processing (steps 3, 4 and 5) |
| `tidyr`, `stringr` | Reshaping tables and processing land-use and region codes (`SSPs_Land.R`) |
| `ncdf4` | Reading the CROPGRIDS NetCDF files (step 1) |
| `raster` | Rasterising the Prestele et al. (2021) table (Prestele baseline scripts) |

```r
install.packages(c("terra", "openxlsx", "dplyr", "tidyr", "stringr", "ncdf4", "raster"))
```

### Paths

All paths are relative to `base_dir`, defined at the top of each script (default `"."`, the
working directory). Run the scripts from the repository root, or set `base_dir` to the folder
that contains the data folders described below. Output folders are created when needed.

## Input data

The input data are not included in this repository. The datasets listed below must be placed
in the following folders:

```text
<repository root>
├── EU_boundaries/
│   └── NUTS_RG_10M_2024_3035/
│       └── NUTS_RG_10M_2024_3035.shp           (and the other shapefile components)
├── DEMAND/
│   ├── AREA_crops/
│   │   ├── FAO_CROPGRIDS/
│   │   │   └── CROPGRIDSv1.08_NC_maps/
│   │   │       └── CROPGRIDSv1.08_<crop>.nc
│   │   ├── Shocks_GTAP_match.xlsx
│   │   ├── Final_pollination_shocks_GTAP.xlsx
│   │   └── SSP_changes/
│   │       ├── SSPs_land_use_data_expl.xlsx
│   │       └── NUTS2 Level Land Use and Land Cover Quantification/
│   │           └── LULC_NUTS2_AllSSPs.xlsx
│   └── DEPENDENCY_crops/
│       └── FAO_CROPGRIDS_pollinatio_dependency.xlsx
└── POTENTIAL/
    └── input_pollination/
        ├── INCA_data/
        │   └── potential_categories.tif
        ├── IIASA_data/
        │   ├── 03_climate_only_pollinators/
        │   │   └── EnsembleProjection_biome_dispersal_<ssp>_climate_only_mean_suitability.tif
        │   └── input_ssps/
        │       └── pollinator_mean_Ref_RCP<x>p<y>.tif
        ├── Ghisbian_data/
        │   └── Transfer/
        │       └── ESI_raster_*.tif
        └── Prestele_data/
            └── Bumblebee-Projections-Probability.csv
```

| Dataset | Files | Source |
|---------|-------|--------|
| INCA crop pollination potential, classes 1–4, for 2000, 2006, 2012 and 2018 | `potential_categories.tif` | Integrated system for Natural Capital Accounting (KIP INCA), European Commission, Joint Research Centre; method in Vallecillo et al. (2018) |
| Pollinator habitat suitability, climate-only experiment, 2015–2095 | `EnsembleProjection_biome_dispersal_<ssp>_climate_only_mean_suitability.tif`, with `<ssp>` = `ssp126`, `ssp245`, `ssp370`, `ssp585` | IIASA |
| Pollinator habitat suitability, SSP2 land use, 2020–2050 | `pollinator_mean_Ref_RCP2p6.tif`, `pollinator_mean_Ref_RCP4p5.tif`, `pollinator_mean_Ref_RCP7p0.tif` | IIASA |
| ESI rasters for 2000–2014 and, under SSP1, SSP3 and SSP5, for 2041–2060 and 2061–2080 | `ESI_raster_2000-2014_t0.tif`, `ESI_raster_<period>_<SSP>.tif` | Ghisbain et al. (2024) |
| Occurrence probability of 47 bumblebee species, 2010, 2050 and 2080 | `Bumblebee-Projections-Probability.csv` | Prestele et al. (2021) |
| CROPGRIDS v1.08 harvested area by crop, 0.05° | `CROPGRIDSv1.08_<crop>.nc` | Tang et al. (2024); data on [figshare](https://doi.org/10.6084/m9.figshare.22491997) |
| Land use and land cover by NUTS 2 region and SSP, 2020–2050 | `LULC_NUTS2_AllSSPs.xlsx` (columns `Scenario`, `Region`, `LandCover`, `LandUse` and one per year) | Goebel and Britz (2025); data on [Mendeley Data](https://data.mendeley.com/datasets/x4xfh2kcdy) |
| NUTS 2024 regions, 1:10 million, EPSG:3035 | `NUTS_RG_10M_2024_3035.shp` | [Eurostat GISCO](https://ec.europa.eu/eurostat/web/gisco/geodata/statistical-units/territorial-units-statistics) |
| Pollination dependency of the CROPGRIDS crops | `FAO_CROPGRIDS_pollinatio_dependency.xlsx` (columns `CROPGRIDS` and `Avg_impact_on_production`, average impact of pollinators on production, 0–1) | Prepared for this study |
| Match between CROPGRIDS crops, land-use classes and GTAP sectors | `Shocks_GTAP_match.xlsx` (columns `shock_crop_names`, `Land_Use`, `GTAP_number`, `GTAP.11`, `GTAP.11.description`, `Avg_impact_on_production`) | Prepared for this study |
| Regions of the economic model | `Final_pollination_shocks_GTAP.xlsx` (first three columns `NUTS_ID`, `LEVL_CODE`, `ICES_Reg_region_ACCREU`) | Prepared for this study |
| Match between land-use classes and GTAP sectors | `SSPs_land_use_data_expl.xlsx`, sheet `crops` (columns `Land_Use`, `Explanation`, `GTAP_11_sector`) | Prepared for this study |

For the tables prepared for this study, the table above gives the columns used by the scripts,
as read by `openxlsx::read.xlsx` (spaces replaced by dots). The other data are subject to the
terms of use of their original providers.

## Outputs

| Folder | Content |
|--------|---------|
| `POTENTIAL/baselines_pollination/INCA/` | INCA maps 2000–2018 (classes and rescaled), baseline pollination potential 2020–2080 (values and classes) and its % change relative to 2020 |
| `POTENTIAL/baselines_pollination/<dataset>/` | Pollinator indicator on the INCA grid, its % change per 5-year step and cumulative, projected pollination potential, its % difference from the baseline and its % change relative to 2020, mean of each layer |
| `POTENTIAL/baselines_NUTS/INCA/` | Means of the INCA rasters over NUTS 0–3 regions (`.xlsx` tables and `.rds` SpatVector files) |
| `POTENTIAL/baselines_NUTS/<dataset>/` | Means of `<dataset>_INCA_cum_2020_2080` over NUTS 0–2 regions and the EU (`.xlsx` table and `.rds` SpatVector file) |
| `DEMAND/AREA_crops/FAO_CROPGRIDS_rasters/` | CROPGRIDS harvested area by crop on the INCA grid |
| `DEMAND/AREA_crops/SSP_changes/NUTS2 Level Land Use and Land Cover Quantification/` | Crop areas and land use by GTAP sector, by NUTS region (intermediate tables of step 3) |
| `DEMAND/AREA_crops/SSP_changes/data_final/crops_land_use/` | Crop areas for the regions of the economic model and their % change, cumulative and per 5-year step, 2020–2080 (`Crops_Land_Use_SSPs_GTAP*`) |
| `DEMAND/AREA_crops/SSP_changes/data_final/land_use_cali/` | Land use by GTAP sector for the regions of the economic model and the rest of the world, and its % change, cumulative and per 5-year step, 2020–2080 (`Calib_Land_Use_SSPs_GTAP*`) |
| `DEMAND/POLL_change_area/<dataset>/<dataset>_INCA_cum_2020_2080/<crop>/` | Mean % change in pollination potential over the harvested area of the crop, by NUTS region |
| `FINAL_SHOCKS/<dataset>/<dataset>_INCA_cum_2020_2080/<crop>/` | Yield shock of the crop, by NUTS region (`shock_*`) |
| `FINAL_SHOCKS/<dataset>/GTAP_shocks/` | Yield shocks by GTAP sector: by NUTS region (`GTAP_cum_2020_2080/`) and for the regions of the economic model (`GTAP_final_pollination_shocks/`) for the climate-only datasets; for the regions of the economic model (`GTAP_2020_2080/`) for the climate and land-use datasets |
| `FINAL_SHOCKS/cum_wrt_2020/` | Yield shocks by GTAP sector and for the whole agricultural sector, all datasets (`<dataset>_INCA_cum_2020_2080pct_wrt_2020/`); EU summary (`EU_shocks_wrt_2020`); range across scenarios in 2070 (`all_shocks_2070_sensitivity_EU27`) |

`<dataset>` is `IIASA_CLIM`, `IIASA_SSPs`, `GHSB_SSPs`, `Prestele_CLIM` or `Prestele_SSPs`.
For GHSB, the dataset folders in `POTENTIAL/baselines_pollination/`, `DEMAND/POLL_change_area/`
and `FINAL_SHOCKS/` are named `Ghisbian_SSPs/`; file and subfolder names use `GHSB_SSPs`. The
main result of each step-2 script is `<dataset>_INCA_cum_2020_2080`: the % change in
pollination potential relative to 2020, by scenario and 5-year step. The main results of each
step-4 script are the yield shocks by GTAP sector for the regions of the economic model.

## References

- Ghisbain, G., et al. (2024). Projected decline in European bumblebee populations in the
  twenty-first century. *Nature*, 628. https://doi.org/10.1038/s41586-023-06471-0
- Goebel, T., & Britz, W. (2025). *NUTS2 Level Land Use and Land Cover Quantifications under the
  Shared Socio-Economic Pathways, 2020-2050* [Data set]. Mendeley Data.
  https://data.mendeley.com/datasets/x4xfh2kcdy
- Prestele, R., et al. (2021). Large variability in response to projected climate and land-use
  changes among European bumblebee species. *Global Change Biology*.
  https://doi.org/10.1111/gcb.15780
- Tang, F. H. M., Nguyen, T. H., Conchedda, G., Casse, L., Tubiello, F. N., & Maggi, F.
  (2024). CROPGRIDS: a global geo-referenced dataset of 173 crops. *Scientific Data*, 11, 413.
  https://doi.org/10.1038/s41597-024-03247-7
- Vallecillo, S., La Notte, A., Polce, C., Zulian, G., Alexandris, N., Ferrini, S., & Maes, J.
  (2018). *Ecosystem services accounting: Part I – Outdoor recreation and crop pollination*.
  EUR 29024 EN, Publications Office of the European Union. https://doi.org/10.2760/619793
