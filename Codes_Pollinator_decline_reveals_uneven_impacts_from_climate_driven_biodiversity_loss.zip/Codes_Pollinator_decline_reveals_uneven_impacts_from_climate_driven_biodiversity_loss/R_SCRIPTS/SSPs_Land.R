rm(list = ls())  
gc()
  

# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)
library(ncdf4)
library(stringr)

wd = paste0('D:/Il mio Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')


crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
crops_rasters = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS_rasters')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
AREA_crops = paste0(wd, "/DEMAND/AREA_crops/")
land_use_SSP = paste0(wd, "/DEMAND/AREA_crops/SSP_changes/NUTS2 Level Land Use and Land Cover Quantification")
crops_land_use_outputs = paste0(wd, "/DEMAND/AREA_crops/SSP_changes/data_final/crops_land_use")
calib_land_use_outputs = paste0(wd, "/DEMAND/AREA_crops/SSP_changes/data_final/land_use_cali")
#-------------------------------------------------------------------------

#-------------------------------------------------------------------------

# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]

#---------------------------------------------------------------------
# Import GTAP_sectors, land use and matching files 

setwd(AREA_crops)
Row_agg_Accreu <- file.path("Row_agg_Accreu.xlsx")
getSheetNames(Row_agg_Accreu)

GTAP_sectors <- read.xlsx(Row_agg_Accreu, sheet = "mapping_sectors") 
GTAP_crops <- GTAP_sectors[GTAP_sectors[[4]] == "Crops", ]
GTAP_crops = GTAP_crops[c(1:3)]

final_GTAP_aggr <- read.xlsx("Final_pollination_shocks_GTAP.xlsx")
final_GTAP_aggr=final_GTAP_aggr[c(1:3)]

Shocks_GTAP_match = read.xlsx("Shocks_GTAP_match.xlsx")

setwd(land_use_SSP)
LULC_NUTS2_AllSSPs = read.xlsx("LULC_NUTS2_AllSSPs.xlsx")

setwd(paste0(AREA_crops, "/SSP_changes"))
SSPs_land_use_data_expl= read.xlsx("SSPs_land_use_data_expl.xlsx", sheet="crops")
SSPs_land_use_data_regions =read.xlsx("SSPs_land_use_data_expl.xlsx", sheet="regions")
 
#---------------------------------------------------------------------
# Aggregate to match GTAP sectors and NUTS production shares
#-------------------------------------------------
# 1 ) CREO FILES per POLLINATION SHOCKS
#-------------------------------------------------

setwd(land_use_SSP)
# 1. Somma Irrigated e Rainfed
# Estrai il nome del crop dalla colonna Land_Use ed elimina i suffissi che generano errore 


NUTS2_AllSSPs_sum <- LULC_NUTS2_AllSSPs %>%
  mutate(
    Land_Use = as.character(LandUse),
    Land_Use = str_remove(Land_Use, "(_irr-a|_rai-a|-a)$"),
    Region   = str_remove(Region, "0000$")
  ) %>%
  group_by(Scenario, Region, LandCover, Land_Use) %>%
  summarise(across(`2020`:`2050`, sum), .groups = "drop")

# keep only  years of interest
NUTS2_AllSSPs_sum <- NUTS2_AllSSPs_sum[
  , c("Scenario", "Region", "LandCover", "Land_Use",
      "2020", "2025", "2030", "2035", "2040", "2045", "2050")]

# Esporta 
write.xlsx(NUTS2_AllSSPs_sum, "NUTS2_AllSSPs_sum.xlsx")


#-----------------------------------------------------------------------
# Aggrego per NUTS 0,1,2
#-----------------------------------------------------------------------
# rinomina colonna region in NUTS_ID
names(NUTS2_AllSSPs_sum)[2] <- "NUTS_ID"

# rinomino valori senza match perfetto
NUTS2_AllSSPs_sum <- NUTS2_AllSSPs_sum %>%
  mutate(NUTS_ID = case_when(
    NUTS_ID == "mlt" ~ "MT",
    NUTS_ID == "bgr" ~ "BG",
    NUTS_ID == "cyp" ~ "CY",
    NUTS_ID == "cze" ~ "CZ",
    NUTS_ID == "dnk" ~ "DK",
    NUTS_ID == "est" ~ "EE",
    NUTS_ID == "fin" ~ "FI",
    NUTS_ID == "hrv" ~ "HR",
    NUTS_ID == "hun" ~ "HU",
    NUTS_ID == "irl" ~ "IE",
    NUTS_ID == "ltu" ~ "LT",
    NUTS_ID == "lux" ~ "LU",
    NUTS_ID == "lva" ~ "LV",
    NUTS_ID == "mlt" ~ "MT",
    NUTS_ID == "svk" ~ "SK", 
    NUTS_ID == "svn" ~ "SI",
    TRUE ~ NUTS_ID   # tutti gli altri restano invariati
  ))

NUTS2_AllSSPs_sum <- NUTS2_AllSSPs_sum %>%
  mutate(NUTS_ID   = str_to_upper(NUTS_ID))     # <-- da minuscole a maiuscole    


# Funzione di aggregazione per un certo prefisso di NUTS_ID
aggregate_by_prefix <- function(df, n) {
  df %>%
    mutate(NUTS_ID = str_sub(NUTS_ID, 1, n)) %>%   # prefisso
    group_by(Scenario, LandCover, Land_Use, NUTS_ID) %>%
    summarise(across(`2020`:`2050`, sum), .groups = "drop")
}

# Calcoli per ciascun livello
agg2 <- aggregate_by_prefix(NUTS2_AllSSPs_sum, 2)  # prime 2 lettere
agg3 <- aggregate_by_prefix(NUTS2_AllSSPs_sum, 3)  # prime 3 lettere

# Combina tutto con il dataset originale
NUTS_0_2_AllSSPs_sum <- bind_rows(
  NUTS2_AllSSPs_sum,
  agg2, agg3
) %>%
  distinct()


NUTS2_AllSSPs_GTAP = merge(final_GTAP_aggr, NUTS_0_2_AllSSPs_sum, by="NUTS_ID", all.x=TRUE)

# Arrotondo a due decimali solo le colonne numeriche
num_cols <- sapply(NUTS2_AllSSPs_GTAP, is.numeric)
NUTS2_AllSSPs_GTAP[num_cols] <- lapply(NUTS2_AllSSPs_GTAP[num_cols], function(x) round(x, 2))


# Controlla quante righe duplicate ci sono
num_duplicates <- sum(duplicated(NUTS2_AllSSPs_GTAP))
num_duplicates


# Save
write.xlsx(NUTS_0_2_AllSSPs_sum,"Land_Use_SSPs_0_2.xlsx")
write.xlsx(NUTS2_AllSSPs_GTAP,"NUTS2_AllSSPs_GTAP.xlsx")

#...........................................................
# merge con GTAP crops categories 

Land_Use_SSPs_GTAP = merge(Shocks_GTAP_match, NUTS2_AllSSPs_GTAP, by="Land_Use", all.x=TRUE)

# Save
#write.xlsx(Land_Use_SSPs_GTAP,"Land_Use_SSPs_GTAP_match.xlsx")


#...........................................................

# Aggiungo totali aree cropland per NUTS  
Land_Use_SSPs_GTAP_total <- Land_Use_SSPs_GTAP %>%
  # togli la colonna LandCover
  select(-LandCover) %>%
  # raggruppa per NUTS_ID e Scenario
  group_by(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, Scenario) %>%
  # calcola la somma di tutte le colonne numeriche (anni)
  summarise(across(where(is.numeric), function(x) sum(x, na.rm = TRUE)),
            .groups = "drop")%>%
  # aggiungi le colonne fisse richieste
  mutate(
    Land_Use = "total",
    shock_crop_names = "total",
    GTAP_number = 0,
    GTAP.11 = "crops",
    GTAP.11.description = "crops",
    Avg_impact_on_production = NA
  )

# unisci al dataset originale
Land_Use_SSPs_GTAP <- bind_rows(
  Land_Use_SSPs_GTAP %>% select(-LandCover),
  Land_Use_SSPs_GTAP_total
)%>%
  # Elimina righe con Scenario NA
  filter(!is.na(Scenario))


non_match_GTAP <- final_GTAP_aggr %>%
  anti_join(Land_Use_SSPs_GTAP, by = "NUTS_ID")


#------- SAVE------------
setwd(crops_land_use_outputs)

write.xlsx(Land_Use_SSPs_GTAP,"Crops_Land_Use_SSPs_GTAP.xlsx")
write.csv(Land_Use_SSPs_GTAP,"Crops_Land_Use_SSPs_GTAP.csv")


#-----------------------------------------------------------------------
# Creo dataframe con le percentuali CUMULATE di cambiamento delle aree in ogni scenario 

# I valori dopo il 2050 sono ottenuti con interpolazione lineare 
names_gtap = names(Land_Use_SSPs_GTAP)


Land_Use_SSPs_GTAP_cum <- Land_Use_SSPs_GTAP %>%
  mutate(base_2020 = `2020`) %>%
  mutate(across(`2020`:`2050`,
                ~ ifelse(base_2020 == 0,
                         0,
                         (.x - base_2020) / base_2020 * 100))) %>%
  mutate(`2020` = 0) %>%
  rowwise() %>%
  mutate(
    slope = `2050` / 30,
    `2055` = `2050` + slope * 5,
    `2060` = `2050` + slope * 10,
    `2065` = `2050` + slope * 15,
    `2070` = `2050` + slope * 20,
    `2075` = `2050` + slope * 25,
    `2080` = `2050` + slope * 30
  ) %>%
  ungroup() %>%
  # 🔒 Impongo limite inferiore a -99%
  mutate(across(c(`2025`,`2030`,`2035`,`2040`,`2045`,`2050`,
                  `2055`,`2060`,`2065`,`2070`,`2075`,`2080`),
                ~ pmax(.x, -99))) %>%
  select(-slope, -base_2020) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))


# Creo valori per PL7, 8, ) come media di valori PL
PL_regions <- Land_Use_SSPs_GTAP_cum %>%
  filter(str_starts(NUTS_ID, "PL"))
PL7 <- PL_regions %>%
  group_by(
    Land_Use, shock_crop_names, GTAP_number, GTAP.11,
    GTAP.11.description, Avg_impact_on_production,
    LEVL_CODE, Scenario  ) %>%
  summarise(across(where(is.numeric), mean, na.rm = TRUE), .groups = "drop") %>%
  mutate(NUTS_ID = "PL7")

PL8 = PL7%>%
  mutate(NUTS_ID = "PL8")
PL9 = PL7%>%
  mutate(NUTS_ID = "PL9")
Land_Use_SSPs_GTAP_cum <- bind_rows(
  Land_Use_SSPs_GTAP_cum,PL7, PL8, PL9)
Land_Use_SSPs_GTAP_cum <- Land_Use_SSPs_GTAP_cum %>%
  mutate(
    ICES_Reg_region_ACCREU = case_when(
      NUTS_ID == "PL7" ~ "CentrePol",
      NUTS_ID == "PL8" ~ "EastPol",
      NUTS_ID == "PL9" ~ "Masovia",
      TRUE ~ ICES_Reg_region_ACCREU ))%>%
  distinct()

# Controlla quante righe duplicate ci sono
num_duplicates <- sum(duplicated(Land_Use_SSPs_GTAP_cum))
num_duplicates

#------- SAVE------------
setwd(crops_land_use_outputs)

write.xlsx(Land_Use_SSPs_GTAP_cum,"Crops_Land_Use_SSPs_GTAP_cum.xlsx")
write.csv(Land_Use_SSPs_GTAP_cum,"Crops_Land_Use_SSPs_GTAP_cum.csv")


#------- creo df wide ------------
year_cols <- c("2020","2025","2030","2035","2040","2045","2050",
               "2055","2060","2065","2070","2075","2080")

df_wide <- Land_Use_SSPs_GTAP_cum %>%
  pivot_longer(
    cols = all_of(year_cols),
    names_to = "Year",
    values_to = "Value"
  ) %>%
  mutate(Scenario_Year = paste0(Scenario, "_", Year)) %>%
  select(-Scenario, -Year) %>%
  pivot_wider(
    names_from = Scenario_Year,
    values_from = Value,
    values_fn = first   # prendi il primo valore in caso di duplicati
  )

# Controlla quante righe duplicate ci sono
num_duplicates <- sum(duplicated(df_wide))
num_duplicates

#------- SAVE------------
setwd(crops_land_use_outputs)

write.xlsx(df_wide,"Crops_Land_Use_SSPs_GTAP_cum_WIDE.xlsx")
write.csv(df_wide,"Crops_Land_Use_SSPs_GTAP_cum_WIDE.csv")


#----------------------------------------------------------------------------------------
# ------------------------------------------------------------
# Creo dataframe con le percentuali NON cumulative (anno su anno)
# ------------------------------------------------------------

years <- c("2020","2025","2030","2035","2040","2045","2050")

Land_Use_SSPs_GTAP_pct <- Land_Use_SSPs_GTAP %>%
  select(all_of(names_gtap))

# Calcolo variazioni anno su anno in modo robusto
for(i in 2:length(years)) {
  
  current_year  <- years[i]
  previous_year <- years[i-1]
  
  Land_Use_SSPs_GTAP_pct[[current_year]] <-
    ifelse(Land_Use_SSPs_GTAP[[previous_year]] == 0,
           0,
           (Land_Use_SSPs_GTAP[[current_year]] -
              Land_Use_SSPs_GTAP[[previous_year]]) /
             Land_Use_SSPs_GTAP[[previous_year]] * 100)
}

# Fisso 2020 = 0
Land_Use_SSPs_GTAP_pct$`2020` <- 0


# ------------------------------------------------------------
# Proiezione lineare dopo il 2050
# ------------------------------------------------------------

Land_Use_SSPs_GTAP_pct <- Land_Use_SSPs_GTAP_pct %>%
  rowwise() %>%
  mutate(
    slope = `2050` / 30,
    `2055` = `2050` + slope * 5,
    `2060` = `2050` + slope * 10,
    `2065` = `2050` + slope * 15,
    `2070` = `2050` + slope * 20,
    `2075` = `2050` + slope * 25,
    `2080` = `2050` + slope * 30
  ) %>%
  ungroup() %>%
  
  # ------------------------------------------------------------
# Impongo limite inferiore a -99% (no valori < -99)
# ------------------------------------------------------------
mutate(across(c("2025","2030","2035","2040","2045","2050",
                "2055","2060","2065","2070","2075","2080"),
              ~ pmax(.x, -99))) %>%
  
  select(-slope) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))

# Creo valori per PL7, 8, ) come media di valori PL
PL_regions <- Land_Use_SSPs_GTAP_pct %>%
  filter(str_starts(NUTS_ID, "PL"))
PL7 <- PL_regions %>%
  group_by(
    Land_Use, shock_crop_names, GTAP_number, GTAP.11,
    GTAP.11.description, Avg_impact_on_production,
    LEVL_CODE, Scenario  ) %>%
  summarise(across(where(is.numeric), mean, na.rm = TRUE), .groups = "drop") %>%
  mutate(NUTS_ID = "PL7")

PL8 = PL7%>%
  mutate(NUTS_ID = "PL8")
PL9 = PL7%>%
  mutate(NUTS_ID = "PL9")
Land_Use_SSPs_GTAP_pct <- bind_rows(
  Land_Use_SSPs_GTAP_pct,PL7, PL8, PL9)
Land_Use_SSPs_GTAP_pct <- Land_Use_SSPs_GTAP_pct %>%
  mutate(
    ICES_Reg_region_ACCREU = case_when(
      NUTS_ID == "PL7" ~ "CentrePol",
      NUTS_ID == "PL8" ~ "EastPol",
      NUTS_ID == "PL9" ~ "Masovia",
      TRUE ~ ICES_Reg_region_ACCREU ))%>%
  distinct()

# Controlla quante righe duplicate ci sono
num_duplicates <- sum(duplicated(Land_Use_SSPs_GTAP_pct))
num_duplicates


#------- SAVE------------
setwd(crops_land_use_outputs)

write.xlsx(Land_Use_SSPs_GTAP_pct,"Crops_Land_Use_SSPs_GTAP_5y.xlsx")
write.csv(Land_Use_SSPs_GTAP_pct,"Crops_Land_Use_SSPs_GTAP_5y.csv")

#------- creo df wide ------------
year_cols <- c("2020","2025","2030","2035","2040","2045","2050",
               "2055","2060","2065","2070","2075","2080")

df_wide <- Land_Use_SSPs_GTAP_pct %>%
  pivot_longer(
    cols = all_of(year_cols),
    names_to = "Year",
    values_to = "Value"
  ) %>%
  mutate(Scenario_Year = paste0(Scenario, "_", Year)) %>%
  select(-Scenario, -Year) %>%
  pivot_wider(
    names_from = Scenario_Year,
    values_from = Value,
    values_fn = first   # prendi il primo valore in caso di duplicati
  )

# Controlla quante righe duplicate ci sono
num_duplicates <- sum(duplicated(df_wide))
num_duplicates

#------- SAVE------------
setwd(crops_land_use_outputs)

write.xlsx(df_wide,"Crops_Land_Use_SSPs_GTAP_5y_WIDE.xlsx")
write.csv(df_wide,"Crops_Land_Use_SSPs_GTAP_5y_WIDE.csv")

  

#-------------------------------------------------


#-------------------------------------------------
# 2)  CREO FILES DI LAND USE SSPs per ICES CALIBRATION
#-------------------------------------------------
setwd(land_use_SSP)


land_use_SSP_match <- LULC_NUTS2_AllSSPs %>%
  # 1. Elimina le righe con Land_Use == "total" (case-insensitive se serve)
  filter(str_to_lower(LandUse) != "total") %>%
  mutate(
    Land_Use = as.character(LandUse),
    Land_Use = str_remove(Land_Use, "(-a)$"),
   # Land_Use = str_remove(Land_Use, "(_irr-a|_rai-a|-a)$"),
    Region   = str_remove(Region, "0000$")
  ) %>%
  group_by(Scenario, Region, LandCover, Land_Use) %>%
  summarise(across(`2020`:`2050`, sum), .groups = "drop")

# keep only  years of interest
land_use_SSP_match <- land_use_SSP_match[
  , c("Scenario", "Region", "LandCover", "Land_Use",
      "2020", "2025", "2030", "2035", "2040", "2045", "2050")]


# Check Intersezione dei valori
intersect(land_use_SSP_match$Land_Use, SSPs_land_use_data_expl$Land_Use)

no_match <- anti_join(land_use_SSP_match, 
                      SSPs_land_use_data_expl, 
                      by = "Land_Use")

land_use_SSP_match= merge(SSPs_land_use_data_expl, land_use_SSP_match, by='Land_Use')



# AGGREGO per scenario e settore GTAP11
land_use_SSP_match <- land_use_SSP_match %>%
  # togliamo le colonne che non servono
  select(-LandCover, -Explanation, -Land_Use) %>%
  # raggruppiamo per Scenario, Region e settore GTAP
  group_by(Scenario, Region, GTAP_11_sector) %>%
  # sommiamo tutte le colonne numeriche (gli anni)
  summarise(across(`2020`:`2050`, sum, na.rm = TRUE), .groups = "drop")

land_use_SSP_match <- land_use_SSP_match[
  , c("Scenario", "Region", "GTAP_11_sector",
      "2020", "2025", "2030", "2035", "2040", "2045", "2050")]


## Identifica duplicati sulle prime 4 colonne
dups_keys <- land_use_SSP_match %>%
  group_by( Scenario, Region, GTAP_11_sector) %>%
  filter(n() > 1) %>%
  ungroup()
# Messaggio informativo
if (nrow(dups_keys) > 0) {
  message("⚠️ Trovati ", nrow(dups_keys), 
          " duplicati sulle chiavi Scenario–Region–LandCover–Land_Use.")} else {
            message("✓ Nessun duplicato sulle prime 4 colonne.")}

# Rimuove i duplicati mantenendo una sola riga per combinazione chiave
land_use_SSP_match <- land_use_SSP_match %>%
  distinct(Scenario, Region, GTAP_11_sector, .keep_all = TRUE)


# Aggeragzione ulteriore dei settori Gtap 

# Aggregazione gro = Rice + Wheat + gro
gro_sum <- land_use_SSP_match %>%
  group_by(Scenario, Region) %>%
  summarise(across(`2020`:`2050`,
                   ~ sum(.x[GTAP_11_sector %in% c("pdr", "wht", "gro")]),
                   .names = "{.col}"),
            .groups = "drop") %>%
  mutate(GTAP_11_sector = "gro")

# Aggregazione ocr = ocr + pfb
ocr_sum <- land_use_SSP_match %>%
  group_by(Scenario, Region) %>%
  summarise(across(`2020`:`2050`,
                   ~ sum(.x[GTAP_11_sector %in% c("ocr", "pfb")]),
                   .names = "{.col}"),
            .groups = "drop") %>%
  mutate(GTAP_11_sector = "ocr")

livestock_sum <- land_use_SSP_match %>%
  group_by(Scenario, Region) %>%
  summarise(across(`2020`:`2050`,
                   ~ sum(.x[GTAP_11_sector %in% c("ctl", "pfb", "rmk", "wol")]),
                   .names = "{.col}"),
            .groups = "drop") %>%
  mutate(GTAP_11_sector = "Livestock")


# Unione dei risultati
land_use_SSP_match <- land_use_SSP_match %>%
  filter(!GTAP_11_sector %in% c("pdr", "wht", "gro", "ocr", "pfb", "ctl", "pfb", "rmk", "wol"))  # togliamo le righe che verranno aggregate

land_use_SSP_match <- bind_rows(land_use_SSP_match,gro_sum, ocr_sum, livestock_sum)


# Aggiungo totali aree land 
land_use_SSP_match_sum <- land_use_SSP_match %>%
  # raggruppa per NUTS_ID e Scenario
  group_by(Scenario, Region) %>%
  # calcola la somma di tutte le colonne numeriche (anni)
  summarise(across(where(is.numeric), function(x) sum(x, na.rm = TRUE)),
            .groups = "drop")%>%
  # aggiungi le colonne fisse richieste
  mutate(
    GTAP_11_sector = "Land_tot",
  )

# unisci al dataset originale
land_use_SSP_match_sum <- bind_rows(land_use_SSP_match_sum ,land_use_SSP_match)
land_use_SSP_match_sum = land_use_SSP_match_sum[c(1:2,10,3:9)]
names(land_use_SSP_match_sum)[2] <- "NUTS_ID"


## Identifica duplicati sulle prime 4 colonne
dups_keys <- land_use_SSP_match_sum %>%
  group_by( Scenario, NUTS_ID, GTAP_11_sector) %>%
  filter(n() > 1) %>%
  ungroup()
# Messaggio informativo
if (nrow(dups_keys) > 0) {
  message("⚠️ Trovati ", nrow(dups_keys), 
          " duplicati sulle chiavi Scenario–Region–LandCover–Land_Use.")} else {
            message("✓ Nessun duplicato sulle prime 4 colonne.")}

# Rimuove i duplicati mantenendo una sola riga per combinazione chiave
#land_use_SSP_match_sum <- land_use_SSP_match_sum %>%
#  distinct(Scenario, NUTS_ID, GTAP_11_sector, .keep_all = TRUE)


#------- Save ----------------------------------------------------------------

write.xlsx(land_use_SSP_match_sum, "Calib_land_use_SSP_match_sum.xlsx")

#-----------------------------------------------------------------------
# Aggrego per NUTS 0,1,2
#-----------------------------------------------------------------------
# rinomina colonna region in NUTS_ID

# rinomino valori senza match perfetto
land_use_SSP_match_nuts <- land_use_SSP_match_sum %>%
  mutate(NUTS_ID = case_when(
    NUTS_ID == "mlt" ~ "MT",
    NUTS_ID == "bgr" ~ "BG",
    NUTS_ID == "cyp" ~ "CY",
    NUTS_ID == "cze" ~ "CZ",
    NUTS_ID == "dnk" ~ "DK",
    NUTS_ID == "est" ~ "EE",
    NUTS_ID == "fin" ~ "FI",
    NUTS_ID == "hrv" ~ "HR",
    NUTS_ID == "hun" ~ "HU",
    NUTS_ID == "irl" ~ "IE",
    NUTS_ID == "ltu" ~ "LT",
    NUTS_ID == "lux" ~ "LU",
    NUTS_ID == "lva" ~ "LV",
    NUTS_ID == "mlt" ~ "MT",
    NUTS_ID == "svk" ~ "SK", 
  
    TRUE ~ NUTS_ID   # tutti gli altri restano invariati
  ))

land_use_SSP_match_nuts <- land_use_SSP_match_nuts %>%
  mutate(NUTS_ID   = str_to_upper(NUTS_ID))     # <-- da minuscole a maiuscole    


# Funzione di aggregazione per un certo prefisso di NUTS_ID
 aggregate_by_prefix <- function(df, n) {
     df %>%
         mutate(NUTS_ID = str_sub(NUTS_ID, 1, n)) %>%   # prefisso
         group_by(Scenario, NUTS_ID, GTAP_11_sector) %>%
         summarise(across(`2020`:`2050`, sum), .groups = "drop")
   }


# Calcoli per ciascun livello
agg2 <- aggregate_by_prefix(land_use_SSP_match_nuts, 2)  # prime 2 lettere
agg3 <- aggregate_by_prefix(land_use_SSP_match_nuts, 3)  # prime 3 lettere


# Combina tutto con il dataset originale
land_use_SSP_match_nuts <- bind_rows(
  land_use_SSP_match_nuts,
  agg2, agg3
)

## Identifica duplicati sulle prime  colonne
dups_keys <- land_use_SSP_match_nuts %>%
  group_by( Scenario, NUTS_ID, GTAP_11_sector) %>%
  filter(n() > 1) %>%
  ungroup()
# Messaggio informativo
if (nrow(dups_keys) > 0) {
  message("⚠️ Trovati ", nrow(dups_keys), 
          " duplicati sulle chiavi Scenario–Region–LandCover–Land_Use.")} else {
            message("✓ Nessun duplicato sulle prime colonne.")}

# Rimuove i duplicati mantenendo una sola riga
land_use_SSP_match_nuts <- land_use_SSP_match_nuts %>% distinct()

# Rimuove le righe con codici chiavi identici mantenendo una sola riga per combinazione chiave 
# mantiene la riga con i valori più alti che corrisponde a il NUTS livello 0 (l'errore è generato li)
land_use_SSP_match_nuts <- land_use_SSP_match_nuts %>%
  group_by(Scenario, NUTS_ID, GTAP_11_sector) %>%
  slice_max(`2020`, n = 1, with_ties = FALSE) %>%
  ungroup()


# griglia completa
grid <- expand.grid(
  NUTS_ID = final_GTAP_aggr$NUTS_ID,
  Scenario = unique(land_use_SSP_match_nuts$Scenario),
  GTAP_11_sector = unique(land_use_SSP_match_nuts$GTAP_11_sector)
)

# merge con i dati SSP
full_SSP <- merge(
  grid,
  land_use_SSP_match_nuts,
  by = c("NUTS_ID", "Scenario", "GTAP_11_sector"),
  all.x = TRUE
)

# riempi NA numerici con 0
num_cols <- sapply(full_SSP, is.numeric)
full_SSP[num_cols] <- lapply(full_SSP[num_cols], function(x) ifelse(is.na(x), 0, x))

nuts_found <- full_SSP$NUTS_ID[
  full_SSP$Scenario == "SSP1" &
    full_SSP$GTAP_11_sector == "c_b"
]

# merge con file matching 
NUTS2_AllSSPs_GTAP = merge(final_GTAP_aggr, land_use_SSP_match_nuts, by="NUTS_ID", all.x=TRUE)


# calcolo rest of the world 
rest_of_w <- land_use_SSP_match_nuts |>
  filter(!grepl("[0-9]", NUTS_ID)) |>
  anti_join(final_GTAP_aggr, by = "NUTS_ID")
unique(rest_of_w$NUTS_ID)

EU_codes <- c(
  # ISO2
  "AT","BE","BG","CY","CZ","DE","DK","EE","ES","FI","FR","GR","HR","HU",
  "IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK",
  
  # ISO3
  "AUT","BEL","BGR","CYP","CZE","DEU","DNK","EST","ESP","FIN","FRA","GRC",
  "HRV","HUN","IRL","ITA","LTU","LUX","LVA","MLT","NLD","POL","PRT","ROU",
  "SWE","SVN","SVK",
  
  # NUTS prefixes
  "FRB","FRC","FRD","FRE","FRF","FRG","FRH","FRI","FRJ","FRK","FRL","FRM",
  "ITC","ITF","ITG","ITH","ITI",
  "TRA","TRB","TRC")


# rimuovo paesi EU rimanenti nel merge 
rest_of_w <- rest_of_w %>%
  filter(!NUTS_ID %in% EU_codes)

unique(rest_of_w$NUTS_ID)

# Aggrego "rest of the world" in un'unica regione RoW per scenario e settore GTAP
rest_of_w_agg <- rest_of_w %>%
  group_by(Scenario, GTAP_11_sector) %>%
  summarise(
    across(`2020`:`2050`, sum, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    NUTS_ID = "RoW"
  )

# Allineo le colonne all'ordine di land_use_SSP_match_nuts
rest_of_w_agg <- rest_of_w_agg %>%
  select(names(land_use_SSP_match_nuts[c(1:10)]))

# rimuovo Uk che veniva duplicato
NUTS2_AllSSPs_GTAP <- NUTS2_AllSSPs_GTAP %>%
  filter(!grepl("^UK", NUTS_ID))

# Aggiungo RoW al dataset principale
NUTS2_AllSSPs_GTAP <- bind_rows(
  NUTS2_AllSSPs_GTAP,
  rest_of_w_agg
)

unique(NUTS2_AllSSPs_GTAP$NUTS_ID)

## Identifica duplicati sulle prime  colonne
dups_keys <- NUTS2_AllSSPs_GTAP %>%
  group_by(  NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,Scenario,GTAP_11_sector) %>%
  filter(n() > 1) %>%
  ungroup()
# Messaggio informativo
if (nrow(dups_keys) > 0) {
  message("⚠️ Trovati ", nrow(dups_keys), 
          " duplicati sulle chiavi Scenario–Region–LandCover–Land_Use.")} else {
            message("✓ Nessun duplicato sulle prime colonne.")}

# Rimuove i duplicati mantenendo una sola riga
#NUTS2_AllSSPs_GTAP <- NUTS2_AllSSPs_GTAP %>% distinct()


NUTS2_AllSSPs_GTAP[is.na(NUTS2_AllSSPs_GTAP)] <- 0

#------- SAVE------------
setwd(calib_land_use_outputs)

write.xlsx(NUTS2_AllSSPs_GTAP,"Calib_Land_Use_SSPs_GTAP.xlsx")
write.csv(NUTS2_AllSSPs_GTAP,"Calib_Land_Use_SSPs_GTAP.csv")
 

#-----------------------------------------------------------------------
# Creo dataframe con le percentuali CUMULATE di cambiamento delle aree in ogni scenario 
names_gtap = names(NUTS2_AllSSPs_GTAP)

Land_Use_SSPs_GTAP_cum <- NUTS2_AllSSPs_GTAP %>%
  mutate(base_2020 = `2020`) %>%
  mutate(across(`2020`:`2050`,
                ~ ifelse(base_2020 == 0,
                         0,
                         (.x - base_2020) / base_2020 * 100))) %>%
  mutate(`2020` = 0) %>%
  rowwise() %>%
  mutate(
    slope = `2050` / 30,
    `2055` = `2050` + slope * 5,
    `2060` = `2050` + slope * 10,
    `2065` = `2050` + slope * 15,
    `2070` = `2050` + slope * 20,
    `2075` = `2050` + slope * 25,
    `2080` = `2050` + slope * 30
  ) %>%
  ungroup() %>%
  # 🔒 Impongo limite inferiore a -99%
  mutate(across(c(`2025`,`2030`,`2035`,`2040`,`2045`,`2050`,
                  `2055`,`2060`,`2065`,`2070`,`2075`,`2080`),
                ~ pmax(.x, -99))) %>%
  select(-slope, -base_2020) %>%
  mutate(across(where(is.numeric), ~ round(.x, 2)))


# Creo valori per PL7, 8, 9 come media di valori PL
# Seleziono tutte le regioni PL esistenti
PL_regions <- Land_Use_SSPs_GTAP_cum %>%
  filter(str_starts(NUTS_ID, "PL"))
#  Calcolo la media per ogni combinazione Scenario × Settore
PL_base <- PL_regions %>%
  filter(if_all(where(is.numeric), ~ !is.na(.x))) %>%
  group_by(Scenario, GTAP_11_sector) %>%
  summarise(across(where(is.numeric), mean, na.rm = TRUE), .groups = "drop")
#  Creo PL7, PL8, PL9 (una sola riga per Scenario × Settore)
PL7 <- PL_base %>%
  mutate(
    NUTS_ID = "PL7",
    LEVL_CODE = 1,
    ICES_Reg_region_ACCREU = "CentrePol" )
PL8 <- PL_base %>%
  mutate(
    NUTS_ID = "PL8",
    LEVL_CODE = 1,
    ICES_Reg_region_ACCREU = "EastPol")
PL9 <- PL_base %>%
  mutate(
    NUTS_ID = "PL9",
    LEVL_CODE = 1,
    ICES_Reg_region_ACCREU = "Masovia")

# Aggiungo PL7, PL8, PL9 al dataset
Land_Use_SSPs_GTAP_cum <- bind_rows(
  Land_Use_SSPs_GTAP_cum,
  PL7, PL8, PL9
)


## Identifica duplicati sulle prime  colonne
dups_keys <- Land_Use_SSPs_GTAP_cum %>%
  group_by(  NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,Scenario,GTAP_11_sector) %>%
  filter(n() > 1) %>%
  ungroup()
# Messaggio informativo
if (nrow(dups_keys) > 0) {
  message("⚠️ Trovati ", nrow(dups_keys), 
          " duplicati sulle chiavi Scenario–Region–LandCover–Land_Use.")} else {
            message("✓ Nessun duplicato sulle prime colonne.")}

# Rimuove i duplicati mantenendo una sola riga
Land_Use_SSPs_GTAP_cum <- Land_Use_SSPs_GTAP_cum %>% distinct()

Land_Use_SSPs_GTAP_cum[is.na(Land_Use_SSPs_GTAP_cum)] <- 0


unique(Land_Use_SSPs_GTAP_cum$Scenario)
unique(Land_Use_SSPs_GTAP_cum$GTAP_11_sector)

# creo la griglia con tutte le combinazioni scenario-crop possibili
nuts_ids <- final_GTAP_aggr$NUTS_ID
nuts_ids <- c(nuts_ids, "RoW")
scenarios <- c("SSP1" ,"SSP4" ,"SSP3", "SSP2" ,"SSP5")
sectors   <- c("frs","c_b" ,"v_f", "gro" ,"osd", "ocr", "Livestock" , "Land_tot" )

grid_full <- expand.grid(
  NUTS_ID = nuts_ids,
  Scenario = scenarios,
  GTAP_11_sector = sectors,
  stringsAsFactors = FALSE
)

grid_full <- merge(
  grid_full,
  final_GTAP_aggr,
  by = "NUTS_ID",
  all.x = TRUE)
grid_full[is.na(grid_full)] <- 0


Land_Use_SSPs_GTAP_cum = merge(grid_full, Land_Use_SSPs_GTAP_cum, all.x=TRUE)

Land_Use_SSPs_GTAP_cum <- Land_Use_SSPs_GTAP_cum %>% 
  filter(Scenario != "0")

#------- SAVE------------
setwd(calib_land_use_outputs)

write.xlsx(Land_Use_SSPs_GTAP_cum,"Calib_Land_Use_SSPs_GTAP_cum.xlsx")
write.csv(Land_Use_SSPs_GTAP_cum,"Calib_Land_Use_SSPs_GTAP_cum.csv")
 

#----------------------------------------------------------------------------------------
# creo files con variazione cumulate 5 years per input ICES

#----------------------------------------------------------------------------------------
setwd(calib_land_use_outputs)

#Land_Use_SSPs_GTAP_cum = read.xlsx("Calib_Land_Use_SSPs_GTAP_cum.xlsx")

Land_Use_SSPs_GTAP_cum_long= Land_Use_SSPs_GTAP_cum

head(Land_Use_SSPs_GTAP_cum_long)
names(Land_Use_SSPs_GTAP_cum_long)

# verificare che ogni combinazione chiave nel dataset sia univoca per ogni anno.
Land_Use_SSPs_GTAP_cum_long %>%
  pivot_longer(
    cols = matches("^20\\d{2}$"),
    names_to = "year",
    values_to = "shock_cum"
  ) %>%
  mutate(
    year = as.integer(year),
    scenario_year = paste0(Scenario, "_", year)
  ) %>%
  summarise(
    n = dplyr::n(),
    .by = c(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,
            Scenario, GTAP_11_sector, scenario_year)
  ) %>%
  filter(n > 1)



# creo percentuali cumulate 5y 

Land_Use_SSPs_GTAP_5y <- Land_Use_SSPs_GTAP_cum_long %>%
  
  # 1) Wide → long
  pivot_longer(
    cols = matches("^20\\d{2}$"),
    names_to = "year",
    values_to = "shock_cum"
  ) %>%
  
  # 2) Converti anno
  mutate(year = as.integer(year)) %>%
  
  # 3) Costruisci indice cumulato
  mutate(index = 1 + shock_cum / 100) %>%
  
  # 4) Calcola shock quinquennale
  arrange(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,
          Scenario, GTAP_11_sector, year) %>%
  group_by(NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,
           Scenario, GTAP_11_sector) %>%
  mutate(shock_5y = (index / lag(index) - 1) * 100) %>%
  ungroup() %>%
  
  # 5) Imposta 2020 = 0
  mutate(shock_5y = if_else(year == 2020, 0, shock_5y)) %>%
  
  # 6) Arrotonda
  mutate(shock_5y = round(shock_5y, 2)) %>%
  
  # 7) Long → wide (solo anni come colonne)
  select(
    NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU,
    Scenario, GTAP_11_sector,
    year, shock_5y
  ) %>%
  pivot_wider(
    names_from  = year,
    values_from = shock_5y
  ) %>%
  
  # 8) Ordina
  arrange(NUTS_ID, Scenario, GTAP_11_sector)


Land_Use_SSPs_GTAP_5y[is.na(Land_Use_SSPs_GTAP_5y)] <- 0



#------- SAVE------------
setwd(calib_land_use_outputs)

write.xlsx(Land_Use_SSPs_GTAP_5y,"Calib_Land_Use_SSPs_GTAP_cum_5y.xlsx")
write.csv(Land_Use_SSPs_GTAP_5y,"Calib_Land_Use_SSPs_GTAP_cum_5y.csv")

 
   
