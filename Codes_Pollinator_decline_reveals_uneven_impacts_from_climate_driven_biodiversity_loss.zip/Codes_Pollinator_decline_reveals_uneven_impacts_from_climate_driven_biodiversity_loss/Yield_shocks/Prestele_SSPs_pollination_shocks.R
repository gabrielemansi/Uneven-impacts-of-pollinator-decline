# ==============================================================================
# Prestele_SSPs_pollination_shocks.R
# ------------------------------------------------------------------------------
# Crop yield shocks from the change in pollination potential projected with the
# climate and land-use (COMB) scenarios of Prestele et al. (2021)
# (Prestele_SSPs_INCA_cum_2020_2080), by NUTS region, crop and GTAP sector.
#
# Method
#   1. For each CROPGRIDS crop, NUTS region and layer (scenario and year), the % change in
#      pollination potential relative to 2020 is averaged over the harvested
#      area of the crop (area-weighted mean, bounded to [-1000, 1000]).
#   2. Yield shock of each crop: mean change multiplied by the pollination
#      dependency of the crop.
#   3. Yield shock of the crops of each GTAP sector (gro, v_f, osd, c_b, ocr) are
#      averaged, weighted by the crop areas projected under the SSP land-use
#      scenarios of Goebel and Britz (2025):
#        SSP1_2_6 and SSP1_4_5 with SSP1, SSP3_4_5 and SSP3_8_5 with SSP3,
#        SSP5_8_5 with SSP5.
#      The land-use projections give the % change in crop area by NUTS 2 region
#      only, so the 2020 crop area of each region is scaled by that change,
#      assuming that new crop areas are close to the existing ones and
#      undergo the same change in pollination potential. The shocks are
#      joined to the regions of the economic model.
#
# Inputs (paths relative to the project root)
#   POTENTIAL/baselines_pollination/Prestele_SSPs/Prestele_SSPs_INCA_cum_2020_2080.tif
#   POTENTIAL/input_pollination/INCA_data/potential_categories.tif
#   DEMAND/AREA_crops/FAO_CROPGRIDS_rasters/<crop>.tif
#   DEMAND/DEPENDENCY_crops/FAO_CROPGRIDS_pollinatio_dependency.xlsx
#   DEMAND/AREA_crops/Shocks_GTAP_match.xlsx
#   DEMAND/AREA_crops/Final_pollination_shocks_GTAP.xlsx
#   DEMAND/AREA_crops/SSP_changes/data_final/crops_land_use/
#     Crops_Land_Use_SSPs_GTAP_cum_WIDE.xlsx (from SSPs_Land.R)
#   EU_boundaries/NUTS_RG_10M_2024_3035/NUTS_RG_10M_2024_3035.shp
#
# Outputs
#   DEMAND/POLL_change_area/Prestele_SSPs/Prestele_SSPs_INCA_cum_2020_2080/<crop>/
#     Prestele_SSPs_INCA_cum_2020_2080_<crop>.xlsx and .rds
#       mean change in pollination potential over the crop area, by NUTS region
#   FINAL_SHOCKS/Prestele_SSPs/Prestele_SSPs_INCA_cum_2020_2080/<crop>/
#     shock_Prestele_SSPs_INCA_cum_2020_2080_<crop>.xlsx, .csv and .rds
#       crop yield shock, by NUTS region
#   FINAL_SHOCKS/Prestele_SSPs/GTAP_shocks/GTAP_2020_2080/
#     Prest_SSPs_shocks_GTAP_<sector>.xlsx, .csv and .rds
#       yield shock by GTAP sector, for the regions of the economic model
#
# Run after INCA_pollination_baselines.R, Prestele_SSPs_pollination_baselines.R
# and SSPs_Land.R
# ==============================================================================

library(terra)
library(dplyr)
library(openxlsx)

# Paths ------------------------------------------------------------------------

base_dir <- "."  # project root (POLLINATION folder)

dataset       <- "Prestele_SSPs"                     # dataset folder name
inca_name     <- "Prestele_SSPs_INCA_cum_2020_2080"  # % change in pollination potential
output_prefix <- "Prest_SSPs"                        # prefix of the GTAP shock files

inca_file       <- file.path(base_dir, "POTENTIAL", "baselines_pollination", dataset,
                             paste0(inca_name, ".tif"))
inca_grid_file  <- file.path(base_dir, "POTENTIAL", "input_pollination", "INCA_data",
                             "potential_categories.tif")
crops_dir       <- file.path(base_dir, "DEMAND", "AREA_crops", "FAO_CROPGRIDS_rasters")
dependency_file <- file.path(base_dir, "DEMAND", "DEPENDENCY_crops",
                             "FAO_CROPGRIDS_pollinatio_dependency.xlsx")
gtap_match_file <- file.path(base_dir, "DEMAND", "AREA_crops", "Shocks_GTAP_match.xlsx")
regions_file    <- file.path(base_dir, "DEMAND", "AREA_crops",
                             "Final_pollination_shocks_GTAP.xlsx")
land_use_file   <- file.path(base_dir, "DEMAND", "AREA_crops", "SSP_changes", "data_final",
                             "crops_land_use", "Crops_Land_Use_SSPs_GTAP_cum_WIDE.xlsx")
nuts_file       <- file.path(base_dir, "EU_boundaries", "NUTS_RG_10M_2024_3035",
                             "NUTS_RG_10M_2024_3035.shp")
change_dir      <- file.path(base_dir, "DEMAND", "POLL_change_area", dataset, inca_name)
shocks_dir      <- file.path(base_dir, "FINAL_SHOCKS", dataset)

# Pollination scenario prefix, SSP of the land-use projections and label used
# in the outputs
scenario_map <- data.frame(
  pollination = c("SSP1_2_6", "SSP1_4_5", "SSP3_4_5", "SSP3_8_5", "SSP5_8_5"),
  land_use    = c("SSP1",     "SSP1",     "SSP3",     "SSP3",     "SSP5"),
  label       = c("SSP1_2_6", "SSP1_4_5", "SSP3_4_5", "SSP3_8_5", "SSP5_8_5")
)

# Functions --------------------------------------------------------------------

na_to_zero <- function(x) {
  x[is.na(x)] <- 0
  x
}

# Sum of the raster values over each NUTS region, rounded to 2 decimals
nuts_sum <- function(r, nuts) {
  na_to_zero(round(extract(r, nuts, fun = sum, na.rm = TRUE)[, 2], 2))
}

# Mean change in pollination potential over the harvested area of a crop in
# each NUTS region (area-weighted), for each layer of inca_change
mean_change_on_crop <- function(crop_area, crop_name, inca_change, nuts) {
  hectares <- nuts_sum(crop_area, nuts)
  out <- nuts
  out$nuts_total_hectares <- hectares
  out$base_name_crop <- crop_name
  for (layer in names(inca_change)) {
    weighted_sum <- nuts_sum(crop_area * inca_change[[layer]], nuts)
    mean_change <- ifelse(hectares > 0, weighted_sum / hectares, 0)
    mean_change[is.nan(mean_change)] <- 0
    out[[layer]] <- round(pmin(pmax(mean_change, -1000), 1000), 2)
  }
  out
}

# Pollination dependency of a crop (0 if missing)
crop_dependency <- function(crop, dependency) {
  d <- dependency$Avg_impact_on_production[dependency$CROPGRIDS == crop]
  d <- suppressWarnings(as.numeric(d))
  if (length(d) == 0 || is.na(d)) 0 else d
}

# Yield shock: change in pollination potential times the crop dependency
apply_dependency <- function(x, dependency) {
  x <- na_to_zero(suppressWarnings(as.numeric(as.character(x))))
  round(x * dependency, 2)
}

# Rename the pollination scenario prefixes to the scenario labels
relabel <- function(x) {
  for (k in seq_len(nrow(scenario_map))) {
    x <- sub(paste0("^", scenario_map$pollination[k]), scenario_map$label[k], x)
  }
  x
}

# Save a table as .rds, .csv and .xlsx
save_table <- function(df, path_stem) {
  saveRDS(df, paste0(path_stem, ".rds"))
  write.csv(df, paste0(path_stem, ".csv"), row.names = FALSE)
  write.xlsx(df, paste0(path_stem, ".xlsx"))
}

# 1. Inputs --------------------------------------------------------------------

dependency <- read.xlsx(dependency_file)[, c("CROPGRIDS", "Avg_impact_on_production")]

nuts <- vect(nuts_file)
nuts <- crop(nuts, rast(inca_grid_file))  # NUTS regions within the INCA extent
nuts <- nuts[, c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN"), drop = FALSE]

# Pollinator-dependent crops (average impact >= 5%) with a non-zero harvested area
dependent_crops <- dependency$CROPGRIDS[dependency$Avg_impact_on_production >= 0.05]
crop_files <- list.files(crops_dir, pattern = "\\.tif$", full.names = TRUE)
crop_files <- crop_files[tools::file_path_sans_ext(basename(crop_files)) %in% dependent_crops]

crop_rasters <- list()
for (f in crop_files) {
  r <- rast(f)
  if (global(r, "max", na.rm = TRUE)[[1]] > 0) {
    crop_rasters[[tools::file_path_sans_ext(basename(f))]] <- round(r, 2)
  }
}

inca_change <- round(rast(inca_file), 2)

# 2. Change in pollination potential over the crop areas -----------------------

for (crop_name in names(crop_rasters)) {
  tryCatch({
    result <- mean_change_on_crop(crop_rasters[[crop_name]], crop_name, inca_change, nuts)
    out_dir <- file.path(change_dir, crop_name)
    dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
    stem <- file.path(out_dir, paste0(inca_name, "_", crop_name))
    saveRDS(result, paste0(stem, ".rds"))
    write.xlsx(as.data.frame(result), paste0(stem, ".xlsx"))
    message("Mean change computed: ", crop_name)
  }, error = function(e) {
    message("Skipped ", crop_name, ": ", conditionMessage(e))
  })
}

# 3. Crop yield shocks ---------------------------------------------------------

id_cols <- c("NUTS_ID", "LEVL_CODE", "CNTR_CODE", "NAME_LATN", "nuts_total_hectares",
             "base_name_crop")

for (crop_dir in list.dirs(change_dir, recursive = FALSE)) {
  crop_name <- basename(crop_dir)
  dep <- crop_dependency(crop_name, dependency)
  out_dir <- file.path(shocks_dir, inca_name, crop_name)
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

  xlsx_file <- list.files(crop_dir, pattern = "\\.xlsx$", full.names = TRUE)
  if (length(xlsx_file) > 0) {
    tryCatch({
      df <- read.xlsx(xlsx_file[1])
      shock_cols <- setdiff(names(df), id_cols)
      df[shock_cols] <- lapply(df[shock_cols], apply_dependency, dependency = dep)
      stem <- tools::file_path_sans_ext(basename(xlsx_file[1]))
      stem <- file.path(out_dir, paste0("shock_", stem))
      write.xlsx(df, paste0(stem, ".xlsx"))
      write.csv(df, paste0(stem, ".csv"), row.names = FALSE)
    }, error = function(e) {
      message("Skipped ", xlsx_file[1], ": ", conditionMessage(e))
    })
  }

  rds_file <- list.files(crop_dir, pattern = "\\.rds$", full.names = TRUE)
  if (length(rds_file) > 0) {
    tryCatch({
      v <- readRDS(rds_file[1])
      for (col in setdiff(names(v), id_cols)) {
        v[[col]] <- apply_dependency(v[[col]], dep)
      }
      saveRDS(v, file.path(out_dir, paste0("shock_", basename(rds_file[1]))))
    }, error = function(e) {
      message("Skipped ", rds_file[1], ": ", conditionMessage(e))
    })
  }
  message("Yield shock computed: ", crop_name)
}

# 4. Yield shocks by GTAP sector, weighted by the SSP crop areas ---------------

gtap_match <- read.xlsx(gtap_match_file)
regions <- read.xlsx(regions_file)[, 1:3]  # NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU
sectors <- c("gro", "v_f", "osd", "c_b", "ocr")

lu_id_cols <- c("base_name_crop", "gtap_id", "GTAP.11.description", "NUTS_ID", "LEVL_CODE",
                "ICES_Reg_region_ACCREU")

# Cumulative % change in crop area relative to 2020, by crop and NUTS region,
# with the columns of each land-use scenario renamed after the scenario labels
land_use <- read.xlsx(land_use_file) %>%
  rename(base_name_crop = shock_crop_names, gtap_id = GTAP.11) %>%
  select(all_of(lu_id_cols), starts_with("SSP"))

land_use_blocks <- lapply(seq_len(nrow(scenario_map)), function(k) {
  prefix <- paste0(scenario_map$land_use[k], "_")
  block <- land_use[, startsWith(names(land_use), prefix), drop = FALSE]
  names(block) <- sub(prefix, paste0(scenario_map$label[k], "_"), names(block), fixed = TRUE)
  block
})
land_use <- cbind(land_use[, lu_id_cols], do.call(cbind, land_use_blocks))

# Crop shocks joined to the land-use table (one table per crop)
crop_shocks <- list()
for (i in seq_len(nrow(gtap_match))) {
  crop_name <- gtap_match$shock_crop_names[i]
  f <- file.path(shocks_dir, inca_name, crop_name,
                 paste0("shock_", inca_name, "_", crop_name, ".xlsx"))
  if (!file.exists(f)) {
    warning("File not found: ", f)
    next
  }
  data <- read.xlsx(f)
  data$base_name_crop <- crop_name
  data <- data[, setdiff(names(data), c("LEVL_CODE", "CNTR_CODE", "NAME_LATN")), drop = FALSE]

  merged <- merge(land_use[land_use$base_name_crop %in% crop_name, lu_id_cols], data,
                  by = c("base_name_crop", "NUTS_ID"), all.x = TRUE)
  merged[is.na(merged)] <- 0
  names(merged) <- relabel(names(merged))
  crop_shocks[[crop_name]] <- merged
}

scenario_cols <- grep("^SSP", names(crop_shocks[[1]]), value = TRUE)
lookup <- land_use[, c("base_name_crop", "NUTS_ID", scenario_cols)]

# Crop area under each scenario: 2020 area scaled by the projected % change
crop_areas <- lapply(crop_shocks, function(df) {
  merged <- merge(df, lookup, by = c("base_name_crop", "NUTS_ID"),
                  suffixes = c("", "_change"), all.x = TRUE)
  for (col in scenario_cols) {
    change <- merged[[paste0(col, "_change")]]
    merged[[col]] <- round(merged$nuts_total_hectares * (1 + change / 100), 2)
  }
  merged[, names(df)]
})

crop_areas <- bind_rows(crop_areas)
crop_shocks <- bind_rows(crop_shocks)
crop_shocks <- crop_shocks[, names(crop_shocks) != "nuts_total_hectares"]

# Share of each crop in the area of its GTAP sector, by NUTS region and scenario
sector_area <- crop_areas %>%
  group_by(gtap_id, NUTS_ID) %>%
  summarise(across(all_of(scenario_cols), ~ sum(.x, na.rm = TRUE)), .groups = "drop")
weights <- left_join(crop_areas, sector_area, by = c("gtap_id", "NUTS_ID"),
                     suffix = c("", "_GTAP"))
for (col in scenario_cols) {
  weights[[col]] <- round(weights[[col]] / weights[[paste0(col, "_GTAP")]], 2)
}
weights <- weights[, c("base_name_crop", "NUTS_ID", "gtap_id", "GTAP.11.description",
                       "LEVL_CODE", "ICES_Reg_region_ACCREU", scenario_cols)]

# Weighted crop shocks (the rows of weights and crop_shocks refer to the same
# crop and region)
stopifnot(identical(weights$NUTS_ID, crop_shocks$NUTS_ID),
          identical(weights$base_name_crop, crop_shocks$base_name_crop))
weighted <- weights[, 1:6]
for (col in scenario_cols) {
  weighted[[col]] <- weights[[col]] * crop_shocks[[col]]
}

all_nuts <- distinct(weighted, NUTS_ID)

# Sum of the weighted crop shocks of a GTAP sector, by NUTS region (0 if the
# region has no crop of the sector)
sector_shock <- function(sector) {
  totals <- weighted %>%
    filter(gtap_id == sector) %>%
    group_by(NUTS_ID) %>%
    summarise(across(all_of(scenario_cols), ~ sum(.x, na.rm = TRUE)), .groups = "drop")
  all_nuts %>%
    left_join(totals, by = "NUTS_ID") %>%
    mutate(gtap_id = sector, across(all_of(scenario_cols), ~ coalesce(.x, 0))) %>%
    select(gtap_id, NUTS_ID, all_of(scenario_cols))
}

gtap_dir <- file.path(shocks_dir, "GTAP_shocks", "GTAP_2020_2080")
dir.create(gtap_dir, recursive = TRUE, showWarnings = FALSE)

for (sector in sectors) {
  shocks <- regions %>%
    left_join(sector_shock(sector), by = "NUTS_ID") %>%
    select(gtap_id, NUTS_ID, LEVL_CODE, ICES_Reg_region_ACCREU, everything())
  save_table(shocks, file.path(gtap_dir, paste0(output_prefix, "_shocks_GTAP_", sector)))
}
