#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
# This file produces pollination potential projections and % shocks.
# Pollination potential projections are generated starting from INCA_2000_2018 data. 
# To capture current pollinators decline trend (EU Butterfly Index 1990/2020) a (conservative) -1% annual shock is applied to INCA_2018 data up to 2035, 
# and then linearly decreasing to match 0% change rate in 2050.  
# The conservation policy is modeled starting from the 2025 value. Pollination potential increases by 1% per year until 2060 (35 years), 
# to match the expected 1990 pollination potential value.  
 
# Output files:
# INCA_2000_2018_normalized.tif: Pollination potential from baseline INCA normalized to 0, 1
# INCA_2000_2018_CLASS.tif : Pollination potential from baseline INCA divided in potential CLASSES (1-4 = NULL,LOW,MED,HIGH)
# INCA_2020_2080.tif : Pollination potential 2020_2080 in the scenario with NO policy
# INCA_2020_2080_CLASS.tif  
# INCA_2020_2080_policy.tif: Pollination potential 2020_2080 in the scenario where the policy is applied. 
# INCA_2020_2080_policy_CLASS.tif
# INCA_2020_2080_policy_y_pct.tif : Annual shock of pollination potential (annual % increase) NOT cumulative, in the policy scenario, respect to 2020
# INCA_pct_cumulative_2020_2080_policy.tif : Shock on pollination potential (annual % increase) CUMULATIVE (y3= y1+y2), in the conservation policy scenario, respect to 2020
# INCA_pct_change_2020_2080.tif :Shock on pollination potential (% difference respect to baseline value in the same year) in the conservation policy scenario

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------

 
rm(list = ls())  
gc()

# Load the package
library(terra)
library(tidyr)
library(fields)
library(ade4)
library(ape)
library(blockCV)
library(diagram)
library(dismo)
library(gbm)
library(geosphere)
library(ggplot2)
library(HDInterval)
library(lubridate)
library(ncdf4)
library(ncf)
library(picante)
library(pgirmess)
library(phytools)
library(RColorBrewer)
library(raster)
library(sf)
library(seqinr)
library(sp)
library(vioplot)
library(raster) 
library(dplyr)  
library(openxlsx)

wd = paste0('D:/Il mio Drive/Desktop/research/intergen_equity/Ecosystems/AGRO_ECOS/A_WORKFLOW/POLLINATION/')

INCA_data = paste0(wd, 'POTENTIAL/input_pollination/INCA_data')
output_baselines = paste0(wd, 'POTENTIAL/baselines_pollination/INCA')
output_baselines_nuts  = paste0(wd, '/POTENTIAL/baselines_NUTS/INCA')
DEPENDENCY_crops = paste0(wd, 'DEMAND/DEPENDENCY_crops')
crops_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS/CROPGRIDSv1.08_NC_maps')
output_area = paste0(wd, 'DEMAND/AREA_crops/FAO_CROPGRIDS_rasters')
EU_boundaries = paste0(wd, 'EU_boundaries/NUTS_RG_10M_2024_3035')


# Load the INCA_2000_2018 file for baseline pollination potential 
setwd(INCA_data)
file_name = paste0("potential_categories") 
file_path <- paste0(file_name,  ".tif")
INCA_2000_2018 <- rast(file_path)


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
setwd(output_baselines)

#--------------------------------------------------------------------------------------------------------------------------
# A) Future pollination potential projections based on INCA 2018 with no climate change 
#----------------------------------------------------------------------------------------------------------------------------------

# Normalize. Recode values using simple math (value / 4)
# in this way NULL potential is considered between 0 and 0.25, LOW up to 0.5, MED up to 0.75 and HIGH above 0.75
names(INCA_2000_2018) <- c("2000", "2006", "2012", "2018")
INCA_2000_2018_normalized <- INCA_2000_2018 / 4
 
#--------------------------------------------------------------------------
# save
writeRaster(INCA_2000_2018_normalized, "INCA_2000_2018_normalized.tif", overwrite = TRUE)
writeRaster(INCA_2000_2018, "INCA_2000_2018_CLASS.tif", overwrite = TRUE)
#-------------------------------------------------------------------------
# Create raster with pollination potential to 2080 in the NO conservation policy scenario:
# A -1% pollination  decrease is applied to INCA2018 base year up to 2035,   
# and then linearly decreasing to match 0% change rate in 2050.  

# Extract 2018 base raster
inca_2018 <- INCA_2000_2018_normalized[["2018"]]

# Base values
base_vals <- values(inca_2018)

# Years (5-year steps)
future_years <- seq(2020, 2080, by = 5)

# Init
raster_list <- list()
template <- inca_2018

# 2020 = 2018
raster_list[["2020"]] <- inca_2018

# Parameters
start_year <- 2020
full_rate_until <- 2035
zero_rate_year <- 2050
annual_rate_2020 <- 0.01

# Equivalent 5-year rate
rate_5y <- function(r) {
  1 - (1 - r)^5
}

# Factor at 2035
n_steps_2035 <- (full_rate_until - start_year) / 5
factor_2035 <- (1 - rate_5y(annual_rate_2020))^n_steps_2035

for (year in future_years[future_years > 2020]) {
  
  if (year <= full_rate_until) {
    
    n_steps <- (year - start_year) / 5
    factor <- (1 - rate_5y(annual_rate_2020))^n_steps
    
  } else if (year <= zero_rate_year) {
    
    steps_after <- (year - full_rate_until) / 5
    
    annual_rates <- seq(
      from = annual_rate_2020,
      to = 0,
      length.out = (zero_rate_year - full_rate_until) / 5 + 1
    )[seq_len(steps_after)]
    
    factor <- factor_2035 * prod(1 - rate_5y(annual_rates))
    
  } else {
    
    factor <- factor_2035 * prod(
      1 - rate_5y(
        seq(
          from = annual_rate_2020,
          to = 0,
          length.out = (zero_rate_year - full_rate_until) / 5 + 1
        )
      )
    )
  }
  pred_vals <- base_vals * factor
  r_pred <- rast(
    template,
    vals = pmin(pmax(pred_vals, 0), 1))
  names(r_pred) <- as.character(year)
  raster_list[[as.character(year)]] <- r_pred
}

# Stack
INCA_2020_2080 <- rast(raster_list)


# CLASSIEFIED raster with pollination potential to 2080 recompiled in CLASSES  
classify_potential <- function(raster_layer) {
  m <- matrix(c(
    -Inf, 0.25, 1,   # NULL
    0.25, 0.5, 2,    # LOW
    0.5,  0.75, 3,   # MED
    0.75, Inf, 4     # HIGH
  ), ncol = 3, byrow = TRUE)
  classify(raster_layer, rcl = m, include.lowest = TRUE)  }

# Applica la funzione di classificazione a ciascun raster
INCA_2020_2080_CLASS <- classify_potential(INCA_2020_2080)


# Raster con variazione % annuale nella baseline 2020_2080 rispetto all'anno base
INCA_pct_change_2020_2080 <- (INCA_2020_2080 - inca_2018) / inca_2018 * 100

gc()
#------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------
# B) Create raster with pollination potential to 2080 in the conservation policy scenario:
# Pollination decline is reversed starting from 2025 to 2060 (+1% annual)

template <- inca_2018
val_2060 <- NULL

for (year in future_years[future_years > 2020]) {
  if (year == 2025) {
    pred_vals <- base_vals * 0.95
  } else if (year == 2030) {
    pred_vals <- base_vals
  } else if (year > 2030 & year <= 2060) {
    steps <- (year - 2030) %/% 5
    pred_vals <- base_vals * (1 + 0.05 * steps)
    if (year == 2060) val_2060 <- pred_vals
  } else if (year > 2060) {
    pred_vals <- val_2060
  } else {
    next}
    r_pred <- rast(template, vals = pmin(pmax(pred_vals, 0), 1))
  names(r_pred) <- as.character(year)
  raster_list[[as.character(year)]] <- r_pred   }

# Stack all layers into a single multilayer raster
INCA_2020_2080_policy <- rast(raster_list)
INCA_2020_2080_policy <- app( INCA_2020_2080_policy, fun = function(x) round(x, 2))

# Applica la funzione di classificazione a ciascun raster
INCA_2020_2080_policy_CLASS <- classify_potential(INCA_2020_2080_policy)

#--------------------------------------------------------------------------------------------------
# Raster con aumento % annuale nello scenario di policy rispetto a baseline 2020_2080
INCA_pct_change_2020_2080_policy <- (INCA_2020_2080_policy - INCA_2020_2080) / INCA_2020_2080 * 100
names(INCA_pct_change_2020_2080_policy) <- names(INCA_2020_2080)
INCA_pct_change_2020_2080_policy <- app( INCA_pct_change_2020_2080_policy, fun = function(x) round(x, 2))


# Raster con aumento % annuale nello scenario di policy rispetto ad anno base 2020
base_2020 <- INCA_2020_2080[[1]]

# Calcola la variazione percentuale di ogni layer rispetto al base 2020
INCA_pct_cumulative_2020_2080_policy <- (INCA_2020_2080_policy - base_2020) / base_2020 * 100
names(INCA_pct_cumulative_2020_2080_policy) <- names(INCA_2020_2080)
INCA_pct_cumulative_2020_2080_policy <- app(INCA_pct_cumulative_2020_2080_policy, fun = function(x) round(x, 2))

#------------------------------------------------------------------------------------------------

#save
writeRaster(INCA_2020_2080, "INCA_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_2020_2080_CLASS, "INCA_2020_2080_CLASS.tif", overwrite = TRUE)
writeRaster(INCA_pct_change_2020_2080, "INCA_pct_change_2020_2080.tif", overwrite = TRUE)
writeRaster(INCA_2020_2080_policy, "INCA_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_2020_2080_policy_CLASS, "INCA_2020_2080_policy_CLASS.tif", overwrite = TRUE)
writeRaster(INCA_pct_change_2020_2080_policy, "INCA_pct_change_2020_2080_policy.tif", overwrite = TRUE)
writeRaster(INCA_pct_cumulative_2020_2080_policy, "INCA_pct_cumulative_2020_2080_policy.tif", overwrite = TRUE)
 
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------
gc()

#-----------------------------------------------------------------------------------------
## some statistics - means
setwd(output_baselines)
# Function to extract mean values from all layers of a SpatRaster
extract_means <- function(rast_obj, dataset_name) {
  layer_names <- names(rast_obj)
  means <- global(rast_obj, mean, na.rm = TRUE)
  
  # Create data frame
  df <- data.frame(
    Layer = layer_names,
    Mean = round(means[, 1], 5),
    Dataset = dataset_name )
  return(df)}

# Compute mean values
INCA_2020_2080 = rast("INCA_2020_2080.tif")
INCA_2020_2080_policy = rast("INCA_2020_2080_policy.tif")

a <- extract_means(INCA_2020_2080, "INCA_2020_2080")
b <- extract_means(INCA_2020_2080_policy, "INCA_2020_2080_policy")


# Combine and export
means_all <- rbind(a,b)

# Save to CSV
#write.xlsx(means_all, file = "beselines_pollination_potential_means_2020_2080.xlsx", row.names = FALSE)
#write.csv(means_all, file = "beselines_pollination_potential_means_2020_2080.csv", row.names = FALSE)

 

#-------------------------------------------------------------------------
# CREATE FILES WITH POLLINATION POTENTIAL AT EU NUTS 0,1,2,3 level 
#-------------------------------------------------------------------------

#-------------------------------------------------------------------------
# Load file .shp with NUTS3 boundaries 
setwd(EU_boundaries)
nuts <- vect("NUTS_RG_10M_2024_3035.shp")   ## Shapefile with NUts 1,2,3 boudaries 
#------------------------

# Loop over both input folders
for (input_path in output_baselines) {
  tif_files <- list.files(input_path, pattern = "\\.tif$", full.names = TRUE)
  
  for (tif_file in tif_files) {
    # Load raster
    INCA_raster <- rast(tif_file)
    
    # Crop NUTS to raster extent
    nuts_cropped <- crop(nuts, INCA_raster)
    
    # Extract mean values per polygon
    nuts_means <- extract(INCA_raster, nuts_cropped, fun = mean, na.rm = TRUE)
    # Round the mean values to 2 decimals
    nuts_means[,-1] <- round(nuts_means[,-1], 2)
    
    # Combine with attributes
    INCA_NUTS <- cbind(nuts_cropped, nuts_means[,-1])
    INCA_NUTS_df <- as.data.frame(INCA_NUTS)
    
    # Create output subfolder named after the raster file
    base_name <- tools::file_path_sans_ext(basename(tif_file))
    subfolder <- paste0(output_baselines_nuts, "/", base_name)
    dir.create(subfolder, showWarnings = FALSE)
    
    # Save RDS
    saveRDS(INCA_NUTS, paste0(subfolder, "/", base_name, ".rds"))
    
    # Save Excel
    write.xlsx(INCA_NUTS_df, paste0(subfolder, "/", base_name, ".xlsx"))
    

    
    cat("✅ Processed:", base_name, "\n")
  }
}



#--------------------------------------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------------
# PREPARE RESTERS FOR POLLONATION DEMAND FOR DIFFERENT CROPS

# The overlap between the pollination potential and demand for pollination is used to 
# quantify the area generating the actual flow of service, i.e. the use area
# The use area can be quantified as the number of hectares of pollinator-dependent crops 
# covered by area with different potential to support pollinators.
#-------------------------------------------------------------------------

# Load CROPGRIDS crops pollination dependency file 
setwd(DEPENDENCY_crops)
crop_dependency = read.xlsx("FAO_CROPGRIDS_pollinatio_dependency.xlsx")
crop_dependency = crop_dependency[c(1,6)]

# Load INCA data
setwd(INCA_data)
INCA_2018 = rast('potential_categories.tif')
INCA_2018 = INCA_2018[[4]] / 4

#  Converto i file CROPGRIDS da .nc a .tif compatibili con INCA data 
# Load CROPGRIDS
setwd(crops_area)

# List all tif files starting with "spam2020_V2r0_global_H_"
nc_files <- list.files(pattern = "^CROPGRIDSv1.08_.*\\.nc$")

# Loop through each file
for (file in nc_files) {
  # Extract the name after "08_" and before ".nc"
  name_suffix <- sub("CROPGRIDSv1.08_(.*)\\.nc", "\\1", file)
  # Add the "H_" prefix
  var_name <- paste0( name_suffix)
  # 1. Apri file NetCDF e carica variabile
  nc_file <- nc_open(file)
  harvarea <- ncvar_get(nc_file, "harvarea")
  lon <- ncvar_get(nc_file, "lon")  # 7200 longitudes
  lat <- ncvar_get(nc_file, "lat")  # 3600 latitudes
  nc_close(nc_file)
  harvarea <- harvarea[, ncol(harvarea):1]  # perché NetCDF ha lat decrescente
  # 2. Crea un oggetto raster vuoto con le dimensioni giuste
  r_orig <- rast(nrows = length(lat), ncols = length(lon),
                 xmin = min(lon), xmax = max(lon),
                 ymin = min(lat), ymax = max(lat),
                 crs = "EPSG:4326")
  # 3. Assegna i valori della matrice al raster
  values(r_orig) <- as.vector(harvarea)  # matrice -> vettore colonna
  # 4. Proietta il raster NetCDF su quello target
  harv_proj <- project(r_orig, INCA_2018, method = "bilinear")
  # 5. Ritaglia per avere le stesse dimensioni (in caso serva)
  harv_crop <- crop(harv_proj, INCA_2018, snap = "out")
  # 6. Allinea perfettamente (resample)
  harv_final <- resample(harv_crop, INCA_2018, method = "bilinear")
  # Force minimum value = 0 (replace negatives with 0)
  harv_final <- ifel(harv_final < 0, 0, harv_final)
  # Assign raster to a variable with the constructed name
  assign(var_name, harv_final)
  # Save raster 
  outfile <- file.path(output_area, paste0(var_name, ".tif"))
  writeRaster(harv_final, outfile, overwrite = TRUE)
  cat("✅ Processed:", outfile, "\n")
  
}





